$(document).ready(function () {
    $('#hight-title').hover(function () {
        $('#hight-title').css("color", "#38b449");
    }, function () {
        $('#hight-title').css("color", "");
    });
});