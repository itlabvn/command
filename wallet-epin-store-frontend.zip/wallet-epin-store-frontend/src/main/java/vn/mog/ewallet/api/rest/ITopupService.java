package vn.mog.ewallet.api.rest;

import vn.mog.ewallet.intergration.contract.topup.CustomerResponse;
import vn.mog.ewallet.exception.StoreFrontException;

public interface ITopupService {
	CustomerResponse findCustomer(String username, String cif, String email, String phone) throws StoreFrontException;

	long getBalance() throws StoreFrontException;

}
