package vn.mog.ewallet.exception;


public class SecurityException extends StoreFrontException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SecurityException(int errorCode, String errorMessage) {
		super(errorCode, errorMessage);
	}
	
	public SecurityException(int errorCode, String source,  String errorMessage) {
		super(errorCode, source, errorMessage);
	}
}
