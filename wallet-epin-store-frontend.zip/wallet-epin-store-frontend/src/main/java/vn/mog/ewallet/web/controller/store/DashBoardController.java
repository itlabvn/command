package vn.mog.ewallet.web.controller.store;

import org.apache.commons.lang3.StringUtils;
import org.jboss.logging.Logger;
import org.json.JSONObject;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import vn.mog.ewallet.intergration.contract.store.GetCardDashBoardRequest;
import vn.mog.ewallet.intergration.contract.store.GetCardDashBoardResponse;
import vn.mog.ewallet.intergration.contract.store.bean.CardDashBoardItem;
import vn.mog.ewallet.intergration.contract.store.bean.CardSummaryWarning;
import vn.mog.ewallet.intergration.contract.store.bean.ChartRowItem;
import vn.mog.ewallet.intergration.contract.store.bean.PieChartItem;
import vn.mog.ewallet.intergration.contract.store.bean.StoreNotfInfo;
import vn.mog.ewallet.web.contract.CardStatus;
import vn.mog.ewallet.web.contract.Stage;
import vn.mog.ewallet.SharedConstants;
import vn.mog.ewallet.common.util.JsonUtil;
import vn.mog.ewallet.common.util.NumberUtil;
import vn.mog.ewallet.web.controller.AbstractController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
public class DashBoardController extends AbstractController {

	private static final Logger log = Logger.getLogger(DashBoardController.class);

	private static final String CARD_INPUTTED = "cardInputted";
	private static final String CARD_SOLD = "cardSold";
	private static final String CARD_ACTIVATE = "cardActivate";
	private static final String CARD_DEACTIVATE = "cardDeactivate";
	private static final String CARD_EXPIRED = "cardExpired";
	private static final String CARD_PRE_EXPIRED = "cardPreExpired";

	private static final String TEN = "10000";
	private static final String TWENTY = "20000";
	private static final String THIRTY = "30000";
	private static final String FIFTY = "50000";
	private static final String HUNDRED = "100000";
	private static final String TWO_HUNDRED = "200000";
	private static final String THREE_HUNDRED = "300000";
	private static final String FIVE_HUNDRED = "500000";
	private static final String ONE_MINION = "1000000";
	private static final String TWO_MINION = "2000000";


	private static final String NUMBER = "number";
	private static final String VALUE = "value";
	private static final String CAPITAL = "capital";

	@RequestMapping(
					value = "/dashboard/cardstore",
					method = RequestMethod.GET)
	public String login(HttpServletRequest request, HttpServletResponse response, ModelMap model) throws Exception {
		if (!checkLogin(request)) {
			return "redirect:/login";
		}

		/*String urlValidateCross = validateCrossAccessKey(request);
		if (StringUtils.isNotEmpty(urlValidateCross)) {
			return urlValidateCross;
		}*/

		model.put("cardTypes", cardStoreService.listType());
		model.put("cardProviders", cardStoreService.listProvider());
		model.put("nearExpDays", SharedConstants.NEAR_EXP_DAYS);

		return "dashboard/cardstore";
	}

	@RequestMapping(
					value = "/dashboard/statistic",
					method = RequestMethod.POST,
					produces = MediaType.APPLICATION_JSON_VALUE,
					consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String statisticDashboard(
					@RequestBody GetCardDashBoardRequest dashboardRequest,
					@RequestParam("daterange") String daterange,
					HttpServletRequest request, HttpServletResponse response) throws Exception {

		JSONObject jDashboard = new JSONObject();
		if (daterange != null && daterange.compareTo("null") != 0 && StringUtils.isNotEmpty(daterange)) {
			DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			String[] range = daterange.split("-");
			Date fromDate = df.parse(StringUtils.trimToEmpty(range[0]));
			Date endDate = df.parse(StringUtils.trimToEmpty(range[1]));
			dashboardRequest.setFromDate(fromDate);
			dashboardRequest.setEndDate(endDate);
		}

		long startRequest = new Date().getTime();
		GetCardDashBoardResponse dashBoardResponse = cardStoreService.getCardDashBoard(dashboardRequest);
		Map<String, Map<Integer, StoreNotfInfo>> warningLevelResult = dashBoardResponse.getWarningLevelResult();
		if (warningLevelResult == null) { warningLevelResult = new HashMap<>(); }
		long endResponse = new Date().getTime();
		if (dashBoardResponse.getCardDashBoardItems() != null) {
			chartFollowStatus(dashBoardResponse.getCardDashBoardItems(), jDashboard);
			chartFollowCardType(dashBoardResponse.getCardDashBoardItems(), warningLevelResult, jDashboard);
		}
		long calulateTime = new Date().getTime();
		log.debug("time request---" + (endResponse - startRequest));
		log.debug("time caculator-" + (calulateTime - endResponse));

		return jDashboard.toString();
	}

	/**
	 * chartFollowStatus
	 * */
	private void chartFollowStatus(List<CardDashBoardItem> items, JSONObject jDashboard) {

		HashMap<String, JSONObject> hashMap = sumCountData(items);

		jDashboard.put(CARD_INPUTTED, hashMap.get(CARD_INPUTTED));
		jDashboard.put(CARD_SOLD, hashMap.get(CARD_SOLD));
		jDashboard.put(CARD_ACTIVATE, hashMap.get(CARD_ACTIVATE));
		jDashboard.put(CARD_DEACTIVATE, hashMap.get(CARD_DEACTIVATE));
		jDashboard.put(CARD_EXPIRED, hashMap.get(CARD_EXPIRED));
		jDashboard.put(CARD_PRE_EXPIRED, hashMap.get(CARD_PRE_EXPIRED));

		List<PieChartItem> pieNumbers = new ArrayList<>();
		pieNumbers.add(new PieChartItem("Sold", hashMap.get(CARD_SOLD).getLong(NUMBER)));//Thẻ đã bán
		pieNumbers.add(new PieChartItem("Active", hashMap.get(CARD_ACTIVATE).getLong(NUMBER)));//Thẻ còn tồn
		pieNumbers.add(new PieChartItem("Inactive", hashMap.get(CARD_DEACTIVATE).getLong(NUMBER)));//Thẻ còn tồn

		jDashboard.put("pieDataNumberCards", JsonUtil.objectToJson(pieNumbers));


		List<PieChartItem> pieValues = new ArrayList<>();
		pieValues.add(new PieChartItem("Sold", hashMap.get(CARD_SOLD).getLong(VALUE)));//Thẻ đã bán
		pieValues.add(new PieChartItem("Active", hashMap.get(CARD_ACTIVATE).getLong(VALUE)));//Thẻ còn tồn
		pieValues.add(new PieChartItem("Inactive", hashMap.get(CARD_DEACTIVATE).getLong(VALUE)));//Thẻ còn tồn

		jDashboard.put("pieDataFaceValues", JsonUtil.objectToJson(pieValues));
	}


	/**
	 * chartFollowCardType
	 * */
	private void chartFollowCardType(List<CardDashBoardItem> itemTables, Map<String, Map<Integer, StoreNotfInfo>> warningLevelResult, JSONObject jsonDashboard) {

		HashMap<String, List<CardDashBoardItem>> rawData = new HashMap<>();

		//sort by Card Type
		for (CardDashBoardItem item : itemTables) {
			if (rawData.containsKey(item.getCardType().name)) {
				List<CardDashBoardItem> chartRowItems = rawData.get(item.getCardType().name);
				chartRowItems.add(item);
				rawData.put(item.getCardType().name, chartRowItems);
			} else {
				List<CardDashBoardItem> rowItems = new ArrayList<>();
				rowItems.add(item);
				rawData.put(item.getCardType().name, rowItems);
			}
		}

		//summary card type
		HashMap<String, List<CardSummaryWarning>> cardSumaryWarning = new HashMap<>();

		//sum value && count
		HashMap<String, List<ChartRowItem>> chartDataStatict = new HashMap<>();

		ChartRowItem chartRowItem;
		CardSummaryWarning cardSummaryWarning;

		for (Map.Entry<String, List<CardDashBoardItem>> rawItem : rawData.entrySet()) {
			String cardType = rawItem.getKey();
			HashMap<String, JSONObject> hashCardType = caculatorByFacevalue(rawItem.getValue());

			List<ChartRowItem> chartRowItems = new ArrayList<>();
			List<CardSummaryWarning> cardSummaryWarnings = new ArrayList<>();

			Set<String> faceValueExistSet = new HashSet<>();
			for (Map.Entry<String, JSONObject> item : hashCardType.entrySet()) {
				JSONObject sumValueCard = item.getValue();
				chartRowItem = new ChartRowItem(rawItem.getKey(), item.getKey(),
								sumValueCard.isNull(CARD_INPUTTED) ? 0L : sumValueCard.getLong(CARD_INPUTTED),
								sumValueCard.isNull(CARD_SOLD) ? 0L : sumValueCard.getLong(CARD_SOLD),
								sumValueCard.isNull(CARD_ACTIVATE) ? 0L : sumValueCard.getLong(CARD_ACTIVATE),
								sumValueCard.isNull(CARD_DEACTIVATE) ? 0L : sumValueCard.getLong(CARD_DEACTIVATE),
								sumValueCard.isNull(CARD_PRE_EXPIRED) ? 0L : sumValueCard.getLong(CARD_PRE_EXPIRED),
								sumValueCard.isNull(CARD_EXPIRED) ? 0L : sumValueCard.getLong(CARD_EXPIRED));

				//TODO tinh mưc cảnh bảo here
				String faceValue = chartRowItem.getFaceValue();
				faceValueExistSet.add(faceValue);
				long level = checkCardWarning(cardType, NumberUtil.convertToInt(faceValue), warningLevelResult);
				chartRowItem.setLeverWarning(level);

				chartRowItems.add(chartRowItem);

				cardSummaryWarning = new CardSummaryWarning(NumberUtil.formatNumber(faceValue), level);
				cardSummaryWarnings.add(cardSummaryWarning);
			}

			chartRowItems.addAll(initDefaultCharRowItem(faceValueExistSet, cardType, warningLevelResult));

			chartDataStatict.put(cardType, chartRowItems);
			cardSumaryWarning.put(cardType, cardSummaryWarnings);
		}


		jsonDashboard.put("cardSumaryWarning", JsonUtil.objectToJson(cardSumaryWarning));
		jsonDashboard.put("cardRowItemes", JsonUtil.objectToJson(chartDataStatict));
	}

	/**
	 * Khởi tạo giá trị default theo card type
	 * */
	private List<ChartRowItem> initDefaultCharRowItem(Set<String> faceValueExist, String cardType, Map<String, Map<Integer, StoreNotfInfo>> warningLevelResult) {
		List<ChartRowItem> initDefault = new ArrayList<>();
		if (!faceValueExist.contains(TEN)) {
			long level = checkCardWarning(cardType, NumberUtil.convertToInt(TEN), warningLevelResult);
			initDefault.add(new ChartRowItem(cardType, TEN, 0L, 0L, 0L, 0L, 0L, 0L, level));
		}

		if (!faceValueExist.contains(TWENTY)) {
			long level = checkCardWarning(cardType, NumberUtil.convertToInt(TWENTY), warningLevelResult);
			initDefault.add(new ChartRowItem(cardType, TWENTY, 0L, 0L, 0L, 0L, 0L, 0L, level));
		}

		if (!faceValueExist.contains(THIRTY)) {
			long level = checkCardWarning(cardType, NumberUtil.convertToInt(THIRTY), warningLevelResult);
			initDefault.add(new ChartRowItem(cardType, THIRTY, 0L, 0L, 0L, 0L, 0L, 0L, level));
		}

		if (!faceValueExist.contains(FIFTY)) {
			long level = checkCardWarning(cardType, NumberUtil.convertToInt(FIFTY), warningLevelResult);
			initDefault.add(new ChartRowItem(cardType, FIFTY, 0L, 0L, 0L, 0L, 0L, 0L, level));
		}

		if (!faceValueExist.contains(HUNDRED)) {
			long level = checkCardWarning(cardType, NumberUtil.convertToInt(HUNDRED), warningLevelResult);
			initDefault.add(new ChartRowItem(cardType, HUNDRED, 0L, 0L, 0L, 0L, 0L, 0L, level));
		}

		if (!faceValueExist.contains(TWO_HUNDRED)) {
			long level = checkCardWarning(cardType, NumberUtil.convertToInt(TWO_HUNDRED), warningLevelResult);
			initDefault.add(new ChartRowItem(cardType, TWO_HUNDRED, 0L, 0L, 0L, 0L, 0L, 0L, level));
		}

		if (!faceValueExist.contains(THREE_HUNDRED)) {
			long level = checkCardWarning(cardType, NumberUtil.convertToInt(THREE_HUNDRED), warningLevelResult);
			initDefault.add(new ChartRowItem(cardType, THREE_HUNDRED, 0L, 0L, 0L, 0L, 0L, 0L, level));
		}

		if (!faceValueExist.contains(FIVE_HUNDRED)) {
      long level = checkCardWarning(cardType, NumberUtil.convertToInt(FIVE_HUNDRED), warningLevelResult);
      initDefault.add(new ChartRowItem(cardType, FIVE_HUNDRED, 0L, 0L, 0L, 0L, 0L, 0L, level));
    }

    if (!faceValueExist.contains(ONE_MINION)) {
      long level = checkCardWarning(cardType, NumberUtil.convertToInt(ONE_MINION), warningLevelResult);
      initDefault.add(new ChartRowItem(cardType, ONE_MINION, 0L, 0L, 0L, 0L, 0L, 0L, level));
    }

    if (!faceValueExist.contains(TWO_MINION)) {
      long level = checkCardWarning(cardType, NumberUtil.convertToInt(TWO_MINION), warningLevelResult);
      initDefault.add(new ChartRowItem(cardType, TWO_MINION, 0L, 0L, 0L, 0L, 0L, 0L, level));
    }
		return initDefault;
	}

	private long checkCardWarning(String cardTypeWarning, Integer faceValue, Map<String, Map<Integer, StoreNotfInfo>> warningLevelResult) {
		if (warningLevelResult.containsKey(cardTypeWarning)) {
			Map<Integer, StoreNotfInfo> integerIntegerMap = warningLevelResult.get(cardTypeWarning);
			if (integerIntegerMap.containsKey(faceValue)) {
				StoreNotfInfo storeNotfInfo = integerIntegerMap.get(faceValue);
				return storeNotfInfo.getWarnLevel() + 1;
			}
		}
		return 0;
	}


	/**
	 * chartFollowCardType
	 * Tính toán tổng các Facevalue
	 * */
	private HashMap<String, JSONObject> caculatorByFacevalue(List<CardDashBoardItem> cardDashBoardItems) {
		HashMap<String, JSONObject> hashMapCardDashBoardItem = new HashMap<>();
		for (CardDashBoardItem itemCardType : cardDashBoardItems) {
			switch (itemCardType.getFaceValue()) {
				case 10000:
					if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.ON == itemCardType.getStage()) {
						sumFacevalue(hashMapCardDashBoardItem, TEN, CARD_ACTIVATE, itemCardType.getTotal());

					} else if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.OFF == itemCardType.getStage()) {
						sumFacevalue(hashMapCardDashBoardItem, TEN, CARD_DEACTIVATE, itemCardType.getTotal());

					} else if (CardStatus.SOLD.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, TEN, CARD_SOLD, itemCardType.getTotal());

					} else if (CardStatus.EXPIRED.code == itemCardType.getStatus().code) {

						sumFacevalue(hashMapCardDashBoardItem, TEN, CARD_EXPIRED, itemCardType.getTotal());

					} else if (CardStatus.NEAR_EXP.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, TEN, CARD_PRE_EXPIRED, itemCardType.getTotal());
					}
					break;
				case 20000:
					if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.ON == itemCardType.getStage()) {
						sumFacevalue(hashMapCardDashBoardItem, TWENTY, CARD_ACTIVATE, itemCardType.getTotal());

					} else if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.OFF == itemCardType.getStage()) {
						sumFacevalue(hashMapCardDashBoardItem, TWENTY, CARD_DEACTIVATE, itemCardType.getTotal());

					} else if (CardStatus.SOLD.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, TWENTY, CARD_SOLD, itemCardType.getTotal());

					} else if (CardStatus.EXPIRED.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, TWENTY, CARD_EXPIRED, itemCardType.getTotal());

					} else if (CardStatus.NEAR_EXP.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, TWENTY, CARD_PRE_EXPIRED, itemCardType.getTotal());
					}
					break;
				case 30000:
					if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.ON == itemCardType.getStage()) {
						sumFacevalue(hashMapCardDashBoardItem, THIRTY, CARD_ACTIVATE, itemCardType.getTotal());

					} else if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.OFF == itemCardType.getStage()) {
						sumFacevalue(hashMapCardDashBoardItem, THIRTY, CARD_DEACTIVATE, itemCardType.getTotal());

					} else if (CardStatus.SOLD.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, THIRTY, CARD_SOLD, itemCardType.getTotal());

					} else if (CardStatus.EXPIRED.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, THIRTY, CARD_EXPIRED, itemCardType.getTotal());

					} else if (CardStatus.NEAR_EXP.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, THIRTY, CARD_PRE_EXPIRED, itemCardType.getTotal());
					}
					break;
				case 50000:
					if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.ON == itemCardType.getStage()) {
						sumFacevalue(hashMapCardDashBoardItem, FIFTY, CARD_ACTIVATE, itemCardType.getTotal());

					} else if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.OFF == itemCardType.getStage()) {
						sumFacevalue(hashMapCardDashBoardItem, FIFTY, CARD_DEACTIVATE, itemCardType.getTotal());

					} else if (CardStatus.SOLD.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, FIFTY, CARD_SOLD, itemCardType.getTotal());

					} else if (CardStatus.EXPIRED.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, FIFTY, CARD_EXPIRED, itemCardType.getTotal());

					} else if (CardStatus.NEAR_EXP.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, FIFTY, CARD_PRE_EXPIRED, itemCardType.getTotal());
					}
					break;
				case 100000:
					if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.ON == itemCardType.getStage()) {
						sumFacevalue(hashMapCardDashBoardItem, HUNDRED, CARD_ACTIVATE, itemCardType.getTotal());

					} else if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.OFF == itemCardType.getStage()) {
						sumFacevalue(hashMapCardDashBoardItem, HUNDRED, CARD_DEACTIVATE, itemCardType.getTotal());

					} else if (CardStatus.SOLD.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, HUNDRED, CARD_SOLD, itemCardType.getTotal());

					} else if (CardStatus.EXPIRED.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, HUNDRED, CARD_EXPIRED, itemCardType.getTotal());

					} else if (CardStatus.NEAR_EXP.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, HUNDRED, CARD_PRE_EXPIRED, itemCardType.getTotal());
					}
					break;
				case 200000:
					if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.ON == itemCardType.getStage()) {
						sumFacevalue(hashMapCardDashBoardItem, TWO_HUNDRED, CARD_ACTIVATE, itemCardType.getTotal());

					} else if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.OFF == itemCardType.getStage()) {
						sumFacevalue(hashMapCardDashBoardItem, TWO_HUNDRED, CARD_DEACTIVATE, itemCardType.getTotal());

					} else if (CardStatus.SOLD.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, TWO_HUNDRED, CARD_SOLD, itemCardType.getTotal());

					} else if (CardStatus.EXPIRED.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, TWO_HUNDRED, CARD_EXPIRED, itemCardType.getTotal());

					} else if (CardStatus.NEAR_EXP.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, TWO_HUNDRED, CARD_PRE_EXPIRED, itemCardType.getTotal());
					}
					break;
				case 300000:
					if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.ON == itemCardType.getStage()) {
						sumFacevalue(hashMapCardDashBoardItem, THREE_HUNDRED, CARD_ACTIVATE, itemCardType.getTotal());

					} else if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.OFF == itemCardType.getStage()) {
						sumFacevalue(hashMapCardDashBoardItem, THREE_HUNDRED, CARD_DEACTIVATE, itemCardType.getTotal());

					} else if (CardStatus.SOLD.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, THREE_HUNDRED, CARD_SOLD, itemCardType.getTotal());

					} else if (CardStatus.EXPIRED.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, THREE_HUNDRED, CARD_EXPIRED, itemCardType.getTotal());

					} else if (CardStatus.NEAR_EXP.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, THREE_HUNDRED, CARD_PRE_EXPIRED, itemCardType.getTotal());
					}
					break;
				case 500000:
					if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.ON == itemCardType.getStage()) {
						sumFacevalue(hashMapCardDashBoardItem, FIVE_HUNDRED, CARD_ACTIVATE, itemCardType.getTotal());

					} else if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.OFF == itemCardType.getStage()) {
						sumFacevalue(hashMapCardDashBoardItem, FIVE_HUNDRED, CARD_DEACTIVATE, itemCardType.getTotal());

					} else if (CardStatus.SOLD.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, FIVE_HUNDRED, CARD_SOLD, itemCardType.getTotal());

					} else if (CardStatus.EXPIRED.code == itemCardType.getStatus().code) {
						sumFacevalue(hashMapCardDashBoardItem, FIVE_HUNDRED, CARD_EXPIRED, itemCardType.getTotal());

					} else if (CardStatus.NEAR_EXP.code == itemCardType.getStatus().code) {

						sumFacevalue(hashMapCardDashBoardItem, FIVE_HUNDRED, CARD_PRE_EXPIRED, itemCardType.getTotal());
					}
					break;

        case 1000000:
          if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.ON == itemCardType.getStage()) {
            sumFacevalue(hashMapCardDashBoardItem, ONE_MINION, CARD_ACTIVATE, itemCardType.getTotal());

          } else if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.OFF == itemCardType.getStage()) {
            sumFacevalue(hashMapCardDashBoardItem, ONE_MINION, CARD_DEACTIVATE, itemCardType.getTotal());

          } else if (CardStatus.SOLD.code == itemCardType.getStatus().code) {
            sumFacevalue(hashMapCardDashBoardItem, ONE_MINION, CARD_SOLD, itemCardType.getTotal());

          } else if (CardStatus.EXPIRED.code == itemCardType.getStatus().code) {
            sumFacevalue(hashMapCardDashBoardItem, ONE_MINION, CARD_EXPIRED, itemCardType.getTotal());

          } else if (CardStatus.NEAR_EXP.code == itemCardType.getStatus().code) {

            sumFacevalue(hashMapCardDashBoardItem, ONE_MINION, CARD_PRE_EXPIRED, itemCardType.getTotal());
          }
          break;

        case 2000000:
          if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.ON == itemCardType.getStage()) {
            sumFacevalue(hashMapCardDashBoardItem, TWO_MINION, CARD_ACTIVATE, itemCardType.getTotal());

          } else if (CardStatus.IN_STOCK.code == itemCardType.getStatus().code && Stage.OFF == itemCardType.getStage()) {
            sumFacevalue(hashMapCardDashBoardItem, TWO_MINION, CARD_DEACTIVATE, itemCardType.getTotal());

          } else if (CardStatus.SOLD.code == itemCardType.getStatus().code) {
            sumFacevalue(hashMapCardDashBoardItem, TWO_MINION, CARD_SOLD, itemCardType.getTotal());

          } else if (CardStatus.EXPIRED.code == itemCardType.getStatus().code) {
            sumFacevalue(hashMapCardDashBoardItem, TWO_MINION, CARD_EXPIRED, itemCardType.getTotal());

          } else if (CardStatus.NEAR_EXP.code == itemCardType.getStatus().code) {

            sumFacevalue(hashMapCardDashBoardItem, TWO_MINION, CARD_PRE_EXPIRED, itemCardType.getTotal());
          }
          break;
				default:
					break;
			}
		}

		for (Map.Entry<String, JSONObject> item : hashMapCardDashBoardItem.entrySet()) {
			JSONObject value = item.getValue();
			value.put(CARD_INPUTTED, (value.isNull(CARD_SOLD) ? 0L : value.getLong(CARD_SOLD)) +
															 (value.isNull(CARD_ACTIVATE) ? 0L : value.getLong(CARD_ACTIVATE)) +
															 (value.isNull(CARD_DEACTIVATE) ? 0L : value.getLong(CARD_DEACTIVATE)));
			hashMapCardDashBoardItem.put(item.getKey(), value);
		}

		return hashMapCardDashBoardItem;
	}

	private void sumFacevalue(HashMap<String, JSONObject> hashMap, String faceValue, String cardType, long total) {
		if (hashMap.containsKey(faceValue)) {
			JSONObject jFaceValue = hashMap.get(faceValue);
			if (jFaceValue.isNull(cardType)) {
				jFaceValue.put(cardType, total);
			} else {
				long aLong = jFaceValue.getLong(cardType);
				aLong += total;
				jFaceValue.put(cardType, aLong);
			}
			hashMap.put(faceValue, jFaceValue);
		} else {
			JSONObject jCardType = new JSONObject();
			jCardType.put(cardType, total);
			hashMap.put(faceValue, jCardType);
		}
	}

	/**
	 * chartFollowStatus
	 * đếm số lượng thẻ, INPUT CARD	, ... trên 1 face value, trên 1nhà mạng
	 * trong màn hình tổng quát, hàng 1
	 * */
	private HashMap<String, JSONObject> sumCountData(List<CardDashBoardItem> items) {

		HashMap<String, JSONObject> hashMap = new HashMap<>();

		Long numberSold = 0L;
		Long valueSold = 0L;
		Long capitalSold = 0L;

		Long numberActivate = 0L;
		Long valueActivate = 0L;
		Long capitalActivate = 0L;

		Long numberDeactivate = 0L;
		Long valueDeactivate = 0L;
		Long capitalDeactivate = 0L;

		Long numberNearExpired = 0L;
		Long valueNearExpired = 0L;
		Long capitalNearExpired = 0L;

		Long numberExpired = 0L;
		Long valueExpired = 0L;
		Long capitalExpired = 0L;


		for (CardDashBoardItem item : items) {
			if (CardStatus.IN_STOCK.code == item.getStatus().code && Stage.ON == item.getStage()) {
				numberActivate += item.getTotal();
				valueActivate += item.getFaceValue() * item.getTotal();
				capitalActivate += item.getCapital();

			} else if (CardStatus.IN_STOCK.code == item.getStatus().code && Stage.OFF == item.getStage()) {
				numberDeactivate += item.getTotal();
				valueDeactivate += item.getFaceValue() * item.getTotal();
				capitalDeactivate += item.getCapital();

			} else if (CardStatus.SOLD.code == item.getStatus().code) {
				numberSold += item.getTotal();
				valueSold += item.getFaceValue() * item.getTotal();
				capitalSold += item.getCapital();

			} else if (CardStatus.EXPIRED.code == item.getStatus().code) {
				numberExpired += item.getTotal();
				valueExpired += item.getFaceValue() * item.getTotal();
				capitalExpired += item.getCapital();

			} else if (CardStatus.NEAR_EXP.code == item.getStatus().code) {
				numberNearExpired += item.getTotal();
				valueNearExpired += item.getFaceValue() * item.getTotal();
				capitalNearExpired += item.getCapital();
			}
		}
		Long numberInputted = numberActivate + numberDeactivate + numberSold;
		Long valueInputted = valueActivate + valueDeactivate + valueSold;
		Long capitalInputted = capitalActivate + capitalDeactivate + capitalSold;

		JSONObject cardInputted = new JSONObject();
		cardInputted.put(NUMBER, numberInputted);
		cardInputted.put(VALUE, valueInputted);
		cardInputted.put(CAPITAL, capitalInputted);

		JSONObject cardSold = new JSONObject();
		cardSold.put(NUMBER, numberSold);
		cardSold.put(VALUE, valueSold);
		cardSold.put(CAPITAL, capitalSold);

		JSONObject cardActivate = new JSONObject();
		cardActivate.put(NUMBER, numberActivate);
		cardActivate.put(VALUE, valueActivate);
		cardActivate.put(CAPITAL, capitalActivate);

		JSONObject cardDeactivate = new JSONObject();
		cardDeactivate.put(NUMBER, numberDeactivate);
		cardDeactivate.put(VALUE, valueDeactivate);
		cardDeactivate.put(CAPITAL, capitalDeactivate);

		JSONObject cardExpired = new JSONObject();
		cardExpired.put(NUMBER, numberExpired);
		cardExpired.put(VALUE, valueExpired);
		cardExpired.put(CAPITAL, capitalExpired);

		JSONObject cardPreExpired = new JSONObject();
		cardPreExpired.put(NUMBER, numberNearExpired);
		cardPreExpired.put(VALUE, valueNearExpired);
		cardPreExpired.put(CAPITAL, capitalNearExpired);

		hashMap.put(CARD_INPUTTED, cardInputted);
		hashMap.put(CARD_SOLD, cardSold);
		hashMap.put(CARD_ACTIVATE, cardActivate);
		hashMap.put(CARD_DEACTIVATE, cardDeactivate);
		hashMap.put(CARD_EXPIRED, cardExpired);
		hashMap.put(CARD_PRE_EXPIRED, cardPreExpired);
//		log.debug("cardPreExpired--" + cardExpired.toString());
		return hashMap;

	}
}
