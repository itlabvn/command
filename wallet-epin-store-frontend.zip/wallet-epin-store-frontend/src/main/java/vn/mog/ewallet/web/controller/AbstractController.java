package vn.mog.ewallet.web.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import vn.mog.ewallet.SharedConstants;
import vn.mog.ewallet.api.rest.ICardStoreService;
import vn.mog.ewallet.api.rest.ISecurityService;
import vn.mog.ewallet.api.rest.ITopupService;
import vn.mog.ewallet.common.util.HmacSHA256;
import vn.mog.ewallet.common.util.HttpUtil;
import vn.mog.ewallet.common.util.NumberUtil;
import vn.mog.ewallet.intergration.contract.security.bean.Role;
import vn.mog.ewallet.intergration.contract.security.bean.User;
import vn.mog.ewallet.intergration.contract.store.GetUserRequest;
import vn.mog.ewallet.intergration.contract.store.GetUserResponse;
import vn.mog.ewallet.intergration.contract.topup.CustomerResponse;
import vn.mog.ewallet.web.contract.UserInfo;
import vn.mog.ewallet.web.taglib.WalletTagLib;


public abstract class AbstractController {

  private static final Logger log = Logger.getLogger(AbstractController.class);

  protected static UserInfo userInfo = new UserInfo(0);

  public static final String REDIRECT_LOGOUT = "redirect:/logout";
  public static final String REDIRECT_LOGOIN = "redirect:/login";

  @Autowired
  protected ICardStoreService cardStoreService;

  @Autowired
  protected ITopupService topupService;

  @Autowired
  protected ISecurityService securityService;


  protected User account;


  protected boolean checkLogin(HttpServletRequest request) {
    //account = (User)request.getSession().getAttribute("account_logined");
    String accessToken = request.getParameter("accessToken");
    if (StringUtils.isBlank(accessToken)) {
      accessToken = (String) request.getSession().getAttribute("access_token");
    }
    if (StringUtils.isNotBlank(accessToken)) {
      request.getSession().setAttribute("access_token", accessToken);
      request.setAttribute("accessToken", accessToken);

      try {
        GetUserResponse getUserResponse = cardStoreService.getUser(new GetUserRequest());
        if (getUserResponse.getUser() != null) {
          request.getSession().setAttribute("account_logined", getUserResponse.getUser());
          account = getUserResponse.getUser();
          request.setAttribute("account", account);

          setUserInfo(request);
          return true;
        } else {
          return false;
        }
      } catch (Exception e) {
        log.error("checkLogin----" , e);
        return false;
      }
    } else {
      return false;
    }
  }

  protected void setUserInfo(HttpServletRequest request) {
    String customerType = "";
    try {
      long balance = topupService.getBalance();
      AbstractController.userInfo.setBalance(balance);
      request.setAttribute("userInfo", userInfo);
      CustomerResponse userInfo = getUserInfo();
      customerType = userInfo.getCustomerType();
      request.setAttribute("userInfoDetail", userInfo);

      String menu = request.getParameter("menu");
      request.setAttribute("menu", menu);
      if (StringUtils.isNotEmpty(menu)) {
        HttpUtil.getCurrentHttpServletRequest().getSession().setAttribute("menu", menu);
      }

    } catch (Exception e) {
      log.error("CustomerType--" + customerType, e);
    }
  }

  protected CustomerResponse getUserInfo() {
    try {
      String username = account.getUsername();
      return topupService.findCustomer(username, null, null, null);
    } catch (Exception e) {
      log.error("getUserInfo", e);
    }
    return null;
  }

  //@formatter:off
  public static String redirectRole(HttpServletRequest request) {

    User account = (User) request.getAttribute("account");
    Collection<Role> roles = account.getRoles();
    Set<String> setRoles = new HashSet<>();
    for (Role item : roles) {
      setRoles.add(item.getName());
    }

    String accessToken = (String) HttpUtil.getCurrentHttpServletRequest().getSession().getAttribute("access_token");
    boolean isStaff = setRoles.contains("ROLE_ADMIN") || setRoles.contains("ROLE_FINANCE") || setRoles.contains("ROLE_FINANCE_SUPPORT_STAFF") || setRoles.contains("ROLE_SALE_MANAGER");
    boolean isMerchant = setRoles.contains("ROLE_MERCHANT");
    boolean isCustomer = setRoles.contains("ROLE_CUSTOMER");
    boolean isSaleSupport = setRoles.contains("ROLE_SALE_SUPPORT") || setRoles.contains("ROLE_SALE_SUPPORT_MANAGER") || setRoles .contains("ROLE_SALE_SUPPORT_STAFF");
    boolean isReconciliation = setRoles.contains("ROLE_RECONCILIATION") || setRoles.contains("ROLE_RECONCILIATION_MANAGER") || setRoles.contains("ROLE_RECONCILIATION_STAFF");
    boolean isBussiness = setRoles.contains("ROLE_CUSTOMER_CARE") || setRoles.contains("ROLE_SALE") || isReconciliation || setRoles.contains("ROLE_TECH_SUPPORT");

    if (isStaff || isMerchant) {
      String urlSignature = WalletTagLib.isSignature(SharedConstants.TOPUP_WEB_BASE_REQUEST_URL + "/dashboard/index", accessToken);
      return urlSignature + "&menu=all";

    } else if (isCustomer || isBussiness) {
      String urlSignature = WalletTagLib.isSignature(SharedConstants.TOPUP_WEB_BASE_REQUEST_URL + "/transaction/list", accessToken);
      return urlSignature + "&menu=all";

    } else if (isSaleSupport) {
      return request.getContextPath() + "/dashboard/cardstore?menu=all";

    } else {
      String urlSignature = WalletTagLib.isSignature(SharedConstants.TOPUP_WEB_BASE_REQUEST_URL + "/dashboard/index", accessToken);
      return urlSignature + "&menu=all";
    }
  }

  //@formatter:off
  protected boolean validateChecksum(HttpServletRequest request) {
    String signature = request.getParameter("signature");
    String accessToken = request.getParameter("accessToken");
    String expiredTime = request.getParameter(SharedConstants.EXPIRED_TIME);

    HmacSHA256 hmacSHA256 = HmacSHA256.getInstance(SharedConstants.CHECKSUM_SECRET_SIGNATURE);

    String data = SharedConstants.ACCESS_TOKEN + "=" + accessToken + "&" + SharedConstants.EXPIRED_TIME + "=" + expiredTime;
    String signatureValidate = hmacSHA256.sign(data);
    long timeNow = new Date().getTime();
    long timeExpired = NumberUtil.convertToLong(expiredTime) + SharedConstants.CHECKSUM_EXPIRED_TIME * 1000;

    boolean isValidateTime = timeExpired > timeNow;
    if (signatureValidate.equalsIgnoreCase(signature) && isValidateTime) {
      return true;
    }
    return false;
  }

  protected String validateCrossAccessKey(HttpServletRequest request) {
    String accessToken = request.getParameter("accessToken");
    if (StringUtils.isNotEmpty(accessToken)) {
      String signature = request.getParameter("signature");
      if (StringUtils.isEmpty(signature)) {
        return "redirect:/error";
      }
      if (StringUtils.isNotEmpty(signature) && !validateChecksum(request)) {
        return "redirect:/logout";
      }
    }
    return StringUtils.EMPTY;
  }
  //@formatter:on

  protected Date[] parseSearchRange(String dateRange) {
    try {
      if (StringUtils.isNotBlank(dateRange)) {
        String[] range = dateRange.split("-");
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date fromDate = df.parse(StringUtils.trimToEmpty(range[0]));
        Date endDate = df.parse(StringUtils.trimToEmpty(range[1]));
        return new Date[]{fromDate, endDate};
      }
    } catch (Exception e) {
      log.error(e.getMessage(), e);
    }
    return new Date[]{null, null};
  }
}
