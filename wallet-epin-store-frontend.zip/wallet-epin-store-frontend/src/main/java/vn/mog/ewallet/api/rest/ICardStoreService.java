package vn.mog.ewallet.api.rest;

import java.util.List;
import vn.mog.ewallet.intergration.contract.store.ChangePurchaseOrderStatusRequest;
import vn.mog.ewallet.intergration.contract.store.ChangePurchaseOrderStatusResponse;
import vn.mog.ewallet.intergration.contract.store.CreateAttachmentRequest;
import vn.mog.ewallet.intergration.contract.store.CreateAttachmentResponse;
import vn.mog.ewallet.intergration.contract.store.CreateFullPurchaseOrderRequest;
import vn.mog.ewallet.intergration.contract.store.CreateFullPurchaseOrderResponse;
import vn.mog.ewallet.intergration.contract.store.FindCardRequest;
import vn.mog.ewallet.intergration.contract.store.FindCardResponse;
import vn.mog.ewallet.intergration.contract.store.FindProviderProfileRequest;
import vn.mog.ewallet.intergration.contract.store.FindProviderProfileResponse;
import vn.mog.ewallet.intergration.contract.store.FindPurchaseOrderRequest;
import vn.mog.ewallet.intergration.contract.store.FindPurchaseOrderResponse;
import vn.mog.ewallet.intergration.contract.store.GetCardDashBoardRequest;
import vn.mog.ewallet.intergration.contract.store.GetCardDashBoardResponse;
import vn.mog.ewallet.intergration.contract.store.GetPurchaseOrderRequest;
import vn.mog.ewallet.intergration.contract.store.GetPurchaseOrderResponse;
import vn.mog.ewallet.intergration.contract.store.GetUserRequest;
import vn.mog.ewallet.intergration.contract.store.GetUserResponse;
import vn.mog.ewallet.intergration.contract.store.UpdatePurchaseOrderRequest;
import vn.mog.ewallet.intergration.contract.store.UpdatePurchaseOrderResponse;
import vn.mog.ewallet.intergration.contract.store.VerifyPurchaseOrderFileRequest;
import vn.mog.ewallet.intergration.contract.store.VerifyPurchaseOrderFileResponse;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowApproveRequest;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowApproveResponse;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowRejectRequest;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowRejectResponse;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowStartProcessRequest;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowStartProcessResponse;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowSubmitProcessRequest;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowSubmitProcessResponse;
import vn.mog.ewallet.web.contract.CardProvider;
import vn.mog.ewallet.web.contract.CardStatus;
import vn.mog.ewallet.web.contract.CardType;
import vn.mog.ewallet.web.contract.PurchaseOrderStatus;
import vn.mog.ewallet.web.contract.Stage;
import vn.mog.ewallet.exception.StoreFrontException;

public interface ICardStoreService {

  CreateFullPurchaseOrderResponse createFullPurchaseOrder(CreateFullPurchaseOrderRequest request)
      throws StoreFrontException;

  UpdatePurchaseOrderResponse updatePurchaseOrder(UpdatePurchaseOrderRequest request)
      throws StoreFrontException;

  CreateAttachmentResponse updatePurchaseOrderAttachment(CreateAttachmentRequest request)
      throws StoreFrontException;

  ChangePurchaseOrderStatusResponse updatePurchaseOrderStatus(ChangePurchaseOrderStatusRequest request)
      throws StoreFrontException;

  FindPurchaseOrderResponse findPurchaseOrders(FindPurchaseOrderRequest request)
      throws StoreFrontException;

  VerifyPurchaseOrderFileResponse verifyPurchaseOrderFile(VerifyPurchaseOrderFileRequest request)
      throws StoreFrontException;

  PurchaseOrderFlowApproveResponse verifyPOApprove(PurchaseOrderFlowApproveRequest request)
      throws StoreFrontException;

  PurchaseOrderFlowRejectResponse verifyPOReject(PurchaseOrderFlowRejectRequest request)
      throws StoreFrontException;

  List<CardProvider> listProvider() throws StoreFrontException;

  List<CardType> listType() throws StoreFrontException;

  List<CardStatus> listCardStatus() throws StoreFrontException;

  List<Stage> listStage() throws StoreFrontException;

  GetPurchaseOrderResponse getPurchaseOrder(GetPurchaseOrderRequest request) throws StoreFrontException;

  FindCardResponse findCards(FindCardRequest request) throws StoreFrontException;

  PurchaseOrderFlowStartProcessResponse startPurchaseOrder(PurchaseOrderFlowStartProcessRequest request)
      throws StoreFrontException;

  PurchaseOrderFlowSubmitProcessResponse submitPurchaseOrder(PurchaseOrderFlowSubmitProcessRequest request)
      throws StoreFrontException;

  GetCardDashBoardResponse getCardDashBoard(GetCardDashBoardRequest request) throws StoreFrontException;

  GetUserResponse getUser(GetUserRequest request) throws StoreFrontException;

  List<PurchaseOrderStatus> listPOStatus() throws StoreFrontException;

  FindProviderProfileResponse findProviderProfiles(FindProviderProfileRequest request) throws StoreFrontException;
}
