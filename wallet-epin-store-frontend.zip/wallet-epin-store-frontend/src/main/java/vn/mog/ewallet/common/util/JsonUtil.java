package vn.mog.ewallet.common.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.jboss.logging.Logger;

/**
 * Created by binhminh on 06/12/2016.
 */
public class JsonUtil {

  private static Logger log = Logger.getLogger(JsonUtil.class);
  protected static ObjectMapper objectMapper = new ObjectMapper();

  public static String objectToJson(Object obj) {
    try {
      return objectMapper.writeValueAsString(obj);
    } catch (JsonProcessingException e) {
      log.error("objectToJson", e);
    }
    return null;
  }
}
