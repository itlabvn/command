package vn.mog.ewallet.web.taglib;

import java.util.Date;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.i18n.LocaleContextHolder;
import vn.mog.ewallet.SharedConstants;
import vn.mog.ewallet.common.util.HmacSHA256;
import vn.mog.ewallet.common.util.NumberUtil;
import vn.mog.ewallet.common.util.StringUtil;
import vn.mog.ewallet.common.util.Utils;

public class WalletTagLib {

  public static String numberToText(String number) {
    try {
      String langLocal = LocaleContextHolder.getLocale().getLanguage();
      if (langLocal.equals("vi")) {
        return Utils.numberToText(number);
      } else {
        number = number.replaceAll("\\D+", "");
        return Utils.numberToTextEn(NumberUtil.convertToLong(number));
      }
    } catch (Exception ex) {
      return number;
    }
  }

  public static String formatNumber(String number) {
    try {
      Long numberL = NumberUtil.convertToLong(number);
      return NumberUtil.formatNumber(numberL);
    } catch (Exception ex) {
      return StringUtils.EMPTY;
    }
  }

  public static String isSignature(String url, String accessToken) {
    try {
      HmacSHA256 hmacSHA256 = HmacSHA256.getInstance(SharedConstants.CHECKSUM_SECRET_SIGNATURE);
      long timeNow = new Date().getTime();
      String data =
          SharedConstants.ACCESS_TOKEN + "=" + accessToken + "&" + SharedConstants.EXPIRED_TIME + "=" + timeNow;
      String signature = hmacSHA256.sign(data);
      if (url.contains(StringUtil.QUESTION_MARK)) {
        return url + "&accessToken=" + accessToken + "&"+SharedConstants.EXPIRED_TIME+"=" + timeNow + "&signature=" + signature;
      } else {
        return url + "?accessToken=" + accessToken + "&"+SharedConstants.EXPIRED_TIME+"=" + timeNow + "&signature=" + signature;
      }

    } catch (Exception e) {
      return url;
    }
  }

}
