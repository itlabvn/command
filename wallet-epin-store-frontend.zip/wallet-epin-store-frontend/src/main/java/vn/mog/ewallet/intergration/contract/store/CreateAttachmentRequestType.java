package vn.mog.ewallet.intergration.contract.store;

import java.io.Serializable;
import java.util.List;

import vn.mog.framework.contract.base.MobiliserRequestType;
import vn.mog.ewallet.intergration.contract.store.bean.Attachment;

@SuppressWarnings("serial")
public class CreateAttachmentRequestType extends MobiliserRequestType implements Serializable {

	protected List<Attachment> attachment;
	protected String note;

	public List<Attachment> getAttachment() {
		return attachment;
	}

	public void setAttachment(List<Attachment> attachment) {
		this.attachment = attachment;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}
}
