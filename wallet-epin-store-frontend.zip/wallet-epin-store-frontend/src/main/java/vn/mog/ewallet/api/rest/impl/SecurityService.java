package vn.mog.ewallet.api.rest.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import vn.mog.ewallet.intergration.contract.security.LogoutRequest;
import vn.mog.ewallet.intergration.contract.security.LogoutResponse;
import vn.mog.ewallet.api.client.SecurityAPIClient;
import vn.mog.ewallet.api.rest.ISecurityService;

@Service
public class SecurityService implements ISecurityService {

  @Autowired
  SecurityAPIClient securityAPIClient;

  @Override
  public void logout() throws Exception {
    securityAPIClient.callRequest("/api/security/logout", new LogoutRequest(), LogoutResponse.class);
  }

}
