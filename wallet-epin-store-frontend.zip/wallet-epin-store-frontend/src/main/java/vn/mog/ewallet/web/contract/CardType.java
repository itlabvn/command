package vn.mog.ewallet.web.contract;


public enum CardType {

	VIETTEL("VTM", "VIETTEL"),
	MOBIFONE("VMS", "MOBIFONE"),
	VINAPHONE("VNP", "VINAPHONE"),
	VNMOBILE("VNM", "VNMOBILE"),
	GATE("GATE", "GATE"),
	GMOBILE("GMOBILE", "GMOBILE"), // TelCard
	VCOIN("VCOIN", "VCOIN"),
	ZING("ZING", "ZING"),
	GARENA("GARENA", "GARENA"),
	ONCASH("ONCASH", "ONCASH"),
	VINPLAY("VINPLAY","VINPLAY"); // GameCard

	public String code;
	public String name;

	private CardType(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public static CardType getCardType(String label) {
		for (CardType cardType : CardType.values()) {
			if (cardType.name().equalsIgnoreCase(label) || cardType.code.equalsIgnoreCase(label) || cardType.name.equalsIgnoreCase(label))
				return cardType;
		}
		return null;
	}

//	@Override
	/*public String toString() {
		return name;
	}*/

	public static void main(String[] args) {
		System.out.println(getCardType("VTM"));
	}

	public String getName() {
		return name;
	}
	public String getCode() {
		return code;
	}
}
