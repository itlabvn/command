package vn.mog.ewallet.intergration.contract.store.follow;

public class PurchaseOrderFlowProcessRequest extends PurchaseOrderFlowSubmitProcessRequestType {

}
