package vn.mog.ewallet.intergration.contract.store;

import vn.mog.framework.contract.base.MobiliserResponseType;
import vn.mog.ewallet.intergration.contract.store.bean.PurchaseOrderItem;

@SuppressWarnings("serial")
public class GetPurchaseOrderResponseType extends MobiliserResponseType {

  protected PurchaseOrderItem purchaseOrder;

  public PurchaseOrderItem getPurchaseOrder() {
    return purchaseOrder;
  }

  public void setPurchaseOrder(PurchaseOrderItem purchaseOrder) {
    this.purchaseOrder = purchaseOrder;
  }

}
