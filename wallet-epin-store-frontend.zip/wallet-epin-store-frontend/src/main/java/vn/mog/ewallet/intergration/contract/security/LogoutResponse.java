package vn.mog.ewallet.intergration.contract.security;

import vn.mog.ewallet.intergration.contract.store.ResponseType;

import java.io.Serializable;

public class LogoutResponse extends ResponseType implements Serializable {
	
	protected boolean signedOut;

	public boolean isSignedOut() {
		return signedOut;
	}

	public void setSignedOut(boolean signedOut) {
		this.signedOut = signedOut;
	}
}
