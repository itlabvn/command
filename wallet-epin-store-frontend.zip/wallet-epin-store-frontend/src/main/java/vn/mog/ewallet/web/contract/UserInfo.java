package vn.mog.ewallet.web.contract;

public class UserInfo {
	private long balance;
	
	public UserInfo() {
	}
	public UserInfo(long balance) {
		this.balance = balance;
	}
	public long getBalance() {
		return balance;
	}
	
	public void setBalance(long balance) {
		this.balance = balance;
	}
}
