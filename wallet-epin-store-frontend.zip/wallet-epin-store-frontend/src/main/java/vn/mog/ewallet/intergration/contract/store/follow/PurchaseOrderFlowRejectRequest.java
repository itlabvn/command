package vn.mog.ewallet.intergration.contract.store.follow;

import java.io.Serializable;

public class PurchaseOrderFlowRejectRequest extends PurchaseOrderFlowRejectRequestType implements Serializable {
}
