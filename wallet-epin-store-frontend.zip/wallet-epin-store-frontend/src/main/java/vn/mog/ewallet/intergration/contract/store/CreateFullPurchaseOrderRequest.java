package vn.mog.ewallet.intergration.contract.store;

import java.io.Serializable;

@SuppressWarnings("serial")
public class CreateFullPurchaseOrderRequest extends CreateFullPurchaseOrderRequestType implements
    Serializable {

}
