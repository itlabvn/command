package vn.mog.ewallet.intergration.contract.store;

@SuppressWarnings("serial")
public class FindProviderProfileRequest extends FindProviderProfileRequestType {

}
