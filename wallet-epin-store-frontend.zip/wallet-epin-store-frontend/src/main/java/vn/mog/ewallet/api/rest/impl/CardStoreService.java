package vn.mog.ewallet.api.rest.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import vn.mog.ewallet.api.rest.ICardStoreService;
import vn.mog.ewallet.intergration.contract.store.ChangePurchaseOrderStatusRequest;
import vn.mog.ewallet.intergration.contract.store.ChangePurchaseOrderStatusResponse;
import vn.mog.ewallet.intergration.contract.store.CreateAttachmentRequest;
import vn.mog.ewallet.intergration.contract.store.CreateAttachmentResponse;
import vn.mog.ewallet.intergration.contract.store.CreateFullPurchaseOrderRequest;
import vn.mog.ewallet.intergration.contract.store.CreateFullPurchaseOrderResponse;
import vn.mog.ewallet.intergration.contract.store.FindCardRequest;
import vn.mog.ewallet.intergration.contract.store.FindCardResponse;
import vn.mog.ewallet.intergration.contract.store.FindProviderProfileRequest;
import vn.mog.ewallet.intergration.contract.store.FindProviderProfileResponse;
import vn.mog.ewallet.intergration.contract.store.FindPurchaseOrderRequest;
import vn.mog.ewallet.intergration.contract.store.FindPurchaseOrderResponse;
import vn.mog.ewallet.intergration.contract.store.GetCardDashBoardRequest;
import vn.mog.ewallet.intergration.contract.store.GetCardDashBoardResponse;
import vn.mog.ewallet.intergration.contract.store.GetPurchaseOrderRequest;
import vn.mog.ewallet.intergration.contract.store.GetPurchaseOrderResponse;
import vn.mog.ewallet.intergration.contract.store.GetUserRequest;
import vn.mog.ewallet.intergration.contract.store.GetUserResponse;
import vn.mog.ewallet.intergration.contract.store.UpdatePurchaseOrderRequest;
import vn.mog.ewallet.intergration.contract.store.UpdatePurchaseOrderResponse;
import vn.mog.ewallet.intergration.contract.store.VerifyPurchaseOrderFileRequest;
import vn.mog.ewallet.intergration.contract.store.VerifyPurchaseOrderFileResponse;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowApproveRequest;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowApproveResponse;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowRejectRequest;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowRejectResponse;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowStartProcessRequest;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowStartProcessResponse;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowSubmitProcessRequest;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowSubmitProcessResponse;
import vn.mog.ewallet.web.contract.CardProvider;
import vn.mog.ewallet.web.contract.CardStatus;
import vn.mog.ewallet.web.contract.CardType;
import vn.mog.ewallet.web.contract.PurchaseOrderStatus;
import vn.mog.ewallet.web.contract.Stage;
import vn.mog.ewallet.api.client.CardStoreAPIClient;
import vn.mog.ewallet.exception.StoreFrontException;

@Service
public class CardStoreService implements ICardStoreService {

  @Autowired
  CardStoreAPIClient cardAPIClient;

  @Override
  public CreateFullPurchaseOrderResponse createFullPurchaseOrder(CreateFullPurchaseOrderRequest request)
      throws StoreFrontException {
    return (CreateFullPurchaseOrderResponse) cardAPIClient
        .callRequest("/api/createFullPurchaseorder", request, CreateFullPurchaseOrderResponse.class);
  }

  @Override
  public UpdatePurchaseOrderResponse updatePurchaseOrder(UpdatePurchaseOrderRequest request)
      throws StoreFrontException {
    return (UpdatePurchaseOrderResponse) cardAPIClient
        .callRequest("/api/updatePurchaseorder", request, UpdatePurchaseOrderResponse.class);
  }

  @Override
  public CreateAttachmentResponse updatePurchaseOrderAttachment(CreateAttachmentRequest request)
      throws StoreFrontException {
    return (CreateAttachmentResponse) cardAPIClient
        .callRequest("/api/createAttachment", request, CreateAttachmentResponse.class);
  }

  @Override
  public ChangePurchaseOrderStatusResponse updatePurchaseOrderStatus(ChangePurchaseOrderStatusRequest request)
      throws StoreFrontException {
    return (ChangePurchaseOrderStatusResponse) cardAPIClient
        .callRequest("/api/changePurchaseOrderStatus", request, ChangePurchaseOrderStatusResponse.class);
  }

  @Override
  public FindPurchaseOrderResponse findPurchaseOrders(FindPurchaseOrderRequest request)
      throws StoreFrontException {
    return (FindPurchaseOrderResponse) cardAPIClient
        .callRequest("/api/findPurchaseOrders", request, FindPurchaseOrderResponse.class);
  }

  @Override
  public VerifyPurchaseOrderFileResponse verifyPurchaseOrderFile(
      VerifyPurchaseOrderFileRequest request) throws StoreFrontException {

    return (VerifyPurchaseOrderFileResponse) cardAPIClient
        .callRequest("/api/verifyPurchaseOrderFile", request, VerifyPurchaseOrderFileResponse.class);
  }

  @Override
  public List<CardProvider> listProvider() throws StoreFrontException {
    return (List<CardProvider>) cardAPIClient.callRequest("/api/listProvider", null, List.class);
  }

  @Override
  public List<CardType> listType() throws StoreFrontException {
    return (List<CardType>) cardAPIClient.callRequest("/api/listOperator", null, List.class);
  }

  @Override
  public List<CardStatus> listCardStatus() throws StoreFrontException {
    return (List<CardStatus>) cardAPIClient.callRequest("/api/listCardStatus", null, List.class);
  }

  @Override
  public List<Stage> listStage() throws StoreFrontException {
    return (List<Stage>) cardAPIClient.callRequest("/api/listWorkflowState", null, List.class);
  }

  @Override
  public GetPurchaseOrderResponse getPurchaseOrder(GetPurchaseOrderRequest request)
      throws StoreFrontException {
    return (GetPurchaseOrderResponse) cardAPIClient
        .callRequest("/api/getPurchaseOrder", request, GetPurchaseOrderResponse.class);
  }

  @Override
  public FindCardResponse findCards(FindCardRequest request)
      throws StoreFrontException {
    return (FindCardResponse) cardAPIClient.callRequest("/api/findCard", request, FindCardResponse.class);
  }

  @Override
  public PurchaseOrderFlowSubmitProcessResponse submitPurchaseOrder(PurchaseOrderFlowSubmitProcessRequest request)
      throws StoreFrontException {
    return (PurchaseOrderFlowSubmitProcessResponse) cardAPIClient
        .callRequest("/api/workflows/purchaseOrder/submit", request, PurchaseOrderFlowSubmitProcessResponse.class);
  }

  @Override
  public PurchaseOrderFlowStartProcessResponse startPurchaseOrder(
      PurchaseOrderFlowStartProcessRequest request)
      throws StoreFrontException {
    return (PurchaseOrderFlowStartProcessResponse) cardAPIClient
        .callRequest("/api/workflows/purchaseOrder/startProcess", request, PurchaseOrderFlowStartProcessResponse.class);
  }

  @Override
  public GetCardDashBoardResponse getCardDashBoard(GetCardDashBoardRequest request) throws StoreFrontException {
    return (GetCardDashBoardResponse) cardAPIClient
        .callRequest("/api/getCardDashBoard", request, GetCardDashBoardResponse.class);
  }

  @Override
  public PurchaseOrderFlowApproveResponse verifyPOApprove(
      PurchaseOrderFlowApproveRequest request) throws StoreFrontException {
    return (PurchaseOrderFlowApproveResponse) cardAPIClient
        .callRequest("/api/workflows/purchaseOrder/approve", request, PurchaseOrderFlowApproveResponse.class);
  }

  @Override
  public PurchaseOrderFlowRejectResponse verifyPOReject(
      PurchaseOrderFlowRejectRequest request) throws StoreFrontException {
    return (PurchaseOrderFlowRejectResponse) cardAPIClient
        .callRequest("/api/workflows/purchaseOrder/reject", request, PurchaseOrderFlowRejectResponse.class);
  }

  @Override
  public GetUserResponse getUser(GetUserRequest request) throws StoreFrontException {
    return (GetUserResponse) cardAPIClient.callRequest("/api/getUser", request, GetUserResponse.class);
  }

  @Override
  public List<PurchaseOrderStatus> listPOStatus() throws StoreFrontException {
    return (List<PurchaseOrderStatus>) cardAPIClient.callRequest("/api/listPOStatus", null, List.class);
  }

  @Override
  public FindProviderProfileResponse findProviderProfiles(
      FindProviderProfileRequest request) throws StoreFrontException {
    return (FindProviderProfileResponse) cardAPIClient
        .callRequest("/api/findProviderProfiles", request, FindProviderProfileResponse.class);
  }
}
