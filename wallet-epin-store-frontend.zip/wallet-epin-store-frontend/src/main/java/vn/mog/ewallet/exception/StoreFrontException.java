package vn.mog.ewallet.exception;

public class StoreFrontException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer errorCode;
	private String errorMessage;
	private String source;
	
	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}
	
	public StoreFrontException(Integer errorCode, String errorMessage){
		this.setErrorCode(errorCode);
		this.setErrorMessage(errorMessage);
	}

	public StoreFrontException(Integer errorCode, String source,  String errorMessage){
		this.setErrorCode(errorCode);
		this.setSource(source);
		this.setErrorMessage(errorMessage);
	}

	public Integer getErrorCode(){
		return errorCode;
	}

	public String getErrorMessage(){
		return errorMessage;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setErrorCode(Integer newVal){
		errorCode = newVal;
	}

	/**
	 * 
	 * @param newVal
	 */
	public void setErrorMessage(String newVal){
		errorMessage = newVal;
	}

}