package vn.mog.ewallet;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class SharedConstants {

  public static String CARD_STORE_CORE_BASE_REQUEST_URL = StringUtils.EMPTY;
	
	@Value("${param.ref.card.core.base.url}")
	public void setCardStoreCoreBaseUrl(String value) {
		CARD_STORE_CORE_BASE_REQUEST_URL = value;
	}
	
	public static String TOPUP_CORE_BASE_REQUEST_URL = StringUtils.EMPTY;
	
	@Value("${param.ref.core.base.url}")
	public void setTopupCoreBaseUrl(String value) {
		TOPUP_CORE_BASE_REQUEST_URL = value;
	}
	
	public static String TOPUP_WEB_BASE_REQUEST_URL = StringUtils.EMPTY;
	
	@Value("${param.ref.web.base.url}")
	public void setTopupWebBaseUrl(String value) {
		TOPUP_WEB_BASE_REQUEST_URL = value;
	}
	
	public static String UPLOAD_FOLDER = "/home/hp/upload";
	public static String INQUIRY_FOLDER = "/home/hp/upload/inquiries";
	
	@Value("${param.system.upload}")
	public void setUploadFolder(String value) {
		UPLOAD_FOLDER = value;
	}
	
	@Value("${param.system.upload.inquiry}")
	public void setInquiryFolder(String value) {
		INQUIRY_FOLDER = UPLOAD_FOLDER + value;
	}
	
	public static String DOWNLOAD_HOST = "http://localhost:8080/files";
	public static String DOWNLOAD_INQUIRY_HOST = "http://localhost:8080/files/inquiries";
	
	@Value("${param.system.download}")
	public void setDownloadHost(String value) {
		DOWNLOAD_HOST = value;
	}
	
	@Value("${param.system.download.inquiry}")
	public void setDownloadInquiry(String value) {
		DOWNLOAD_INQUIRY_HOST = DOWNLOAD_HOST + value;
	}

	// CARD DASHBOARD
	public static int NEAR_EXP_DAYS = 15;

	@Value("${param.card.dashboard.near.expiration.days}")
	public void setCardDashBoardNearExpDays(int value) {
		NEAR_EXP_DAYS = value;
	}

	public static String AUTH_WEB_BASE_REQUEST_URL = StringUtils.EMPTY;
	@Value("${param.ref.auther.web.base.url}")
	public void setAuthWebBaseUrl(String value) {AUTH_WEB_BASE_REQUEST_URL = value;}

	public static String AUTH_SERVER_BASE_REQUEST_URL = StringUtils.EMPTY;
	@Value("${param.ref.auther.server.base.url}")
	public void setAuthServerBaseUrl(String value) {AUTH_SERVER_BASE_REQUEST_URL = value;}

	//Checksum signature
	public static String CHECKSUM_SECRET_SIGNATURE = StringUtils.EMPTY;
	public static Integer CHECKSUM_EXPIRED_TIME = 0;

	@Value("${checksum.secret.signature}")
	public void setChecksumSecretSignature(String value) {
		CHECKSUM_SECRET_SIGNATURE = value;
	}

	@Value("${checksum.expired.time}")
	public void setChecksumExpiredtime(Integer value) {
		CHECKSUM_EXPIRED_TIME = value;
	}

	public static String EXPIRED_TIME = "expired_time";
	public static String ACCESS_TOKEN = "access_token";
}
