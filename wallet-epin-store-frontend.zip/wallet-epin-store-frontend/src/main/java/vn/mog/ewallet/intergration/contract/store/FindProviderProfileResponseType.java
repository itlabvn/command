package vn.mog.ewallet.intergration.contract.store;

import java.util.Collection;

import vn.mog.framework.contract.base.MobiliserResponseType;
import vn.mog.ewallet.web.contract.ProviderProfile;

@SuppressWarnings("serial")
public class FindProviderProfileResponseType extends MobiliserResponseType {
	
	private Collection<ProviderProfile> providerProfiles;

	public Collection<ProviderProfile> getProviderProfiles() {
		return providerProfiles;
	}

	public void setProviderProfiles(Collection<ProviderProfile> providerProfiles) {
		this.providerProfiles = providerProfiles;
	}
}
