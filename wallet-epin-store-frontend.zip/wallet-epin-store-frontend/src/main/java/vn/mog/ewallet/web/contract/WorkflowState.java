package vn.mog.ewallet.web.contract;

public enum WorkflowState {

	INIT(0, "Declared"), REJECTED(1, "Rejected"), READY_TO_VERIFY(2, "Wait approve"), CONFIRMED(4, "Approved");

	public int code;
	public String displayText;

	private WorkflowState(int value, String displayText) {
		this.code = value;
		this.displayText = displayText;
	}

	public int value() {
		return this.code;
	}

	public String displayText() {
		return this.displayText;
	}

	public static WorkflowState getWorkFlowState(int value) {
		for (WorkflowState state : WorkflowState.values()) {
			if (state.code == value) {
				return state;
			}
		}
		return null;
	}
}
