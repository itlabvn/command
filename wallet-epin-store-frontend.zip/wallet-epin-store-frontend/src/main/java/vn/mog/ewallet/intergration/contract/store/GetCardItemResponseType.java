package vn.mog.ewallet.intergration.contract.store;

import vn.mog.ewallet.intergration.contract.store.bean.CardItem;
import vn.mog.framework.contract.base.MobiliserResponseType;

@SuppressWarnings("serial")
public class GetCardItemResponseType extends MobiliserResponseType {

  protected CardItem cardItem;

  public CardItem getCardItem() {
    return cardItem;
  }

  public void setCardItem(CardItem cardItem) {
    this.cardItem = cardItem;
  }
}
