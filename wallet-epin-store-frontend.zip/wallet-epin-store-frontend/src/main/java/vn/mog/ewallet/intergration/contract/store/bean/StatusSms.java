package vn.mog.ewallet.intergration.contract.store.bean;

public class StatusSms {
  private int status;
  private String sms;

  public int getStatus() {
    return status;
  }

  public void setStatus(int status) {
    this.status = status;
  }

  public String getSms() {
    return sms;
  }

  public void setSms(String sms) {
    this.sms = sms;
  }

}
