package vn.mog.ewallet.web.contract;

public enum PurchaseOrderStatus {

	INACTIVE(0), ACTIVE(1), NA(2);

	public int code;

	private PurchaseOrderStatus(int value) {
		this.code = value;
	}

	public static PurchaseOrderStatus getByValue(String value) {
		for (PurchaseOrderStatus item : PurchaseOrderStatus.values()) {
			if (value.equalsIgnoreCase(String.valueOf(item.code)))
				return item;
		}
		return null;
	}

}
