package vn.mog.ewallet.api.rest.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import vn.mog.ewallet.api.rest.ITopupService;
import vn.mog.framework.contract.base.MobiliserRequestType;
import vn.mog.ewallet.intergration.contract.topup.CustomerRequest;
import vn.mog.ewallet.intergration.contract.topup.CustomerResponse;
import vn.mog.ewallet.api.client.TopupAPIClient;
import vn.mog.ewallet.exception.StoreFrontException;

@Service
public class TopupService implements ITopupService {

	@Autowired
	TopupAPIClient topupAPIClient;
	
	@Override
	public CustomerResponse findCustomer(String username, String cif, String email, String phone) throws StoreFrontException {
		CustomerRequest request = new CustomerRequest();
		request.setUsername(username);
		request.setCif(cif);
		request.setEmail(email);
		request.setMsisdn(phone);
		
		return (CustomerResponse) topupAPIClient.callRequest("/api/customer/findCustomer", request, CustomerResponse.class);
	}
	
	@Override
	public long getBalance() throws StoreFrontException {
		MobiliserRequestType request = new MobiliserRequestType();
		return (long)topupAPIClient.callRequest("/api/customer/getBalance", request, Long.class);
	}
}
