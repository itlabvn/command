package vn.mog.ewallet.intergration.contract.store.follow;

import vn.mog.framework.contract.base.MobiliserResponseType;

import java.io.Serializable;

public class PurchaseOrderFlowRejectResponseType extends MobiliserResponseType implements Serializable {
    protected Long purchaseOrderId;

    public Long getPurchaseOrderId() {
	return purchaseOrderId;
    }

    public void setPurchaseOrderId(Long purchaseOrderId) {
	this.purchaseOrderId = purchaseOrderId;
    }
}
