package vn.mog.ewallet.intergration.contract.store.follow;

import java.io.Serializable;

public class GetPurchaseOrderFlowResponse extends GetPurchaseOrderFlowResponseType implements Serializable {

}
