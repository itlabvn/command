package vn.mog.ewallet.exception;


public class NotAuthorizedException extends SecurityException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NotAuthorizedException(int errorCode, String errorMessage) {
		super(errorCode, errorMessage);
	}
	
	public NotAuthorizedException(int errorCode, String source,  String errorMessage) {
		super(errorCode, source, errorMessage);
	}
}
