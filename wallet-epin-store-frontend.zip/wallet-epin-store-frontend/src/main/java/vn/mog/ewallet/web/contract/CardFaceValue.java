package vn.mog.ewallet.web.contract;

/**
 * Created by binhminh on 28/12/2016.
 */
public enum CardFaceValue {
	TEN(10000, "10.000"),
	TWENTY(20000, "20.000"),
	THIRTY(30000, "30.000"),
	FIFTY(50000, "50.000"),
	HUNDRED(100000, "100.000"),
	TWO_HUNDRED(200000, "200.000"),
	THREE_HUNDRED(300000, "300.000"),
	FIVE_HUNDRED(500000, "500.000"),
	ONE_MILLION(1000000, "1.000.000"),
	TWO_MILLION(2000000, "2.000.000");

	public int code;
	public String name;

	private CardFaceValue(int code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public Integer getCode() {
		return code;
	}
}
