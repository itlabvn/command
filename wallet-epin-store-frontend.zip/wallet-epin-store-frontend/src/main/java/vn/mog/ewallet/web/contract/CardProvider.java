package vn.mog.ewallet.web.contract;

public enum  CardProvider {
	VIETTEL(1, "Viettel Telecom"),
	VNPAY(2, "VnPay JSC"),
	VNTP(3, "Vinatopup"),
	EPAY(4, "EPAY JSC"),
	VTC(5, "VTC Intecom"),
	ESALE(6, "ESALE"),
	TRUEMONEY(8, "TrueMoney VietNam JSC"),
	MOBIFONE(9, "Mobifone"),
    VINPLAY(10, "Vinplay");
  
  // Why is CardProvider frontend different from CardProvider backend ?

	public int code;
	public String name;

	private CardProvider(int code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getName() {
		return name;
	}
	public Integer getCode() {
		return code;
	}

}
