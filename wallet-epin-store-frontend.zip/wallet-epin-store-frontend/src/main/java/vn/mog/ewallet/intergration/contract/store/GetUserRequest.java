package vn.mog.ewallet.intergration.contract.store;

import java.io.Serializable;

public class GetUserRequest extends RequestType implements Serializable {
	protected String username;
	protected Long userId;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

}
