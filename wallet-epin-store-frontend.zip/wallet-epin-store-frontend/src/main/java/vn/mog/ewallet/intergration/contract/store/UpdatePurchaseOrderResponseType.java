package vn.mog.ewallet.intergration.contract.store;

import vn.mog.framework.contract.base.MobiliserResponseType;

@SuppressWarnings("serial")
public class UpdatePurchaseOrderResponseType extends MobiliserResponseType {

}
