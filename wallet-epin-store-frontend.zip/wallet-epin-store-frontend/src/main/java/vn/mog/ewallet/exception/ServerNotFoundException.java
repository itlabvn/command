package vn.mog.ewallet.exception;


public class ServerNotFoundException extends ErrorException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ServerNotFoundException(int errorCode, String errorMessage) {
		super(errorCode, errorMessage);
	}
	
	public ServerNotFoundException(int errorCode, String source,  String errorMessage) {
		super(errorCode, source, errorMessage);
	}
}
