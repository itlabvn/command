package vn.mog.ewallet.intergration.contract.store.follow;

import java.io.Serializable;

public class PurchaseOrderFlowApproveResponse extends PurchaseOrderFlowApproveResponseType implements Serializable {

}
