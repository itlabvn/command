package vn.mog.ewallet.common.util;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Enumeration;

public class SessionUtil {

	private static final Logger log = LoggerFactory.getLogger(SessionUtil.class);

	public final static String ACCOUNT_LOGINED = "account_logined";
	public final static String ACCOUNT_SESSION_LOGINED = "account_session_logined";

	/***
	 * Xóa session
	 * */
	public static void cleanSession(HttpServletRequest request) {
		try {
			HttpSession session = request.getSession();
			Enumeration<?> attrNames = session.getAttributeNames();
			while (attrNames.hasMoreElements()) {
				session.removeAttribute((String) attrNames.nextElement());
			}
			request.getSession().invalidate();
		} catch (Exception e) {
			log.error("cleanSession", e);
		}
	}

	public static void setSession(HttpServletRequest request, Object object) {
		try {
			if (object != null) {
				setObjectToSession(request, object);
			}
		} catch (Exception e) {
			log.error("setSession", e);
		}
	}

	public static Object getObjectFromSession(HttpServletRequest request, String name) {
		try {
			if (name != null && StringUtils.isNotEmpty(name)) {
				return request.getSession().getAttribute(name);
			}
		} catch (Exception e) {
			log.error("getObjectFromSession", e);
		}
		return null;
	}

	public static void setObjectToSession(HttpServletRequest request, Object obj) {
		try {
			request.getSession().setAttribute(ACCOUNT_SESSION_LOGINED, obj);
		} catch (Exception e) {
			log.error("setObjectToSession", e);
		}
	}

	public static boolean hasSession(HttpServletRequest request, String sessionName) {
		try {
			HttpSession session = (HttpSession) request.getSession();
			String name = StringUtils.trimToEmpty(sessionName);
			if (StringUtils.isNotBlank(name) && session.getAttribute(name) != null) {
				return true;
			}
		} catch (Exception e) {
			log.error("hasSession", e);
		}
		return false;
	}

}
