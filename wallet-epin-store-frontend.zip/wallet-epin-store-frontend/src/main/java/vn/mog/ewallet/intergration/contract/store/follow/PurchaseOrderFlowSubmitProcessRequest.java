package vn.mog.ewallet.intergration.contract.store.follow;

public class PurchaseOrderFlowSubmitProcessRequest extends PurchaseOrderFlowSubmitProcessRequestType {

}
