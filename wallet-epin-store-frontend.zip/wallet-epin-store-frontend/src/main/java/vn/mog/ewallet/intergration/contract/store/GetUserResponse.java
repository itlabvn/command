package vn.mog.ewallet.intergration.contract.store;

import java.io.Serializable;

import vn.mog.ewallet.intergration.contract.security.bean.User;

public class GetUserResponse extends ResponseType implements Serializable {
	protected User user;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
}
