package vn.mog.ewallet.web.controller.store;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import vn.mog.ewallet.exception.StoreFrontException;
import vn.mog.ewallet.intergration.contract.store.FindCardRequest;
import vn.mog.ewallet.intergration.contract.store.FindCardResponse;
import vn.mog.ewallet.intergration.contract.store.bean.CardItem;
import vn.mog.ewallet.web.contract.RolesType;
import vn.mog.ewallet.web.controller.AbstractController;

@Controller
@RequestMapping(value = "/card-store")
public class CardController extends AbstractController {

	private static final Logger log = LoggerFactory.getLogger(CardController.class);

	public Integer[] listAmount = {10000, 20000, 30000, 50000, 100000, 200000, 300000, 500000, 1000000, 2000000};

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String cardManagerStore(HttpServletRequest request, ModelMap model) throws StoreFrontException {
		boolean isNotLogin = !checkLogin(request);

		boolean hasNotAnyRoles = account != null && !account
				.hasAnyRoles(RolesType.ADMIN,
						RolesType.FINANCE, RolesType.FINANCE_SUPPORT_STAFF,
						RolesType.SALE_SUPPORT, RolesType.SALE_SUPPORT_MANAGER, RolesType.SALE_SUPPORT_STAFF,
						RolesType.SALE_MANAGER,
						RolesType.RECONCILIATION, RolesType.RECONCILIATION_MANAGER,
						RolesType.CUSTOMER_CARE);

		if (isNotLogin && hasNotAnyRoles) {
			return REDIRECT_LOGOIN;
		}

		//todo role

		model.put("listTelcos", cardStoreService.listProvider());
		model.put("listAmount", Arrays.asList(listAmount));
		model.put("listStatus", cardStoreService.listCardStatus());
		model.put("cardTypes", cardStoreService.listType());

		Long total = 0L;
		Integer offset = 0;
		Integer limit = 10;
		if (request.getParameter("d-49520-p") != null) {
			Integer p = Integer.parseInt(request.getParameter("d-49520-p"));
			offset = limit * (p - 1);
		}

		FindCardRequest requestCard = new FindCardRequest();

		String searchRange = request.getParameter("range");
		Date[] dates = parseSearchRange(searchRange);
		requestCard.setFromDate(dates[0]);
		requestCard.setEndDate(dates[1]);

		int[] faceValues = ServletRequestUtils.getIntParameters(request, "faceValues");
		String[] status = request.getParameterValues("status");
		String[] stages = request.getParameterValues("stages");
		String[] cardType = request.getParameterValues("cardTypes");

		if (faceValues != null && faceValues.length > 0 && faceValues[0] > 0) {
			requestCard.setFaceValues(Arrays.asList(ArrayUtils.toObject(faceValues)));
		}

		if (status != null && status.length > 0 && !status[0].equals(StringUtils.EMPTY)) {
			requestCard.setStatus(Arrays.asList(status));
		}

		if (stages != null && stages.length > 0 && !stages[0].equals(StringUtils.EMPTY)) {
			requestCard.setStages(Arrays.asList(stages));
		}

		if (cardType != null && cardType.length > 0 && !cardType[0].equals(StringUtils.EMPTY)) {
			requestCard.setTypes(Arrays.asList(cardType));
		}

		requestCard.setOrderBy(new String[]{"creationDate"});
		requestCard.setDesc(new boolean[]{true});

		String quickSearch = StringUtils.trimToNull(request.getParameter("search"));
		requestCard.setQuickSearch(quickSearch);
		requestCard.setOffset(offset);
		requestCard.setLimit(limit);

		Collection<CardItem> listCard = new ArrayList<>();
		FindCardResponse responseCard = cardStoreService.findCards(requestCard);
		long sumOfmoney = 0;
		long sumOfcapital = 0;
		if (responseCard.getStatus().getCode() == 0) {
			listCard = responseCard.getCards();
			total = responseCard.getCount();
			sumOfmoney = responseCard.getAmount();
			sumOfcapital = responseCard.getCapital();
		}

		model.put("pagesize", limit);
		model.put("offset", offset);
		model.put("list", listCard);
		model.put("total", total.intValue());
		model.put("sumOfmoney", sumOfmoney);
		model.put("sumOfcapital", sumOfcapital);
		model.put("search", StringUtils.trimToNull(quickSearch));

		return "card-store/list";
	}

}
