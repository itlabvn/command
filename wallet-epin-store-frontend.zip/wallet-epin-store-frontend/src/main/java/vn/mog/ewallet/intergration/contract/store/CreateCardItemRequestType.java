package vn.mog.ewallet.intergration.contract.store;

import vn.mog.ewallet.intergration.contract.store.bean.CardItem;
import vn.mog.framework.contract.base.MobiliserRequestType;

@SuppressWarnings("serial")
public class CreateCardItemRequestType extends MobiliserRequestType {
  protected CardItem cardItem;

  public CardItem getCardItem() {
    return cardItem;
  }

  public void setCardItem(CardItem cardItem) {
    this.cardItem = cardItem;
  }
}
