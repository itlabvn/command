package vn.mog.ewallet.intergration.contract.store.follow;

import java.io.Serializable;

public class PurchaseOrderFlowStartProcessResponse extends PurchaseOrderFlowStartProcessResponseType implements Serializable {

}
