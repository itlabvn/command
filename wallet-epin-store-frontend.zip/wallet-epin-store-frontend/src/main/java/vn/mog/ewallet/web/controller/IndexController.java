package vn.mog.ewallet.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import vn.mog.ewallet.SharedConstants;
import vn.mog.ewallet.common.util.HttpUtil;
import vn.mog.ewallet.web.taglib.WalletTagLib;

@Controller
public class IndexController extends AbstractController {

  @RequestMapping(value = "/")
  String index(HttpServletRequest request) {
    if (!checkLogin(request)) {
      return "redirect:/login";
    }
    return "redirect:/card-store/list";
  }

  @RequestMapping(value = "/error", method = RequestMethod.GET)
  public String error(HttpServletRequest request, HttpServletResponse response, ModelMap map) {
    String nav = request.getParameter("nav");
    map.put("nav", nav);
    return "config/error";
  }

  @RequestMapping(value = "/landing/customer", method = RequestMethod.GET)
  @PreAuthorize("hasAnyRole('STAFF','CUSTOMER','MERCHANT')")
  public String customer(HttpServletRequest request, ModelMap map) throws Exception {
    if (!checkLogin(request)) {
      return "redirect:/login";
    }
    String menu = request.getParameter("menu");
    map.put("menu", menu);
    request.setAttribute("menu", menu);
    if (StringUtils.isNotEmpty(menu)) {
      HttpUtil.getCurrentHttpServletRequest().getSession().setAttribute("menu", menu);
    }
    map.put("accessToken", (String) HttpUtil.getCurrentHttpServletRequest().getSession().getAttribute("access_token"));
    return "landing/customer";
  }

  @RequestMapping(value = "/landing/provider", method = RequestMethod.GET)
  @PreAuthorize("hasAnyRole('STAFF','CUSTOMER','MERCHANT')")
  public String provider(HttpServletRequest request, ModelMap map) throws Exception {
    if (!checkLogin(request)) {
      return "redirect:/login";
    }
    String menu = request.getParameter("menu");
    map.put("menu", menu);
    request.setAttribute("menu", menu);
    if (StringUtils.isNotEmpty(menu)) {
      HttpUtil.getCurrentHttpServletRequest().getSession().setAttribute("menu", menu);
    }
    map.put("accessToken", (String) HttpUtil.getCurrentHttpServletRequest().getSession().getAttribute("access_token"));
    return "landing/provider";
  }

  @RequestMapping(value = "/landing/service", method = RequestMethod.GET)
  @PreAuthorize("hasAnyRole('STAFF','CUSTOMER','MERCHANT')")
  public String service(HttpServletRequest request, ModelMap map) throws Exception {
    if (!checkLogin(request)) {
      return "redirect:/login";
    }
    String menu = request.getParameter("menu");
    map.put("menu", menu);
    request.setAttribute("menu", menu);
    if (StringUtils.isNotEmpty(menu)) {
      HttpUtil.getCurrentHttpServletRequest().getSession().setAttribute("menu", menu);
    }
    map.put("accessToken", (String) HttpUtil.getCurrentHttpServletRequest().getSession().getAttribute("access_token"));
    return "landing/service";
  }

  @RequestMapping(value = "/landing/setting", method = RequestMethod.GET)
  @PreAuthorize("hasAnyRole('STAFF','CUSTOMER','MERCHANT')")
  public String setting(HttpServletRequest request, ModelMap map) throws Exception {
    if (!checkLogin(request)) {
      return "redirect:/login";
    }
    String menu = request.getParameter("menu");
    map.put("menu", menu);
    request.setAttribute("menu", menu);
    if (StringUtils.isNotEmpty(menu)) {
      HttpUtil.getCurrentHttpServletRequest().getSession().setAttribute("menu", menu);
    }
    map.put("accessToken", (String) HttpUtil.getCurrentHttpServletRequest().getSession().getAttribute("access_token"));
    return "landing/setting";
  }

  @RequestMapping(value = "/landing/wallet", method = RequestMethod.GET)
  @PreAuthorize("hasAnyRole('STAFF','CUSTOMER','MERCHANT')")
  public String wallet(HttpServletRequest request, ModelMap map) throws Exception {
    if (!checkLogin(request)) {
      return "redirect:/login";
    }
    String menu = request.getParameter("menu");
    map.put("menu", menu);
    request.setAttribute("menu", menu);
    if (StringUtils.isNotEmpty(menu)) {
      HttpUtil.getCurrentHttpServletRequest().getSession().setAttribute("menu", menu);
    }
    map.put("accessToken", (String) HttpUtil.getCurrentHttpServletRequest().getSession().getAttribute("access_token"));
    return "landing/wallet";
  }
}
