package vn.mog.ewallet.intergration.contract.store;

@SuppressWarnings("serial")
public class FindProviderProfileResponse extends FindProviderProfileResponseType {

}
