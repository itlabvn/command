package vn.mog.ewallet.intergration.contract.store;

import vn.mog.framework.contract.base.MobiliserRequestType;
import vn.mog.ewallet.intergration.contract.store.bean.PurchaseOrderItem;

@SuppressWarnings("serial")
public class CreatePurchaseOrderRequestType extends MobiliserRequestType {
  protected PurchaseOrderItem purchaseOrder;
  protected boolean includePODetail;

  public boolean getIncludePODetail() {
    return includePODetail;
  }

  public boolean isIncludePODetail() {
    return includePODetail;
  }

  public void setIncludePODetail(boolean includePODetail) {
    this.includePODetail = includePODetail;
  }

  public PurchaseOrderItem getPurchaseOrder() {
    return purchaseOrder;
  }

  public void setPurchaseOrder(PurchaseOrderItem purchaseOrder) {
    this.purchaseOrder = purchaseOrder;
  }

}
