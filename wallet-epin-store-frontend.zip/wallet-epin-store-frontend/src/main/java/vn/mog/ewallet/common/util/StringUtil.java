package vn.mog.ewallet.common.util;

/**
 * Created by binhminh on 6/2/17.
 */
public class StringUtil {

  public static final String QUESTION_MARK = "?";
}
