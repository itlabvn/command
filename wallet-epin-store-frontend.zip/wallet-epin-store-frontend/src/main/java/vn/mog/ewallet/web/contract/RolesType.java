package vn.mog.ewallet.web.contract;

public class RolesType {

  /**
   * Management
   */
  public static final String SYSTEM = "ROLE_SYSTEM";//have not used*/
  public static final String ADMIN = "ROLE_ADMIN";
  public static final String TECH_SUPPORT = "ROLE_TECH_SUPPORT";

  /**
   * Merchant
   */
  public static final String MERCHANT = "ROLE_MERCHANT";
  /**
   * Customer
   */
  public static final String CUSTOMER = "ROLE_CUSTOMER";

  /**
   * Business
   */
  public static final String FINANCE = "ROLE_FINANCE";
  public static final String FINANCE_SUPPORT_MANAGER = "ROLE_FINANCE_SUPPORT_MANAGER";
  public static final String FINANCE_SUPPORT_STAFF = "ROLE_FINANCE_SUPPORT_STAFF";
  public static final String STAFF = "ROLE_STAFF";

  public static final String RECONCILIATION = "ROLE_RECONCILIATION";
  public static final String RECONCILIATION_MANAGER = "ROLE_RECONCILIATION_MANAGER";
  public static final String RECONCILIATION_STAFF = "ROLE_RECONCILIATION_STAFF";


  /**
   * Sale
   */
  public static final String SALE_MANAGER = "ROLE_SALE_MANAGER";
  public static final String SALE = "ROLE_SALE";

  public static final String SALE_SUPPORT = "ROLE_SALE_SUPPORT";
  public static final String SALE_SUPPORT_MANAGER = "ROLE_SALE_SUPPORT_MANAGER";
  public static final String SALE_SUPPORT_STAFF = "ROLE_SALE_SUPPORT_STAFF";

  public static final String CUSTOMER_CARE = "ROLE_CUSTOMER_CARE";
}
