package vn.mog.ewallet.exception;


public class InternalServerException extends ErrorException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InternalServerException(int errorCode, String errorMessage) {
		super(errorCode, errorMessage);
	}
	
	public InternalServerException(int errorCode, String source,  String errorMessage) {
		super(errorCode, source, errorMessage);
	}
}
