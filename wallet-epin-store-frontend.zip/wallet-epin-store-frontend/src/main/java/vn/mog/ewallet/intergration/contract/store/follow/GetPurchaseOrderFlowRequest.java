package vn.mog.ewallet.intergration.contract.store.follow;

import java.io.Serializable;

public class GetPurchaseOrderFlowRequest extends GetPurchaseOrderFlowRequestType implements Serializable{

}
