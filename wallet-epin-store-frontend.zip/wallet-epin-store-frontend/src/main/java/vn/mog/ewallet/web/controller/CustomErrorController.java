package vn.mog.ewallet.web.controller;

import org.springframework.boot.autoconfigure.web.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import vn.mog.ewallet.common.util.SessionUtil;
import vn.mog.ewallet.SharedConstants;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by binhminh on 18/02/2017.
 */

@Controller
public class CustomErrorController extends AbstractController implements ErrorController {

	private static final String PATH_ERROR = "/error";

	@RequestMapping(value = PATH_ERROR)
	public String error(HttpServletRequest request, HttpServletResponse response, ModelMap map) {
		if (!checkLogin(request))
			return "redirect:/login";

		if (HttpServletResponse.SC_UNAUTHORIZED == response.getStatus()) {
			SessionUtil.cleanSession(request);
			return SharedConstants.TOPUP_WEB_BASE_REQUEST_URL + "/logout.html";
		}

		return "redirect:/error";
	}

	@Override
	public String getErrorPath() {
		return PATH_ERROR;
	}
}
