package vn.mog.ewallet.exception;


public enum ErrorMessages {
	SUCCESS(0 , "Success!"),
	SUCCESS_VERIFY(100, "Process Verify successfullly"),


	ERROR(1 , "Unknown exception!"),
	ERROR_API(2 , "API Client exception!"),// API Client
	ERROR_SERVICE(3 , "Service Client exception!"),// Service Client
	;
	
	public String message; 
	public int code;
	ErrorMessages(int code, String message){
		this.code = code;
		this.message = message;
	}
	public static ErrorMessages parse(int code) {
		ErrorMessages status = null; // Default
        for (ErrorMessages item : ErrorMessages.values()) {
            if (item.code==code) {
            	status = item;
                break;
            }
        }
        return status;
    }
}
