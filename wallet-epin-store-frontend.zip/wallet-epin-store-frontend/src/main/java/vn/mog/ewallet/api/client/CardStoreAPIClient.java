package vn.mog.ewallet.api.client;

import org.jboss.logging.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import vn.mog.ewallet.common.util.HttpUtil;
import vn.mog.ewallet.exception.SecurityException;
import vn.mog.ewallet.SharedConstants;
import vn.mog.ewallet.exception.ErrorException;

import javax.servlet.http.HttpServletRequest;

@Service
public class CardStoreAPIClient {

	private static final Logger log = Logger.getLogger(CardStoreAPIClient.class);

	//--------------------------------
	public static final String AUTHORIZATION = "Authorization";
	public static final String BEARER_HEADER_PREFIX = "Bearer ";
	public static final String USER_AGENT = "User-Agent";

	public static String ACCESS_TOKEN = "access_token";

	public String getAccessToken() {
		try {
			return (String) HttpUtil.getCurrentHttpServletRequest().getSession().getAttribute(ACCESS_TOKEN);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return null;
	}

	public void setAccessToken(String accessToken) {
		HttpUtil.getCurrentHttpServletRequest().getSession().setAttribute(ACCESS_TOKEN, accessToken);
	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	public Object callRequest(String requestURI, Object request, Class clazz) throws SecurityException, ErrorException {
		try {
			HttpServletRequest httpServletRequest = HttpUtil.getCurrentHttpServletRequest();

			final String url = SharedConstants.CARD_STORE_CORE_BASE_REQUEST_URL + requestURI;
			//--------------
			HttpHeaders headers = new HttpHeaders();
			headers.add(AUTHORIZATION, BEARER_HEADER_PREFIX + getAccessToken());
			headers.add(USER_AGENT, httpServletRequest.getHeader(USER_AGENT));

			final HttpEntity walletRequest = new HttpEntity(request, headers);
			//
			Object resp = HttpUtil.restTemplate.postForObject(url, walletRequest, clazz);
			if (resp == null)
				throw new ErrorException(1, "Fail to this request!");

			return resp;
		} catch (HttpStatusCodeException ex) {
			log.error(ex.getMessage());
			int statusCode = ex.getStatusCode().value();
			log.error("RESPONE HTTP CODE: " + statusCode);
			if (statusCode == 401)
				throw new SecurityException(401, "Not Authorized!");
			throw ex;
		} catch (RestClientException ex) {
			log.error(ex.getMessage());
			throw ex;
		} catch (Exception ex) {
			log.error(ex.getMessage());
			throw ex;
		}
	}
}
