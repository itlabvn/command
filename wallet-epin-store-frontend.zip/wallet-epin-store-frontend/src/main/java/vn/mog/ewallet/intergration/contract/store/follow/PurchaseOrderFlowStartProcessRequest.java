package vn.mog.ewallet.intergration.contract.store.follow;

import java.io.Serializable;

public class PurchaseOrderFlowStartProcessRequest extends PurchaseOrderFlowStartProcessRequestType implements Serializable {

}
