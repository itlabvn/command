package vn.mog.ewallet.intergration.contract.topup;

import java.io.Serializable;

import vn.mog.framework.contract.base.MobiliserRequestType;

public class CustomerRequestType extends MobiliserRequestType implements Serializable {
    private static final long serialVersionUID = 1L;

}
