package vn.mog.ewallet.intergration.contract.store;

@SuppressWarnings("serial")
public class GetCardAvailableResponse extends GetCardAvailableResponseType {

}
