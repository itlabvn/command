package vn.mog.ewallet.exception;


public class SessionInvalidException extends SecurityException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SessionInvalidException(int errorCode, String errorMessage) {
		super(errorCode, errorMessage);
	}
	
	public SessionInvalidException(int errorCode, String source,  String errorMessage) {
		super(errorCode, source, errorMessage);
	}
}
