package vn.mog.ewallet.intergration.contract.security;

import vn.mog.ewallet.intergration.contract.store.RequestType;

import java.io.Serializable;

public class LogoutRequest extends RequestType implements Serializable {
	
	private String test = "Bye bye Server";

	public String getTest() {
		return test;
	}

	public void setTest(String test) {
		this.test = test;
	}
}
