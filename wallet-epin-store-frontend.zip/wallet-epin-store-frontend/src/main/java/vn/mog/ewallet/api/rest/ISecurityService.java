package vn.mog.ewallet.api.rest;

public interface ISecurityService {

  public void logout() throws Exception;


}
