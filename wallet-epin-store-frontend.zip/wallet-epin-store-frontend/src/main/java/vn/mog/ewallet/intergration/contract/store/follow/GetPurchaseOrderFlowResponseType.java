package vn.mog.ewallet.intergration.contract.store.follow;

import vn.mog.ewallet.intergration.contract.store.follow.beans.PurchaseOrderFlow;
import vn.mog.framework.contract.base.MobiliserResponseType;

import java.io.Serializable;

public class GetPurchaseOrderFlowResponseType extends MobiliserResponseType implements Serializable {
	protected PurchaseOrderFlow purchaseOrderFlow;

	public PurchaseOrderFlow getPurchaseOrderFlow() {
	    return purchaseOrderFlow;
	}
	
	public void setPurchaseOrderFlow(PurchaseOrderFlow purchaseOrderFlow) {
	    this.purchaseOrderFlow = purchaseOrderFlow;
	}

}
