package vn.mog.ewallet.intergration.contract.topup;

import java.io.Serializable;

import vn.mog.framework.contract.base.MobiliserResponseType;

public class CustomerResponseType extends MobiliserResponseType implements Serializable {
    private static final long serialVersionUID = 1L;

}
