package vn.mog.ewallet.web.controller.store;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import vn.mog.ewallet.common.util.FileCompareUtil;
import vn.mog.ewallet.common.util.NumberUtil;
import vn.mog.ewallet.exception.ErrorMessages;
import vn.mog.ewallet.intergration.contract.store.ChangePurchaseOrderStatusRequest;
import vn.mog.ewallet.intergration.contract.store.ChangePurchaseOrderStatusResponse;
import vn.mog.ewallet.intergration.contract.store.CreateAttachmentRequest;
import vn.mog.ewallet.intergration.contract.store.CreateAttachmentResponse;
import vn.mog.ewallet.intergration.contract.store.CreateFullPurchaseOrderRequest;
import vn.mog.ewallet.intergration.contract.store.CreateFullPurchaseOrderResponse;
import vn.mog.ewallet.intergration.contract.store.FindProviderProfileRequest;
import vn.mog.ewallet.intergration.contract.store.FindProviderProfileResponse;
import vn.mog.ewallet.intergration.contract.store.FindPurchaseOrderRequest;
import vn.mog.ewallet.intergration.contract.store.FindPurchaseOrderResponse;
import vn.mog.ewallet.intergration.contract.store.GetPurchaseOrderRequest;
import vn.mog.ewallet.intergration.contract.store.GetPurchaseOrderResponse;
import vn.mog.ewallet.intergration.contract.store.UpdatePurchaseOrderRequest;
import vn.mog.ewallet.intergration.contract.store.UpdatePurchaseOrderResponse;
import vn.mog.ewallet.intergration.contract.store.VerifyPurchaseOrderFileRequest;
import vn.mog.ewallet.intergration.contract.store.VerifyPurchaseOrderFileResponse;
import vn.mog.ewallet.intergration.contract.store.bean.Attachment;
import vn.mog.ewallet.intergration.contract.store.bean.POFileCompareResult;
import vn.mog.ewallet.intergration.contract.store.bean.PurchaseOrderDetailItem;
import vn.mog.ewallet.intergration.contract.store.bean.PurchaseOrderItem;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowApproveRequest;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowApproveResponse;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowRejectRequest;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowRejectResponse;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowStartProcessRequest;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowStartProcessResponse;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowSubmitProcessRequest;
import vn.mog.ewallet.intergration.contract.store.follow.PurchaseOrderFlowSubmitProcessResponse;
import vn.mog.ewallet.web.contract.AjaxResponse;
import vn.mog.ewallet.web.contract.RolesType;
import vn.mog.ewallet.web.contract.WorkflowState;
import vn.mog.ewallet.web.controller.AbstractController;
import vn.mog.framework.contract.base.KeyValue;

@Controller
@RequestMapping(value = "/purchase-order")
public class PurchaseOrderController extends AbstractController {

  private static final Logger log = LoggerFactory.getLogger(PurchaseOrderController.class);

  @RequestMapping(value = "/list", method = RequestMethod.GET)
  public String purchaseOrderList(HttpServletRequest httpRequest, ModelMap model) throws Exception {
    boolean isNotLogin = !checkLogin(httpRequest);

    boolean hasNotAnyRoles = account != null && !account
        .hasAnyRoles(RolesType.ADMIN,
            RolesType.FINANCE, RolesType.FINANCE_SUPPORT_STAFF,
            RolesType.SALE_SUPPORT, RolesType.SALE_SUPPORT_MANAGER, RolesType.SALE_SUPPORT_STAFF,
            RolesType.SALE_MANAGER,
            RolesType.RECONCILIATION, RolesType.RECONCILIATION_MANAGER,
            RolesType.CUSTOMER_CARE);

    if (isNotLogin && hasNotAnyRoles) {
      return REDIRECT_LOGOIN;
    }

    String[] provider = httpRequest.getParameterValues("provider");
    String quickSearch = httpRequest.getParameter("id");
    String[] status = httpRequest.getParameterValues("status");

    int[] workflowState = ServletRequestUtils.getIntParameters(httpRequest, "workflowState");
    String searchRange = httpRequest.getParameter("range");
    Date[] dates = parseSearchRange(searchRange);

    int limit = 20;
    int offset = 0;
    if (httpRequest.getParameter("d-49520-p") != null) {
      Integer p = Integer.parseInt(httpRequest.getParameter("d-49520-p"));
      offset = limit * (p - 1);
    }

    FindPurchaseOrderRequest request = new FindPurchaseOrderRequest();
    request.setFromDate(dates[0]);
    request.setEndDate(dates[1]);
    if (provider != null && provider.length > 0 && !provider[0].equals(StringUtils.EMPTY)) {
      request.setProvider(Arrays.asList(provider));
    }
    if (status != null && status.length > 0 && !status[0].equals(StringUtils.EMPTY)) {
      request.setStatus(Arrays.asList(status));
    }
    if (workflowState != null && workflowState.length > 0) {
      request.setWorkflowState(Arrays.asList(ArrayUtils.toObject(workflowState)));
    }

    request.setQuickSearch(StringUtils.trimToNull(quickSearch));
    request.setLimit(limit);
    request.setOffset(offset);

    FindPurchaseOrderResponse response = cardStoreService.findPurchaseOrders(request);

    Long totalOfMoney = response.getAmount();
    Long totalOfCapital = response.getCapital();

    model.put("listProvider", cardStoreService.listProvider());
    model.put("listWorkflow", WorkflowState.values());
    model.put("listStatus", cardStoreService.listPOStatus());

    model.put("pagesize", limit);
    model.put("offset", offset);
    model.put("list", response.getPurchaseOrders());
    model.put("total", (ObjectUtils.equals(response.getCount(), null) ? 0 : response.getCount().intValue()));
    model.put("totalOfMoney", totalOfMoney);
    model.put("totalOfCapital", totalOfCapital);
    model.put("totalOfCards", ObjectUtils.equals(response.getQuantity(), null) ? 0 : response.getQuantity().intValue());
    model.put("id", StringUtils.trimToNull(quickSearch));

    return "purchase-order/list";
  }

  @RequestMapping(value = "/add", method = RequestMethod.GET)
  public String purchaseOrderAdd(HttpServletRequest request, ModelMap model) throws Exception {
    boolean isNotLogin = !checkLogin(request);

    boolean hasNotAnyRoles = account != null && !account
        .hasAnyRoles(RolesType.ADMIN,
            RolesType.SALE_SUPPORT, RolesType.SALE_SUPPORT_MANAGER, RolesType.SALE_SUPPORT_STAFF,
            RolesType.FINANCE);

    if (isNotLogin && hasNotAnyRoles) {
      return REDIRECT_LOGOIN;
    }

    model.put("listProvider", cardStoreService.listProvider());

    return "purchase-order/declare_po";
  }

  /**
   * Luồng import
   * B1:  Khai báo PO
   */
  @RequestMapping(value = "/add", method = RequestMethod.POST)
  public String purchaseOrderSubmit(HttpServletRequest request, ModelMap model) throws Exception {
    boolean isNotLogin = !checkLogin(request);

    boolean hasNotAnyRoles = account != null && !account
        .hasAnyRoles(RolesType.ADMIN,
            RolesType.SALE_SUPPORT, RolesType.SALE_SUPPORT_MANAGER, RolesType.SALE_SUPPORT_STAFF,
            RolesType.FINANCE);

    if (isNotLogin && hasNotAnyRoles) {
      return REDIRECT_LOGOIN;
    }

    Long totalQuantity = 0L;
    Long totalMoney = 0L;
    Long totalCapitalValue = 0L;
    Integer totalTelco = NumberUtil.convertToInt(request.getParameter("totalTelco"));
    List<PurchaseOrderDetailItem> poDetails = new ArrayList<>();
    for (int i = 1; i < totalTelco + 1; i++) {
      PurchaseOrderDetailItem detailItem = new PurchaseOrderDetailItem();

      String cardType = request.getParameter("telco_" + i);
      Integer faceValue = NumberUtil.convertToInt(request.getParameter("value_" + i));
      Integer quantity = NumberUtil.convertToInt(request.getParameter("quantity_" + i));
      Double discount = NumberUtil.convertToDouble(request.getParameter("discount_" + i));

      BigDecimal sumFaceValue = new BigDecimal(Long.valueOf(faceValue) * quantity);
      BigDecimal discountPercentRate = new BigDecimal(discount / 100);
      BigDecimal sumCapitalValue = sumFaceValue.subtract(sumFaceValue.multiply(discountPercentRate));
      totalCapitalValue += sumCapitalValue.setScale(0, RoundingMode.HALF_UP).longValueExact();

      detailItem.setCardType(cardType);
      detailItem.setFaceValue(faceValue);
      detailItem.setQuantity(quantity);
      detailItem.setDiscountRate(discount);

      totalQuantity += quantity;
      Long money = (quantity * 1L) * faceValue;
      totalMoney += money;
      poDetails.add(detailItem);

    }

    String provider = request.getParameter("provider");
    String poCode = request.getParameter("poCode");
    String notePo = request.getParameter("note");

    CreateFullPurchaseOrderRequest requestPO = new CreateFullPurchaseOrderRequest();
    PurchaseOrderItem poAdd = new PurchaseOrderItem();
    poAdd.setPoCode(poCode);
    poAdd.setTotalQuantity(totalQuantity);
    poAdd.setTotalValue(totalMoney);
    poAdd.setCapitalValue(totalCapitalValue);
    poAdd.setProvider(provider);
    poAdd.setPurchaseOrderDetails(poDetails);
    poAdd.setNote(notePo);

    requestPO.setPurchaseOrder(poAdd);

    try {

      MultipartHttpServletRequest multiPartRequest = (MultipartHttpServletRequest) request;
      List<MultipartFile> multiparts = multiPartRequest.getFiles("file");

      List<Attachment> attachments = new ArrayList<>();
      Attachment fileUpload;

      for (MultipartFile multipart : multiparts) {
        byte[] fileData = new byte[0];
        if (multipart != null && multipart.getBytes() != null && multipart.getBytes().length > 0) {
          fileData = multipart.getBytes();
        }
        fileUpload = new Attachment();
        fileUpload.setName(multipart.getOriginalFilename());
        fileUpload.setContentType(multipart.getContentType());
        fileUpload.setContent(fileData);

        attachments.add(fileUpload);
      }

      requestPO.setAttachments(attachments);
    } catch (Exception ex) {
      log.error("purchaseOrderSubmit", ex);
    }

    CreateFullPurchaseOrderResponse responsePO = cardStoreService.createFullPurchaseOrder(requestPO);

    if (responsePO.getStatus().getCode() == 0) {
      return "redirect:/purchase-order/list";
    } else {
      model.put("codeErr", responsePO.getStatus().getCode());
      model.put("mesErr", responsePO.getStatus().getValue());
      model.put("unstructuredData", responsePO.getUnstructuredData());
      model.put("listProvider", cardStoreService.listProvider());
      return "purchase-order/declare_po";
    }
  }

  @RequestMapping(value = "/upload", method = RequestMethod.GET)
  public String purchaseOrderUpload(HttpServletRequest request, ModelMap model) throws Exception {

    boolean isNotLogin = !checkLogin(request);

    boolean hasNotAnyRoles = account != null && !account.hasAnyRoles(RolesType.ADMIN,
        RolesType.SALE_SUPPORT, RolesType.SALE_SUPPORT_MANAGER, RolesType.SALE_SUPPORT_STAFF,
        RolesType.FINANCE);

    if (isNotLogin && hasNotAnyRoles) {
      return REDIRECT_LOGOIN;
    }

    model.put("listProvider", cardStoreService.listProvider());

    return "purchase-order/upload_file";
  }

  /**
   * Luồng import
   * B2: file tải lên
   */
  @RequestMapping(value = "/upload", method = RequestMethod.POST)
  public String createFullPurchaseOrder(HttpServletRequest request, ModelMap model) throws Exception {

    boolean isNotLogin = !checkLogin(request);

    boolean hasNotAnyRoles = account != null && !account
        .hasAnyRoles(RolesType.ADMIN, RolesType.SALE_SUPPORT, RolesType.SALE_SUPPORT_MANAGER,
            RolesType.SALE_SUPPORT_STAFF, RolesType.FINANCE);

    if (isNotLogin && hasNotAnyRoles) {
      return REDIRECT_LOGOIN;
    }


		/* Upload file file excel and save it to PO table */
    String notePo = request.getParameter("note");
    String filePath = request.getParameter("pathFile");

    MultipartHttpServletRequest multiPartRequest = (MultipartHttpServletRequest) request;
    List<MultipartFile> multiparts = multiPartRequest.getFiles("file");

    List<Attachment> attachments = new ArrayList<>();
    Attachment fileUpload;

    for (MultipartFile multipart : multiparts) {
      byte[] fileData = new byte[0];
      if (multipart != null && multipart.getBytes() != null && multipart.getBytes().length > 0) {
        fileData = multipart.getBytes();
      }
      fileUpload = new Attachment();

      fileUpload.setName(multipart.getOriginalFilename());
      fileUpload.setContentType("unknow");
      fileUpload.setContent(fileData);

      attachments.add(fileUpload);

    }

    CreateFullPurchaseOrderRequest requestBackEnd = new CreateFullPurchaseOrderRequest();
    PurchaseOrderItem poUpdate = new PurchaseOrderItem();
    poUpdate.setNote(notePo);
    poUpdate.setFilePath(filePath);

    requestBackEnd.setPurchaseOrder(poUpdate);
    requestBackEnd.setAttachments(attachments);

    CreateFullPurchaseOrderResponse responseBackEnd = cardStoreService.createFullPurchaseOrder(requestBackEnd);
    if (responseBackEnd.getStatus().getCode() == 0) {
      return "redirect:/purchase-order/list";
    } else {
      model.put("codeErr", responseBackEnd.getStatus().getCode());
      model.put("mesErr", responseBackEnd.getStatus().getValue());
      model.put("listProvider", cardStoreService.listProvider());
      return "redirect:/purchase-order/add";
    }

  }

  @RequestMapping(value = "/updateAttachment", method = RequestMethod.POST)
  public String updatePurchaseOrderAttachment(HttpServletRequest request, ModelMap model) throws Exception {
    boolean isNotLogin = !checkLogin(request);

    boolean hasNotAnyRoles = account != null && !account
        .hasAnyRoles(RolesType.ADMIN, RolesType.SALE_SUPPORT, RolesType.SALE_SUPPORT_MANAGER,
            RolesType.SALE_SUPPORT_STAFF, RolesType.FINANCE);

    if (isNotLogin && hasNotAnyRoles) {
      return REDIRECT_LOGOIN;
    }

		/* Upload file file excel and save it to PO table */

    Long idPo = Long.parseLong(request.getParameter("id"));
    String note = request.getParameter("note");

    MultipartHttpServletRequest multiPartRequest = (MultipartHttpServletRequest) request;
    List<MultipartFile> multiparts = multiPartRequest.getFiles("file");

    List<Attachment> attachments = new ArrayList<>();
    Attachment fileUpload;

    for (MultipartFile multipart : multiparts) {
      byte[] fileData = new byte[0];
      if (multipart != null && multipart.getBytes() != null && multipart.getBytes().length > 0) {
        fileData = multipart.getBytes();
      }
      fileUpload = new Attachment();
      fileUpload.setPurchaseOrderId(idPo);
      fileUpload.setName(multipart.getOriginalFilename());
      fileUpload.setContentType("unknow");
      fileUpload.setContent(fileData);
      attachments.add(fileUpload);
    }

    CreateAttachmentRequest requestBackEnd = new CreateAttachmentRequest();
    requestBackEnd.setAttachment(attachments);
    requestBackEnd.setNote(note);

    CreateAttachmentResponse responseBackEnd = cardStoreService.updatePurchaseOrderAttachment(requestBackEnd);
    if (responseBackEnd.getStatus().getCode() == 0) {
      return "redirect:/purchase-order/list";
    } else {
      model.put("codeErr", responseBackEnd.getStatus().getCode());
      model.put("mesErr", responseBackEnd.getStatus().getValue());
      model.put("listProvider", cardStoreService.listProvider());
      return "redirect:/purchase-order/upload?id=" + idPo;
    }

  }

  @RequestMapping(value = "/edit", method = RequestMethod.GET)
  public String purchaseOrderEdit(HttpServletRequest request, ModelMap model) throws Exception {
    boolean isNotLogin = !checkLogin(request);

    boolean hasNotAnyRoles = account != null && !account
        .hasAnyRoles(RolesType.ADMIN, RolesType.SALE_SUPPORT, RolesType.SALE_SUPPORT_MANAGER,
            RolesType.SALE_SUPPORT_STAFF, RolesType.FINANCE);

    if (isNotLogin && hasNotAnyRoles) {
      return REDIRECT_LOGOIN;
    }

    String id = request.getParameter("id");
    if (StringUtils.isBlank(id)) {
      return "redirect:/purchase-order/list";
    }
    try {
      Long poId = Long.parseLong(id);

      GetPurchaseOrderRequest requestPO = new GetPurchaseOrderRequest();
      requestPO.setPurchaseOrderId(poId);

      GetPurchaseOrderResponse responsePO = cardStoreService.getPurchaseOrder(requestPO);

      if (responsePO != null && responsePO.getPurchaseOrder() != null) {
        model.put("responsePO", responsePO.getPurchaseOrder());
        model.put("poItem", responsePO.getPurchaseOrder());
        model.put("poDetailItems", responsePO.getPurchaseOrder().getPurchaseOrderDetails());
        model.put("listProvider", cardStoreService.listProvider());
        return "purchase-order/edit_declare_po";

      } else {
        return "redirect:/purchase-order/list";
      }
    } catch (Exception e) {
      log.error("purchaseOrderEdit", e);
      return "redirect:/purchase-order/list";
    }

  }

  /**
   * Luồng import
   * Edit po
   */
  @RequestMapping(value = "/edit", method = RequestMethod.POST)
  public String purchaseOrderEditAction(HttpServletRequest request, ModelMap model) throws Exception {
    boolean isNotLogin = !checkLogin(request);

    boolean hasNotAnyRoles = account != null && !account
        .hasAnyRoles(RolesType.ADMIN, RolesType.SALE_SUPPORT, RolesType.SALE_SUPPORT_MANAGER,
            RolesType.SALE_SUPPORT_STAFF, RolesType.FINANCE);

    if (isNotLogin && hasNotAnyRoles) {
      return REDIRECT_LOGOIN;
    }

    String id = request.getParameter("id");
    if (StringUtils.isBlank(id)) {
      return "redirect:/purchase-order/list";
    }
    try {
      Long poid = Long.parseLong(id);

      GetPurchaseOrderRequest requestPO = new GetPurchaseOrderRequest();
      requestPO.setPurchaseOrderId(poid);

      GetPurchaseOrderResponse responsePO = cardStoreService.getPurchaseOrder(requestPO);

      model.put("responsePO", responsePO);

      model.put("listProvider", cardStoreService.listProvider());

      Integer totalTelco = NumberUtil.convertToInt(request.getParameter("totalTelco"));
      String provider = request.getParameter("provider");
      String poCode = request.getParameter("poCode");

      Long totalQuantity = 0L;
      Long totalValue = 0L;
      Long totalCapitalValue = 0L;

      List<PurchaseOrderDetailItem> listPOdetail = new ArrayList<>();
      for (int i = 1; i < totalTelco + 1; i++) {
        PurchaseOrderDetailItem detailItem = new PurchaseOrderDetailItem();

        String cardType = request.getParameter("telco_" + i);
        Integer faceValue = NumberUtil.convertToInt(request.getParameter("value_" + i));
        Integer quantity = NumberUtil.convertToInt(request.getParameter("quantity_" + i));
        Double discount = NumberUtil.convertToDouble(request.getParameter("discount_" + i));

        BigDecimal sumFaceValue = new BigDecimal(Long.valueOf(faceValue) * quantity);
        BigDecimal discountPercentRate = new BigDecimal(discount / 100);
        BigDecimal sumCapitalValue = sumFaceValue.subtract(sumFaceValue.multiply(discountPercentRate));
        totalCapitalValue += sumCapitalValue.setScale(0, RoundingMode.HALF_UP).longValueExact();

        detailItem.setCardType(cardType);
        detailItem.setFaceValue(faceValue);
        detailItem.setQuantity(quantity);
        detailItem.setDiscountRate(discount);
        detailItem.setPoId(poid);
        listPOdetail.add(detailItem);

        totalQuantity += (quantity * 1L);
        totalValue += (quantity * 1L) * faceValue;
      }
      PurchaseOrderItem purchaseOrderItem = new PurchaseOrderItem();
      purchaseOrderItem.setProvider(provider);
      purchaseOrderItem.setId(poid);
      purchaseOrderItem.setPoCode(poCode);
      purchaseOrderItem.setPurchaseOrderDetails(listPOdetail);
      purchaseOrderItem.setTotalQuantity(totalQuantity);
      purchaseOrderItem.setTotalValue(totalValue);
      purchaseOrderItem.setCapitalValue(totalCapitalValue);

      UpdatePurchaseOrderRequest requestUpPO = new UpdatePurchaseOrderRequest();
      requestUpPO.setPurchaseOrder(purchaseOrderItem);
      if (!listPOdetail.isEmpty()) {
        requestUpPO.setIncludePODetail(true);
      }

      UpdatePurchaseOrderResponse responseUpPO = cardStoreService.updatePurchaseOrder(requestUpPO);

      if (responseUpPO.getStatus().getCode() == 0) {
        return "redirect:/purchase-order/list";
      } else {
        model.put("codeErr", responseUpPO.getStatus().getCode());
        model.put("mesErr", responseUpPO.getStatus().getValue());
        return "redirect:/purchase-order/edit?id=" + poid;
      }
    } catch (Exception e) {
      log.error("purchaseOrderEditAction", e);
      return "redirect:/purchase-order/list";
    }
  }

  @RequestMapping(value = "/verify", method = RequestMethod.GET)
  public String purchaseOrderVerify(HttpServletRequest request, ModelMap model) throws Exception {
    boolean isNotLogin = !checkLogin(request);

    boolean hasNotAnyRoles = account != null && !account.hasAnyRoles(RolesType.ADMIN, RolesType.FINANCE);

    if (isNotLogin && hasNotAnyRoles) {
      return REDIRECT_LOGOIN;
    }

    /* Get PO & PO Detail from Database to show for User */
    return "purchase-order/display_verify";
  }

  @RequestMapping(value = "/verify", method = RequestMethod.POST)
  public String purchaseOrderVerifySubmit(HttpServletRequest request, ModelMap model) throws Exception {
    boolean isNotLogin = !checkLogin(request);

    boolean hasNotAnyRoles = account != null && !account.hasAnyRoles(RolesType.ADMIN, RolesType.FINANCE);

    if (isNotLogin && hasNotAnyRoles) {
      return REDIRECT_LOGOIN;
    }

    /* Get password from client */
    String password = request.getParameter("password");
    String poID = request.getParameter("poId");
    String poCode = request.getParameter("poCode");
    try {
      if (poID != null && poID != StringUtils.EMPTY) {
        VerifyPurchaseOrderFileRequest requestPO = new VerifyPurchaseOrderFileRequest();
        requestPO.setPoId(Long.parseLong(poID));
        requestPO.setPassword(password);
        log.error("poID--" + Long.parseLong(poID));
        log.error("password--" + password);

        VerifyPurchaseOrderFileResponse responsePO = cardStoreService.verifyPurchaseOrderFile(requestPO);

        List<POFileCompareResult> compareResult = new ArrayList<>();
        boolean isPOdetail = responsePO.getpODetailList() != null && !responsePO.getpODetailList().isEmpty();
        boolean isPoFile = responsePO.getpOFileList() != null && !responsePO.getpOFileList().isEmpty();
        if (isPOdetail && isPoFile) {
          compareResult = FileCompareUtil.compare((List) responsePO.getpODetailList(), (List) responsePO.getpOFileList());
        }

        model.put("codeErr", responsePO.getStatus().getCode());
        model.put("mesErr", responsePO.getStatus().getValue());

        model.put("poId", poID);
        model.put("poCode", poCode);
        model.put("password", password);
        model.put("responsePO", responsePO);
        model.put("compareResult", compareResult);
      } else {
        model.put("codeErr", ErrorMessages.ERROR.code);
        model.put("mesErr", "Xử lý thất bại, có lỗi xảy ra.");
      }
    } catch (Exception e) {
      log.error("purchaseOrderVerifySubmit", e);
      model.put("codeErr", 1);
      model.put("mesErr", e.getMessage());
    }
    /* Compare excel data with data in database return to client */
    return "purchase-order/verify";
  }

  @RequestMapping(value = "/verify/commit", method = RequestMethod.POST)
  public String purchaseOrderVerifyCommit(HttpServletRequest request, ModelMap model)
      throws Exception {

    boolean isNotLogin = !checkLogin(request);

    boolean hasNotAnyRoles = account != null && !account.hasAnyRoles(RolesType.ADMIN, RolesType.FINANCE);

    if (isNotLogin && hasNotAnyRoles) {
      return REDIRECT_LOGOIN;
    }

		/* Get some parameter */
    String poID = request.getParameter("poid");
    String poCode = request.getParameter("poCode");
    String action = request.getParameter("action");
    String password = request.getParameter("password");
    String note = request.getParameter("note");

    try {
      if (poID != null && poID != StringUtils.EMPTY && action != null && action != StringUtils.EMPTY) {

        if (action.equals(WorkflowState.CONFIRMED.name())) {
          PurchaseOrderFlowApproveRequest requestPO = new PurchaseOrderFlowApproveRequest();
          requestPO.setPurchaseOrderId(Long.parseLong(poID));
          requestPO.setInfo(note);
          List<KeyValue> unstructuredData = new ArrayList<>();
          unstructuredData.add(new KeyValue("password", password));
          requestPO.setUnstructuredData(unstructuredData);
          PurchaseOrderFlowApproveResponse responsePO = cardStoreService.verifyPOApprove(requestPO);

          if (responsePO.getStatus().getCode() != 0) {
            model.put("poCode", poCode);
            model.put("codeErr", responsePO.getStatus().getCode());
            model.put("mesErr", responsePO.getStatus().getValue());
            return "redirect:/purchase-order/list";
          }
        } else if (action.equals(WorkflowState.REJECTED.name())) {
          PurchaseOrderFlowRejectRequest requestPO = new PurchaseOrderFlowRejectRequest();
          requestPO.setPurchaseOrderId(Long.parseLong(poID));
          requestPO.setInfo(note);
          List<KeyValue> unstructuredData = new ArrayList<>();
          unstructuredData.add(new KeyValue("password", password));
          requestPO.setUnstructuredData(unstructuredData);
          PurchaseOrderFlowRejectResponse responsePO = cardStoreService.verifyPOReject(requestPO);

          if (responsePO.getStatus().getCode() != 0) {
            return "redirect:/purchase-order/list";
          }
        } else {
          model.put("codeErr", 1);
          model.put("mesErr", "Lỗi trong quá trình xử lý.");
        }
      } else {
        model.put("codeErr", 1);
        model.put("mesErr", "Xử lý thất bại, thiếu tham số.");
      }
    } catch (Exception e) {
      log.error("purchaseOrderVerifyCommit", e);
      model.put("codeErr", 1);
      model.put("mesErr", e.getMessage());
    }

    return "redirect:/purchase-order/list";
  }

  @RequestMapping(value = "/update-status", method = RequestMethod.POST)
  @ResponseBody
  public AjaxResponse purchaseOrderUpdateStatusSubmit(HttpServletRequest request, HttpServletResponse response) {

    if (account != null && !account.hasAnyRoles(RolesType.ADMIN, RolesType.FINANCE)) {
      return new AjaxResponse(1, "Xử lý thất bại, có lỗi xảy ra.");
    }

    String poID = request.getParameter("poid");
    String poCode = request.getParameter("poCode");
    String status = request.getParameter("action");
    String note = request.getParameter("note");

    try {
      if (!StringUtils.EMPTY.equals(poID) && !StringUtils.EMPTY.equals(status)) {
        ChangePurchaseOrderStatusRequest requestPO = new ChangePurchaseOrderStatusRequest();

        requestPO.setActiveOrInactive("ACTIVE".equals(status) ? true : false);
        requestPO.setPoCode(poCode);
        requestPO.setNote(note);

        ChangePurchaseOrderStatusResponse responsePO = cardStoreService.updatePurchaseOrderStatus(requestPO);
        if (responsePO.getStatus().getCode() == 0) {
          return new AjaxResponse(0, "Cập nhật trạng thái thành công!");
        } else {
          return new AjaxResponse(responsePO.getStatus().getCode(), responsePO.getStatus().getValue());
        }
      } else {
        return new AjaxResponse(1, "Xử lý thất bại, có lỗi xảy ra.");
      }
    } catch (Exception e) {
      log.error("purchaseOrderUpdateStatusSubmit", e);
      return new AjaxResponse(1, e.getMessage());
    }
  }


  @RequestMapping(value = "/submit-po", method = RequestMethod.POST)
  @ResponseBody
  public AjaxResponse submitPurchaseOrderFlow(HttpServletRequest request, HttpServletResponse response) {

    //TODO ROLE

    String poID = request.getParameter("poid");
    String action = request.getParameter("action");
    String note = request.getParameter("note");

    try {
      if (!StringUtils.EMPTY.equals(poID) && !StringUtils.EMPTY.equals(action)) {
        if (action.equals(WorkflowState.REJECTED.name())) {

          PurchaseOrderFlowSubmitProcessRequest requestPO = new PurchaseOrderFlowSubmitProcessRequest();
          requestPO.setPurchaseOrderId(Long.parseLong(poID));
          requestPO.setInfo(note);

          PurchaseOrderFlowSubmitProcessResponse responsePO = cardStoreService.submitPurchaseOrder(requestPO);
          if (responsePO.getStatus().getCode() == 0) {
            return new AjaxResponse(0, "Cập nhật trạng thái thành công!");
          } else {
            return new AjaxResponse(responsePO.getStatus().getCode(), responsePO.getStatus().getValue());
          }
        } else if (action.equals(WorkflowState.INIT.name())) {

          PurchaseOrderFlowStartProcessRequest requestPO = new PurchaseOrderFlowStartProcessRequest();
          requestPO.setPurchaseOrderId(Long.parseLong(poID));
          requestPO.setInfo(note);

          PurchaseOrderFlowStartProcessResponse responsePO = cardStoreService.startPurchaseOrder(requestPO);
          if (responsePO.getStatus().getCode() == 0) {
            return new AjaxResponse(0, "Cập nhật trạng thái thành công!");
          } else {
            return new AjaxResponse(responsePO.getStatus().getCode(), responsePO.getStatus().getValue());
          }
        } else {
          return new AjaxResponse(1, "Xử lý thất bại, có lỗi xảy ra.");
        }
      } else {
        return new AjaxResponse(1, "Xử lý thất bại, có lỗi xảy ra.");
      }
    } catch (Exception e) {
      log.error("submitPurchaseOrderFlow", e);
      return new AjaxResponse(1, e.getMessage());
    }
  }

  @RequestMapping(value = "/getPoDetail", method = RequestMethod.POST)
  @ResponseBody
  public GetPurchaseOrderResponse getPODetail(HttpServletRequest request, HttpServletResponse response) {

    //TODO role

    GetPurchaseOrderRequest requestPO = new GetPurchaseOrderRequest();
    GetPurchaseOrderResponse responsePO = new GetPurchaseOrderResponse();
    try {
      Long poId = NumberUtil.convertToLong(request.getParameter("poid"));
      requestPO.setPurchaseOrderId(poId);

      responsePO = cardStoreService.getPurchaseOrder(requestPO);
    } catch (Exception e) {
      log.error("getPODetail", e);
    }

    return responsePO;
  }

  @RequestMapping(value = "/getFileExistCard", method = RequestMethod.POST)
  public String getFileExistCard(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
    //TODO ROLE

    String poID = request.getParameter("poid");
    String password = request.getParameter("password");

    try {
      if (!StringUtils.EMPTY.equals(poID)) {
        VerifyPurchaseOrderFileRequest requestPO = new VerifyPurchaseOrderFileRequest();
        requestPO.setPoId(Long.parseLong(poID));
        requestPO.setPassword(password);

        VerifyPurchaseOrderFileResponse responsePO = cardStoreService.verifyPurchaseOrderFile(requestPO);

        if (responsePO.getExistedPinQuantity() + responsePO.getExistedSerialQuantity() != 0
            && responsePO.getExistedFile() != null) {
          response.setContentType("application/vnd.ms-excel");
          response.setHeader("Content-Disposition", "attachment; filename=" + responsePO.getExistedFileName());
          ServletOutputStream out = response.getOutputStream();
          out.write(responsePO.getExistedFile());
          out.flush();
          out.close();
        }
      }
    } catch (Exception e) {
      log.error("getFileExistCard", e);
    }
    return "purchase-order/verify";
  }

  private static String EPAY = "/templatefile/EPAY.xls";
  private static String TRUEMONEY = "/templatefile/TRUEMONEY.xlsx";
  private static String VIETTEL = "/templatefile/VIETTEL.txt";
  private static String VNTP = "/templatefile/VNTP.xlsx";
  private static String VTC = "/templatefile/VTC.txt";
  private static String MOBIFONE = "/templatefile/MOBIFONE.dat";
  private static String VINPLAY = "/templatefile/VINPLAY.txt";

  private static String EPAY_NAME = "EPAY";
  private static String TRUEMONEY_NAME = "TRUEMONEY";
  private static String VIETTEL_NAME = "VIETTEL";
  private static String VNTP_NAME = "VNTP";
  private static String VTC_NAME = "VTC";
  private static String MOBIFONE_NAME = "MOBIFONE";
  private static String VINPLAY_NAME = "VINPLAY";


  @RequestMapping(value = "/files/{file_name}", method = RequestMethod.GET)
  public void getFile(@PathVariable("file_name") String fileName, HttpServletResponse response) {
    //TODO ROLE

    try {
      String contentType = "";
      InputStream inputStream = null;
      String extensionFile = "";
      if (EPAY_NAME.equals(fileName)) {
        inputStream = new ClassPathResource(EPAY).getInputStream();
        contentType = "application/vnd.ms-excel";
        extensionFile = "xls";
      } else if (TRUEMONEY_NAME.equals(fileName)) {
        inputStream = new ClassPathResource(TRUEMONEY).getInputStream();
        contentType = "application/vnd.ms-excel";
        extensionFile = "xlsx";
      } else if (VIETTEL_NAME.equals(fileName)) {
        contentType = "text/plain";
        inputStream = new ClassPathResource(VIETTEL).getInputStream();
        extensionFile = "txt";
      } else if (VNTP_NAME.equals(fileName)) {
        inputStream = new ClassPathResource(VNTP).getInputStream();
        contentType = "application/vnd.ms-excel";
        extensionFile = "xlsx";
      } else if (VTC_NAME.equals(fileName)) {
        inputStream = new ClassPathResource(VTC).getInputStream();
        contentType = "text/plain";
        extensionFile = "txt";
      } else if (MOBIFONE_NAME.equals(fileName)) {
        inputStream = new ClassPathResource(MOBIFONE).getInputStream();
        contentType = "text/plain";
        extensionFile = "dat";
      } else if (VINPLAY_NAME.equals(fileName)) {
        inputStream = new ClassPathResource(VINPLAY).getInputStream();
        contentType = "text/plain";
        extensionFile = "txt";
      }
      response.addHeader("Content-disposition", "attachment;filename=" + fileName + "." + extensionFile);
      response.setContentType(contentType);

      // Copy the stream to the response's output stream.
      IOUtils.copy(inputStream, response.getOutputStream());
      response.flushBuffer();

    } catch (IOException e) {
      log.error("Error writing file to output stream. Filename was '{}'" + fileName, e);
      throw new RuntimeException("IOError writing file to output stream");
    }
  }

  @RequestMapping(value = "/findProviderProfiles", method = RequestMethod.POST)
  @ResponseBody
  public FindProviderProfileResponse findProviderProfiles(HttpServletRequest request) throws Exception {

    //TODO ROLE

    String providerCode = request.getParameter("provider");

    FindProviderProfileRequest requestProfile = new FindProviderProfileRequest();

    requestProfile.setProviderCode(providerCode);

    return cardStoreService.findProviderProfiles(requestProfile);
  }
}
