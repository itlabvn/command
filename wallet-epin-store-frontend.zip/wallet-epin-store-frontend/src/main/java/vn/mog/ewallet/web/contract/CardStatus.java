package vn.mog.ewallet.web.contract;

public enum CardStatus {
	NOTAVAILABLE(0), IN_STOCK(1), SOLD(2), EXPIRED(3), NEAR_EXP(4);
	public int code;

	private CardStatus(int value) {
		this.code = value;
	}

	public int getCode() {
		return code;
	}
}
