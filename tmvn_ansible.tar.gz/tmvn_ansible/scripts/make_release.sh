#! /bin/bash

set -e
set -x
print_help() {
    echo "$0 <commit>"
    echo "<commit>: commit to release"
}

# Precondition checks {{{
if [ -z "$1" ]; then
    echo "Need commit"
    print_help
    exit 1
fi
commit=$(git rev-parse --short $1)

if [ -z "$JENKINS_USER" ]; then
    read -p "Enter Jenkins username: " JENKINS_USER
fi

if [ -z "$JENKINS_API_TOKEN" ]; then
    read -p "Enter Jenkins API token: " JENKINS_API_TOKEN
fi
# End precondition checks }}}

repo_uri=$(git remote get-url origin)

if ! git rev-parse refs/heads/release &>/dev/null; then
    git checkout -b release
else
    git checkout release
fi

old_head=$(git rev-parse HEAD)
git reset --hard "$commit"
git tag
read -p "nhap vao TAG phien ban tiep theo: " tag
./bin/bump_version "$tag"

trap "git tag -d $tag && git reset --hard $old_head && exit 1" INT
read -p "deploy commit $commit as $tag? Y/N: " yn
case $yn in
    [Yy] )
        git push --force --tags origin release
        version=$(git describe --tags --long)
        curl --user "$JENKINS_USER:$JENKINS_API_TOKEN" "https://ci.truemoney.com.vn/job/build-release-branch/buildWithParameters?token=e8DCtVddPvhDubLrPvm&REPO_URI=$repo_uri&APP_VERSION=$version"
        ;;
    * )
        git tag -d "$tag"
        git reset --hard "$old_head"
        exit
        ;;
esac
