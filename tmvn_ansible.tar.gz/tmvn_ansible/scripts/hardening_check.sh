echo 
echo ==== HOSTNAME: $(hostname) ====

#echo; echo ' 1.1.1.1 - 1.1.1.8 '
#modprobe -n -v cramfs 
#lsmod | grep cramfs 
#
#modprobe -n -v freevxfs
#lsmod | grep freevxfs 
#
#modprobe -n -v jffs2  
#lsmod | grep jffs2 
#
#modprobe -n -v hfs 
#lsmod | grep hfs 
#
#modprobe -n -v hfsplus 
#lsmod | grep hfsplus
#
#modprobe -n -v squashfs 
#lsmod | grep squashfs 
#
#modprobe -n -v udf 
#lsmod | grep udf 
#
#modprobe -n -v vfat 
#lsmod | grep vfat 
#echo; echo ' 1.1.3 '
#mount | grep /tmp 
#echo; echo ' 1.1.4 '
#mount | grep /tmp
#echo; echo ' 1.1.7  '
#mount | grep /var/tmp 
#echo; echo ' 1.1.8 '
#mount | grep /var/tmp
#echo; echo ' 1.1.9  '
#mount | grep /var/tmp
#echo; echo ' 1.1.21 '
#systemctl is-enabled autofs 
#echo; echo ' 1.2.1 '
#apt-cache policy 
#echo; echo ' 1.4.1 '
#stat /boot/grub/grub.cfg
#echo; echo ' 1.4.2  '
#grep "^set superusers" /boot/grub/grub.cfg 
#grep "^password" /boot/grub/grub.cfg 
echo; echo ' 1.4.3 '
grep ^root:[*\!]: /etc/shadow
#grep ^SINGLE /etc/sysconfig/init
#echo; echo ' 1.5.1 '
#grep "hard core" /etc/security/limits.conf /etc/security/limits.d/* 
#sysctl fs.suid_dumpable 
#echo; echo ' 1.5.2  '
#dmesg | grep NX 
#echo; echo ' 1.5.3 '
#sysctl kernel.randomize_va_space 
#echo; echo ' 1.5.4 '
#dpkg -s prelink
#echo; echo ' 1.7.1.2 '
#cat /etc/issue 
#echo; echo ' 1.7.1.3  '
#cat /etc/issue.net 
#echo; echo ' 1.8 '
#apt-get -s upgrade 
#echo; echo ' 2.1.1 '
#grep -R "^chargen" /etc/inetd.* 
#echo; echo ' 2.1.2 '
#grep -R "^daytime" /etc/inetd.* 
#echo; echo ' 2.1.6 '
#grep -R "^shell" /etc/inetd.* 
#grep -R "^login" /etc/inetd.*  
#grep -R "^exec" /etc/inetd.*  
#echo; echo ' 2.1.8 '
#grep -R "^telnet" /etc/inetd.* 
#echo; echo ' 2.1.9 '
#grep -R "^tftp" /etc/inetd.* 
#echo; echo ' 2.2.1.1  '
#dpkg -s ntp 
#dpkg -s chrony
echo; echo ' 2.2.1.2  '
grep "^restrict" /etc/ntp.conf 
grep "^server" /etc/ntp.conf 
grep "RUNASUSER=ntp" /etc/init.d/ntp
#echo; echo ' 2.2.1.3 '
#grep "^server" /etc/chrony/chrony.conf 
#echo; echo ' 2.2.2  '
#dpkg -l xserver-xorg* 
#echo; echo ' 2.2.4  '
#systemctl is-enabled cups
#echo; echo ' 2.2.5 '
#systemctl is-enabled isc-dhcp-server 
#systemctl is-enabled isc-dhcp-server6 
#echo; echo ' 2.2.7  '
#systemctl is-enabled nfs-kernel-server 
#echo; echo ' 2.2.9 '
#systemctl is-enabled vsftpd 
#echo; echo ' 2.2.12  '
#systemctl is-enabled smbd 
#echo; echo ' 3.1.1  '
#sysctl net.ipv4.ip_forward 
#echo; echo ' 3.1.2  '
#sysctl net.ipv4.conf.all.send_redirects 
#sysctl net.ipv4.conf.default.send_redirects 
#echo; echo ' 3.2.4 '
#sysctl net.ipv4.conf.all.log_martians  
#sysctl net.ipv4.conf.default.log_martians 
#echo; echo ' 3.2.5  '
#sysctl net.ipv4.icmp_echo_ignore_broadcasts 
#echo; echo ' 3.2.8  '
#sysctl net.ipv4.tcp_syncookies 
#echo; echo ' 3.3.1  '
#sysctl net.ipv6.conf.all.accept_ra 
#sysctl net.ipv6.conf.default.accept_ra 
#echo; echo ' 3.3.2 '
#sysctl net.ipv6.conf.all.accept_redirects 
#sysctl net.ipv6.conf.default.accept_redirects 
echo; echo ' 3.3.3 '
grep "^\s*linux" /boot/grub/grub.cfg 
#echo; echo ' 3.7 '
#iwconfig 
#echo; echo ' 4.2.1.1  '
#systemctl is-enabled rsyslog 
#echo; echo ' 4.2.1.2 '
#ls -l /var/log/
#echo; echo ' 4.2.1.3  '
#grep ^\$FileCreateMode /etc/rsyslog.conf
#echo; echo ' 4.2.1.4  '
#grep "^*.*[^I][^I]*@" /etc/rsyslog.conf
#echo; echo ' 4.2.2.1  '
#systemctl is-enabled syslog-ng 
#echo; echo ' 5.1.2  '
#stat /etc/crontab
#stat /etc/cron.hourly 
#stat /etc/cron.daily
#stat /etc/cron.weekly
#stat /etc/cron.monthly 
#echo; echo ' 5.2.1  '
#stat /etc/ssh/sshd_config 
#echo; echo ' 5.2.2  '
#grep "^Protocol" /etc/ssh/sshd_config 
#echo; echo ' 5.2.3  '
#grep "^LogLevel" /etc/ssh/sshd_config 
#echo; echo ' 5.2.4  '
#grep "^X11Forwarding" /etc/ssh/sshd_config 
#echo; echo ' 5.2.5  '
#grep "^MaxAuthTries" /etc/ssh/sshd_config 
#echo; echo ' 5.2.8  '
#grep "^PermitRootLogin" /etc/ssh/sshd_config 
#echo; echo ' 5.2.9  '
#grep "^PermitEmptyPasswords" /etc/ssh/sshd_config 
#echo; echo ' 5.2.10  '
#grep PermitUserEnvironment /etc/ssh/sshd_config 
#echo; echo ' 5.2.11  '
#grep "MACs" /etc/ssh/sshd_config
#echo; echo ' 5.2.12  '
#grep "^ClientAliveInterval" /etc/ssh/sshd_config 
#grep "^ClientAliveCountMax" /etc/ssh/sshd_config 
#echo; echo ' 5.2.15  '
#grep "^Banner" /etc/ssh/sshd_config 
#echo; echo ' 5.3.2  '
#grep "pam_tally2" /etc/pam.d/common-auth 
#echo; echo ' 5.4.1.1  '
#grep PASS_MAX_DAYS /etc/login.defs 
#echo; echo ' 6.1.2  '
#stat /etc/passwd 
#echo; echo ' 6.1.3  '
#stat /etc/shadow 
#echo; echo ' 6.2.1  '
#cat /etc/shadow | awk -F: '($2 == "" ) { print $1 " does not have a password "}'
#echo; echo ' 6.2.9  '
#cat /etc/passwd | awk -F: '{ print $1 " " $3 " " $6 }' | while read user uid dir; do 
# if [ $uid -ge 1000 -a -d "$dir" -a $user != "nfsnobody" ]; then 
# owner=$(stat -L -c "%U" "$dir") 
# if [ "$owner" != "$user" ]; then 
# echo "The home directory ($dir) of user $user is owned by $owner." 
# fi 
# fi 
#done
#echo; echo ' 6.2.18 '
#cat /etc/passwd | cut -f1 -d":" | sort -n | uniq -c | while read x ; do 
#  [ -z "${x}" ] && break 
#  set - $x 
#  if [ $1 -gt 1 ]; then 
#    uids=`awk -F: '($1 == n) { print $3 }' n=$2 /etc/passwd | xargs` 
#    echo "Duplicate User Name ($2): ${uids}" 
#  fi 
#done 
#
#echo; echo '1. Running port/services'
#netstat -an | grep -i listen
#echo
#netstat -an | grep -i est
#echo
#ps -ef
#
#echo; echo '2. Crontab startup scripts'
#ls /var/spool/cron/*/*
#
#cat /etc/crontab
#
#echo; echo '3. User review'
#getent passwd
#echo
#lastlog|grep -v monitor
