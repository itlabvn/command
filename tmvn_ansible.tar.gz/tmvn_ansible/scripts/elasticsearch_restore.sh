#!/bin/bash

set -e
#set -x

if [ -z "$1" ]; then
    echo "Missing option!"
    exit 1
fi

host="127.0.0.1"
port="9200"

while getopts ":h:p:" opt; do
    case $opt in
        h) host="$OPTARG" ;;
        p) port="$OPTARG" ;;
        \?)
            echo "Invalid option: -$OPTARG" >&2
            exit 1
            ;;
        :)
            echo "Option -$OPTARG requires an argument." >&2
            exit 1
            ;;
    esac
done

snapshot_number=0
snapshots=$(curl -s -XGET "http://${host}:${port}/_snapshot/graylog/_all?pretty" | jq -r ".snapshots[].snapshot")


##Close all index
#current_indices=$(ls -1 /var/lib/elasticsearch/graylog/nodes/0/indices)
#
#for index in ${current_indices}
#do
#    echo Closing index: ${index}
#    curl -XPOST "${host}:${port}/${index}/_close"
#done

for snapshot in ${snapshots}
do
    echo -------- ${snapshot_number} ---------
    snapshot_index=$(curl -s -XGET "http://${host}:${port}/_snapshot/graylog/_all?pretty" | jq -r ".snapshots[${snapshot_number}].indices[0]")
    echo Closing index: ${snapshot_index}
    curl -XPOST "${host}:${port}/${snapshot_index}/_close"
    echo && echo && echo Restoring snapshot: ${snapshot}
    curl -XPOST "http://${host}:${port}/_snapshot/graylog/${snapshot}/_restore?pretty"
    echo
    snapshot_number=$((${snapshot_number}+1))
    sleep 2
done
