--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 9.6.0

-- Started on 2017-05-16 17:54:14


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 8 (class 2615 OID 69075)
-- Name: bankgw; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA bankgw;

--
-- TOC entry 1 (class 3079 OID 12387)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2174 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = bankgw, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 185 (class 1259 OID 25051)
-- Name: sec_permission; Type: TABLE; Schema: bankgw; Owner: -
--

CREATE TABLE sec_permission (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    db_active character(1),
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    description character varying(255),
    name character varying(50),
    type character varying(255)
);


--
-- TOC entry 186 (class 1259 OID 25059)
-- Name: sec_role; Type: TABLE; Schema: bankgw; Owner: -
--

CREATE TABLE sec_role (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    db_active character(1),
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    description character varying(255),
    name character varying(50),
    type character varying(255)
);


--
-- TOC entry 187 (class 1259 OID 25067)
-- Name: sec_role_permission; Type: TABLE; Schema: bankgw; Owner: -
--

CREATE TABLE sec_role_permission (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    db_active character(1),
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    permission_id bigint,
    role_id bigint
);


--
-- TOC entry 188 (class 1259 OID 25072)
-- Name: sec_user; Type: TABLE; Schema: bankgw; Owner: -
--

CREATE TABLE sec_user (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    db_active character(1),
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    cif character varying(64),
    password character varying(50),
    username character varying(50)
);


--
-- TOC entry 189 (class 1259 OID 25077)
-- Name: sec_user_role; Type: TABLE; Schema: bankgw; Owner: -
--

CREATE TABLE sec_user_role (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    db_active character(1),
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    role_id bigint,
    user_id bigint
);


--
-- TOC entry 190 (class 1259 OID 25114)
-- Name: seq_id_entity; Type: SEQUENCE; Schema: bankgw; Owner: -
--

CREATE SEQUENCE seq_id_entity
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2162 (class 0 OID 25051)
-- Dependencies: 185
-- Data for Name: sec_permission; Type: TABLE DATA; Schema: bankgw; Owner: -
--

INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (1, '2015-11-02 18:36:16', 1, 'Y', '2017-02-27 03:36:32', 1, 'CTRL_USER_ADD_POST', 'CTRL_USER_ADD_POST', 'ADMIN');
INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (2, '2015-11-02 18:37:03', 1, 'Y', '2015-11-09 13:14:35', 1, 'CTRL_USER_DELETE_GET', 'CTRL_USER_DELETE_GET', 'ADMIN');
INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (5, '2015-11-02 18:37:55', 1, 'Y', '2015-11-09 13:14:38', 1, 'CTRL_USER_VIEW_GET', 'CTRL_USER_VIEW_GET', 'ADMIN');
INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (6, '2015-11-02 18:38:22', 1, 'Y', '2015-11-09 13:14:41', 1, 'CTRL_USER_EDIT_POST', 'CTRL_USER_EDIT_POST', 'ADMIN');
INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (7, '2015-11-02 18:38:43', 1, 'Y', '2015-11-09 13:14:44', 1, 'CTRL_USER_LIST_GET', 'CTRL_USER_LIST_GET', 'ADMIN');
INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (8, '2015-11-02 18:39:03', 1, 'Y', '2015-11-09 13:14:47', 1, 'CTRL_PERM_ADD_POST', 'CTRL_PERM_ADD_POST', 'ADMIN');
INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (9, '2015-11-02 18:39:41', 1, 'Y', '2015-11-09 13:14:54', 1, 'CTRL_PERM_DELETE_GET', 'CTRL_PERM_DELETE_GET', 'ADMIN');
INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (10, '2015-11-02 18:39:49', 1, 'Y', '2015-11-09 13:14:59', 1, 'CTRL_PERM_EDIT_GET', 'CTRL_PERM_EDIT_GET', 'ADMIN');
INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (11, '2015-11-02 18:40:15', 1, 'Y', '2015-11-09 13:15:03', 1, 'CTRL_PERM_EDIT_POST', 'CTRL_PERM_EDIT_POST', 'ADMIN');
INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (12, '2015-11-02 18:40:34', 1, 'Y', '2015-11-09 13:15:09', 1, 'CTRL_PERM_LIST_GET', 'CTRL_PERM_LIST_GET', 'ADMIN');
INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (13, '2015-11-02 18:41:16', 1, 'Y', '2015-11-09 13:15:11', 1, 'CTRL_ROLE_ADD_POST', 'CTRL_ROLE_ADD_POST', 'ADMIN');
INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (14, '2015-11-02 18:41:37', 1, 'Y', '2015-11-09 13:15:15', 1, 'CTRL_ROLE_DELETE_GET', 'CTRL_ROLE_DELETE_GET', 'ADMIN');
INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (15, '2015-11-02 18:41:56', 1, 'Y', '2015-11-09 13:15:18', 1, 'CTRL_ROLE_VIEW_GET', 'CTRL_ROLE_VIEW_GET', 'ADMIN');
INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (16, '2015-11-02 18:42:14', 1, 'Y', '2015-11-09 13:15:21', 1, 'CTRL_ROLE_EDIT_POST', 'CTRL_ROLE_EDIT_POST', 'ADMIN');
INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (17, '2015-11-02 18:42:32', 1, 'Y', '2015-11-09 13:15:25', 1, 'CTRL_ROLE_LIST_GET', 'CTRL_ROLE_LIST_GET', 'ADMIN');
INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (18, '2015-11-02 18:39:03', 1, 'Y', '2015-11-09 13:14:51', 1, 'CTRL_PERM_VIEW_GET', 'CTRL_PERM_VIEW_GET', 'ADMIN');
INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (23, '2015-11-10 16:08:32', 1, 'Y', '2017-02-24 15:24:33', 1, 'CTRL_PERM_ROLE_ADD_POST', 'CTRL_PERM_ROLE_ADD_POST', 'ADMIN');
INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (24, '2017-02-24 15:42:04', 1, 'Y', '2017-02-24 17:31:59', 1, 'CTRL_TEST', 'CTRL_TEST', 'USER');
INSERT INTO sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (25, '2017-02-24 17:41:33', 1, 'Y', NULL, NULL, 'CRTL_SYSTEM_TEST', 'CRTL_SYSTEM_TEST', 'SYSTEM');


--
-- TOC entry 2163 (class 0 OID 25059)
-- Dependencies: 186
-- Data for Name: sec_role; Type: TABLE DATA; Schema: bankgw; Owner: -
--

INSERT INTO sec_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (1, '2015-09-24 11:25:53', 0, 'Y', NULL, NULL, 'ROLE_SYSTEM', 'ROLE_SYSTEM', 'SYSTEM');
INSERT INTO sec_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (2, '2015-09-24 11:25:53', 0, 'Y', '2017-03-10 10:13:26', 42, 'Quản trị user', 'ROLE_ADMIN', 'ADMIN');
INSERT INTO sec_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (3, '2015-09-24 11:25:53', 0, 'N', '2017-03-10 10:13:41', 42, 'Quản lý hệ thống', 'ROLE_MANAGER', 'MANAGER');
INSERT INTO sec_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (4, '2015-09-24 11:25:53', 0, 'Y', '2017-03-08 11:59:13', 42, 'Người đăng nhập', 'ROLE_CUSTOMER', 'CUSTOMER');
INSERT INTO sec_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (5, '2015-09-24 11:25:53', 0, 'Y', '2017-03-10 10:14:09', 42, 'Nhà buôn', 'ROLE_MERCHANT', 'MERCHANT');
INSERT INTO sec_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (6, '2015-09-24 11:25:53', 0, 'Y', '2017-03-14 14:10:32', 42, 'Nhân viên', 'ROLE_STAFF', 'STAFF');
INSERT INTO sec_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (7, '2016-10-31 15:45:45', 0, 'Y', '2017-03-14 14:10:03', 42, 'Vai trò tài chính', 'ROLE_FINANCE', 'STAFF');
INSERT INTO sec_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (8, NULL, 0, 'Y', '2017-03-06 14:58:28', 42, 'Hộ hợ kinh doanh', 'ROLE_SALE_SUPPORT', 'STAFF');
INSERT INTO sec_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (9, '2017-01-17 15:34:09', 0, 'Y', '2017-03-14 14:09:47', 42, 'Quản lý kinh doanh', 'ROLE_SALE_MANAGER', 'STAFF');
INSERT INTO sec_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (10, '2017-02-06 10:38:16', 0, 'Y', '2017-03-14 14:10:18', 42, 'Nhân viên kinh doanh', 'ROLE_SALE', 'STAFF');
INSERT INTO sec_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (11, '2017-02-06 11:20:11', 0, 'Y', '2017-03-14 14:09:33', 42, 'Chăm sóc khác hàng', 'ROLE_CUSTOMER_CARE', 'STAFF');
INSERT INTO sec_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (12, '2017-03-06 14:10:30', 0, 'Y', '2017-03-08 11:42:49', 42, 'Quản lý vận hành hệ thống', 'ROLE_SYSTEM_ADMIN', 'ADMIN');
INSERT INTO sec_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (13, '2017-03-06 14:59:12', 0, 'Y', NULL, NULL, 'Đối soát', 'ROLE_RECONCILIATION', 'STAFF');
INSERT INTO sec_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) VALUES (14, '2017-03-06 15:41:39', 0, 'Y', NULL, NULL, 'Hỗ trợ kĩ thuật', 'ROLE_TECH_SUPPORT', 'STAFF');


--
-- TOC entry 2164 (class 0 OID 25067)
-- Dependencies: 187
-- Data for Name: sec_role_permission; Type: TABLE DATA; Schema: bankgw; Owner: -
--

INSERT INTO sec_role_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, permission_id, role_id) VALUES (4, '2017-03-01 03:49:55', 1, 'Y', NULL, NULL, 2, 3);
INSERT INTO sec_role_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, permission_id, role_id) VALUES (5, '2017-03-01 03:49:55', 1, 'Y', NULL, NULL, 2, 10);
INSERT INTO sec_role_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, permission_id, role_id) VALUES (30, '2017-03-01 09:29:26', 1, 'Y', NULL, NULL, 1, 8);
INSERT INTO sec_role_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, permission_id, role_id) VALUES (31, '2017-03-01 09:29:26', 1, 'Y', NULL, NULL, 1, 1);


--
-- TOC entry 2165 (class 0 OID 25072)
-- Dependencies: 188
-- Data for Name: sec_user; Type: TABLE DATA; Schema: bankgw; Owner: -
--

INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (1, '2015-09-24 11:25:53', 0, 'Y', '2017-03-06 18:11:05', 1, '0000000005', 'e10adc3949ba59abbe56e057f20f883e', 'admin@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (6, '2016-03-15 12:02:10', 1, 'Y', NULL, NULL, '0000000012', 'e10adc3949ba59abbe56e057f20f883e', 'sale.support@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (12, '2016-03-16 00:43:20', 1, 'Y', '2017-03-09 18:08:54', 1, '0000000044', 'e10adc3949ba59abbe56e057f20f883e', 'merchant@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (13, '2016-03-22 00:11:10', 1, 'Y', '2017-03-10 11:04:21', 1, '0000000019', 'e10adc3949ba59abbe56e057f20f883e', 'finance@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (24, '2016-09-17 10:58:47', 1, 'Y', NULL, NULL, '0000000021', 'e10adc3949ba59abbe56e057f20f883e', 'customer.care@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (28, '2016-03-15 12:02:10', 1, 'Y', NULL, NULL, '0000000022', 'e10adc3949ba59abbe56e057f20f883e', 'sale.manager@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (29, '2016-03-15 12:02:10', 1, 'Y', '2017-03-10 11:28:43', 1, '0000000047', 'e10adc3949ba59abbe56e057f20f883e', 'sale@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (31, '2017-02-22 17:21:21', 1, 'Y', '2017-03-09 18:09:16', 1, '0000000043', 'e10adc3949ba59abbe56e057f20f883e', 'merchant001@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (34, '2017-02-22 17:25:56', 1, 'Y', '2017-03-09 18:09:27', 1, '0000000046', 'e10adc3949ba59abbe56e057f20f883e', 'merchant002@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (38, '2017-03-02 09:39:31', 1, 'N', NULL, NULL, '0000000049', 'e10adc3949ba59abbe56e057f20f883e', 'test_huhu@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (42, '2017-03-06 14:08:32', 1, 'Y', NULL, NULL, '0000000053', 'e10adc3949ba59abbe56e057f20f883e', 'system@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (43, '2017-03-06 14:38:59', 1, 'Y', '2017-03-06 15:00:00', 1, '0000000054', 'e10adc3949ba59abbe56e057f20f883e', 'reconciliation@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (44, '2017-03-06 15:16:12', 1, 'Y', '2017-03-06 15:46:26', 1, '0000000055', 'e10adc3949ba59abbe56e057f20f883e', 'tech.support@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (45, '2017-03-06 16:18:05', 1, 'N', '2017-03-06 16:18:51', 1, '0000000056', 'e10adc3949ba59abbe56e057f20f883e', 'test.sale.support@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (46, '2017-03-08 13:55:50', 1, 'Y', NULL, NULL, '0000000057', 'e10adc3949ba59abbe56e057f20f883e', 'minh.sale@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (47, '2017-03-08 14:25:29', 1, 'Y', NULL, NULL, '0000000058', 'e10adc3949ba59abbe56e057f20f883e', 'merchant.test@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (48, '2017-03-08 14:36:11', 1, 'Y', '2017-03-08 14:36:31', 1, '0000000059', 'e10adc3949ba59abbe56e057f20f883e', 'sale.support.test@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (49, '2017-03-08 14:41:22', 1, 'Y', NULL, NULL, '0000000060', 'e10adc3949ba59abbe56e057f20f883e', 'haihai@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (52, '2017-03-09 14:32:12', 1, 'Y', NULL, NULL, '0000000063', 'e10adc3949ba59abbe56e057f20f883e', 'sale.support.test_11@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (53, '2017-03-09 14:34:34', 1, 'Y', NULL, NULL, '0000000064', 'e10adc3949ba59abbe56e057f20f883e', 'sale.support.test_22@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (54, '2017-03-09 14:40:23', 1, 'Y', NULL, NULL, '0000000065', 'e10adc3949ba59abbe56e057f20f883e', 'sale.support.test_33@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (55, '2017-03-09 14:41:18', 1, 'Y', '2017-03-09 14:41:35', 1, '0000000066', 'e10adc3949ba59abbe56e057f20f883e', 'sale.support.test_444@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (56, '2017-03-09 14:47:00', 1, 'Y', '2017-03-09 14:53:23', 1, '0000000067', 'e10adc3949ba59abbe56e057f20f883e', 'sale.support.test_77@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (57, '2017-03-10 10:10:59', 1, 'Y', NULL, NULL, '0000000068', 'e10adc3949ba59abbe56e057f20f883e', 'merchang_test_11@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (58, '2017-03-10 10:11:58', 1, 'Y', NULL, NULL, '0000000069', 'e10adc3949ba59abbe56e057f20f883e', 'staff_test_33@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (61, '2017-03-14 11:22:51', 1, 'Y', NULL, NULL, '0000000072', '96e79218965eb72c92a549dd5a330112', 'binhminh.merchant');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (63, '2017-03-15 14:50:37', 6, 'Y', NULL, NULL, '0000000073', 'e10adc3949ba59abbe56e057f20f883e', 'binhminh.customer');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (67, '2017-03-15 14:58:10', 6, 'Y', NULL, NULL, '0000000077', 'e10adc3949ba59abbe56e057f20f883e', 'binhminh.merchant.111');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (68, '2017-03-15 15:03:53', 6, 'Y', NULL, NULL, '0000000078', 'e10adc3949ba59abbe56e057f20f883e', 'binhminh.customer.111');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (69, '2017-03-15 15:09:06', 6, 'Y', NULL, NULL, '0000000079', 'e10adc3949ba59abbe56e057f20f883e', 'binhminh.customer.222');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (70, '2017-03-15 15:13:09', 6, 'Y', NULL, NULL, '0000000080', 'e10adc3949ba59abbe56e057f20f883e', 'binhminh.customer.333');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (71, '2017-03-15 15:26:14', 6, 'Y', NULL, NULL, '0000000081', 'e10adc3949ba59abbe56e057f20f883e', 'customer00001@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (73, '2017-03-15 15:30:15', 6, 'Y', NULL, NULL, '0000000083', 'e10adc3949ba59abbe56e057f20f883e', 'customer00002@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (75, '2017-03-15 15:33:17', 6, 'Y', NULL, NULL, '0000000085', 'e10adc3949ba59abbe56e057f20f883e', 'customer00004@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (76, '2017-03-15 15:35:08', 6, 'Y', NULL, NULL, '0000000086', 'e10adc3949ba59abbe56e057f20f883e', 'customer00005@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (77, '2017-03-15 15:36:03', 6, 'Y', NULL, NULL, '0000000087', 'e10adc3949ba59abbe56e057f20f883e', 'customer00006@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (78, '2017-03-15 15:43:45', 6, 'Y', NULL, NULL, '0000000088', 'e10adc3949ba59abbe56e057f20f883e', 'binhminh.customer.444');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (79, '2017-03-15 15:44:06', 6, 'Y', NULL, NULL, '0000000089', 'e10adc3949ba59abbe56e057f20f883e', 'binhminh.customer.555');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (80, '2017-03-15 15:46:13', 6, 'Y', NULL, NULL, '0000000090', 'e10adc3949ba59abbe56e057f20f883e', 'binhminh.merchant.222');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (81, '2017-03-15 15:47:42', 6, 'Y', NULL, NULL, '0000000091', 'e10adc3949ba59abbe56e057f20f883e', 'customer00007@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (82, '2017-03-15 16:24:53', 1, 'Y', NULL, NULL, '0000000092', '05dde363e48d57c5b88a39f7ce44c656', 'merchant000001@truemoney.com.vn');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (83, '2017-03-15 18:01:15', 6, 'Y', NULL, NULL, '0000000093', 'e10adc3949ba59abbe56e057f20f883e', 'binhminh.customer.666');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (84, '2017-03-15 19:33:29', 6, 'Y', NULL, NULL, '0000000094', 'e10adc3949ba59abbe56e057f20f883e', 'binhminh.customer.777');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (85, '2017-03-17 15:09:34', 1, 'Y', NULL, NULL, '0000000095', 'e10adc3949ba59abbe56e057f20f883e', 'luulien');
INSERT INTO sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) VALUES (86, '2017-03-24 16:25:34', 1, 'Y', NULL, NULL, '0000000096', 'e10adc3949ba59abbe56e057f20f883e', 'customer@truemoney.com.vn');


--
-- TOC entry 2166 (class 0 OID 25077)
-- Dependencies: 189
-- Data for Name: sec_user_role; Type: TABLE DATA; Schema: bankgw; Owner: -
--

INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (26, '2016-09-17 10:58:47', 1, 'Y', NULL, NULL, 11, 24);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (37, '2016-09-17 10:58:47', 1, 'Y', '2016-09-17 10:58:47', 1, 9, 28);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (41, '2016-03-15 12:02:10', 1, 'Y', '2016-03-15 12:02:10', 1, 8, 6);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (95, '2017-02-28 11:30:50', 1, 'Y', NULL, NULL, 6, 6);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (98, '2017-02-28 11:32:24', 1, 'Y', NULL, NULL, 6, 24);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (99, '2017-02-28 11:32:53', 1, 'Y', NULL, NULL, 6, 28);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (104, '2017-03-02 09:39:31', 1, 'Y', NULL, NULL, 4, 38);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (109, '2017-03-06 14:12:24', 0, 'Y', NULL, NULL, 1, 42);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (110, '2017-03-06 14:12:50', 0, 'Y', NULL, NULL, 6, 42);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (115, '2017-03-06 15:00:01', 1, 'Y', NULL, NULL, 6, 43);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (116, '2017-03-06 15:00:01', 1, 'Y', NULL, NULL, 13, 43);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (120, '2017-03-06 15:46:26', 1, 'Y', NULL, NULL, 6, 44);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (121, '2017-03-06 15:46:26', 1, 'Y', NULL, NULL, 14, 44);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (124, '2017-03-06 16:18:51', 1, 'Y', NULL, NULL, 8, 45);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (125, '2017-03-06 16:18:51', 1, 'Y', NULL, NULL, 4, 45);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (126, '2017-03-06 16:18:51', 1, 'Y', NULL, NULL, 6, 45);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (128, '2017-03-06 18:11:05', 1, 'Y', NULL, NULL, 2, 1);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (129, '2017-03-06 18:11:05', 1, 'Y', NULL, NULL, 3, 1);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (131, '2017-03-06 18:11:05', 1, 'Y', NULL, NULL, 6, 1);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (132, '2017-03-08 13:55:50', 1, 'Y', NULL, NULL, 4, 46);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (133, '2017-03-08 13:55:50', 1, 'Y', NULL, NULL, 6, 46);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (134, '2017-03-08 14:25:29', 1, 'Y', NULL, NULL, 4, 47);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (135, '2017-03-08 14:25:29', 1, 'Y', NULL, NULL, 5, 47);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (138, '2017-03-08 14:36:31', 1, 'Y', NULL, NULL, 8, 48);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (139, '2017-03-08 14:36:31', 1, 'Y', NULL, NULL, 6, 48);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (140, '2017-03-08 14:41:22', 1, 'Y', NULL, NULL, 4, 49);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (141, '2017-03-08 14:41:22', 1, 'Y', NULL, NULL, 6, 49);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (142, '2017-03-08 15:49:27', 1, 'Y', NULL, NULL, 4, 48);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (143, '2017-03-09 14:32:13', 1, 'Y', NULL, NULL, 4, 52);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (144, '2017-03-09 14:32:13', 1, 'Y', NULL, NULL, 5, 52);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (145, '2017-03-09 14:34:34', 1, 'Y', NULL, NULL, 4, 53);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (146, '2017-03-09 14:34:34', 1, 'Y', NULL, NULL, 5, 53);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (147, '2017-03-09 14:40:23', 1, 'Y', NULL, NULL, 4, 54);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (148, '2017-03-09 14:40:23', 1, 'Y', NULL, NULL, 5, 54);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (151, '2017-03-09 14:41:35', 1, 'Y', NULL, NULL, 4, 55);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (152, '2017-03-09 14:41:35', 1, 'Y', NULL, NULL, 6, 55);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (153, '2017-03-09 14:41:35', 1, 'Y', NULL, NULL, 10, 55);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (159, '2017-03-09 14:53:23', 1, 'Y', NULL, NULL, 8, 56);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (160, '2017-03-09 14:53:23', 1, 'Y', NULL, NULL, 4, 56);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (161, '2017-03-09 14:53:23', 1, 'Y', NULL, NULL, 6, 56);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (163, '2017-03-09 18:08:54', 1, 'Y', NULL, NULL, 5, 12);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (166, '2017-03-09 18:09:16', 1, 'Y', NULL, NULL, 4, 31);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (167, '2017-03-09 18:09:16', 1, 'Y', NULL, NULL, 5, 31);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (168, '2017-03-09 18:09:27', 1, 'Y', NULL, NULL, 4, 34);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (169, '2017-03-09 18:09:27', 1, 'Y', NULL, NULL, 5, 34);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (170, '2017-03-10 10:11:00', 1, 'Y', NULL, NULL, 4, 57);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (171, '2017-03-10 10:11:00', 1, 'Y', NULL, NULL, 5, 57);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (172, '2017-03-10 10:11:58', 1, 'Y', NULL, NULL, 4, 58);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (173, '2017-03-10 10:11:58', 1, 'Y', NULL, NULL, 6, 58);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (176, '2017-03-10 11:04:21', 1, 'Y', NULL, NULL, 6, 13);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (177, '2017-03-10 11:04:21', 1, 'Y', NULL, NULL, 7, 13);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (179, '2017-03-10 11:28:43', 1, 'Y', NULL, NULL, 6, 29);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (180, '2017-03-10 11:28:43', 1, 'Y', NULL, NULL, 10, 29);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (181, '2017-03-14 11:22:51', 1, 'Y', NULL, NULL, 4, 61);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (182, '2017-03-14 11:22:51', 1, 'Y', NULL, NULL, 5, 61);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (184, '2017-03-15 14:50:39', 6, 'Y', NULL, NULL, 4, 63);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (185, '2017-03-15 14:58:10', 6, 'Y', NULL, NULL, 4, 67);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (186, '2017-03-15 14:58:11', 6, 'Y', NULL, NULL, 5, 67);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (187, '2017-03-15 15:03:55', 6, 'Y', NULL, NULL, 4, 68);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (188, '2017-03-15 15:09:06', 6, 'Y', NULL, NULL, 4, 69);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (189, '2017-03-15 15:13:11', 6, 'Y', NULL, NULL, 4, 70);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (190, '2017-03-15 15:26:23', 6, 'Y', NULL, NULL, 4, 71);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (191, '2017-03-15 15:26:24', 6, 'Y', NULL, NULL, 5, 71);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (192, '2017-03-15 15:30:20', 6, 'Y', NULL, NULL, 4, 73);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (193, '2017-03-15 15:30:20', 6, 'Y', NULL, NULL, 5, 73);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (194, '2017-03-15 15:33:20', 6, 'Y', NULL, NULL, 4, 75);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (195, '2017-03-15 15:33:20', 6, 'Y', NULL, NULL, 5, 75);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (196, '2017-03-15 15:35:13', 6, 'Y', NULL, NULL, 4, 76);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (197, '2017-03-15 15:35:13', 6, 'Y', NULL, NULL, 5, 76);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (198, '2017-03-15 15:36:07', 6, 'Y', NULL, NULL, 4, 77);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (199, '2017-03-15 15:36:07', 6, 'Y', NULL, NULL, 5, 77);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (200, '2017-03-15 15:43:47', 6, 'Y', NULL, NULL, 4, 78);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (201, '2017-03-15 15:44:08', 6, 'Y', NULL, NULL, 4, 79);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (202, '2017-03-15 15:46:15', 6, 'Y', NULL, NULL, 4, 80);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (203, '2017-03-15 15:46:15', 6, 'Y', NULL, NULL, 5, 80);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (204, '2017-03-15 15:47:47', 6, 'Y', NULL, NULL, 4, 81);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (205, '2017-03-15 15:47:47', 6, 'Y', NULL, NULL, 5, 81);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (206, '2017-03-15 16:24:57', 1, 'Y', NULL, NULL, 5, 82);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (207, '2017-03-15 18:01:17', 6, 'Y', NULL, NULL, 4, 83);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (208, '2017-03-15 19:33:32', 6, 'Y', NULL, NULL, 4, 84);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (209, '2017-03-17 15:09:34', 1, 'Y', NULL, NULL, 4, 85);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (210, '2017-03-17 15:09:34', 1, 'Y', NULL, NULL, 6, 85);
INSERT INTO sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) VALUES (211, '2017-03-24 16:25:34', 1, 'Y', NULL, NULL, 4, 86);


--
-- TOC entry 2175 (class 0 OID 0)
-- Dependencies: 190
-- Name: seq_id_entity; Type: SEQUENCE SET; Schema: bankgw; Owner: -
--

SELECT pg_catalog.setval('seq_id_entity', 1, false);


--
-- TOC entry 2020 (class 2606 OID 25058)
-- Name: sec_permission sec_permission_pkey; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY sec_permission
    ADD CONSTRAINT sec_permission_pkey PRIMARY KEY (id);


--
-- TOC entry 2028 (class 2606 OID 25071)
-- Name: sec_role_permission sec_role_permission_pkey; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY sec_role_permission
    ADD CONSTRAINT sec_role_permission_pkey PRIMARY KEY (id);


--
-- TOC entry 2024 (class 2606 OID 25066)
-- Name: sec_role sec_role_pkey; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY sec_role
    ADD CONSTRAINT sec_role_pkey PRIMARY KEY (id);


--
-- TOC entry 2032 (class 2606 OID 25076)
-- Name: sec_user sec_user_pkey; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY sec_user
    ADD CONSTRAINT sec_user_pkey PRIMARY KEY (id);


--
-- TOC entry 2038 (class 2606 OID 25081)
-- Name: sec_user_role sec_user_role_pkey; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY sec_user_role
    ADD CONSTRAINT sec_user_role_pkey PRIMARY KEY (id);


--
-- TOC entry 2034 (class 2606 OID 25091)
-- Name: sec_user uk_46psvtdbgrirs6s7ib5d3hs49; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY sec_user
    ADD CONSTRAINT uk_46psvtdbgrirs6s7ib5d3hs49 UNIQUE (username);


--
-- TOC entry 2022 (class 2606 OID 25083)
-- Name: sec_permission uk_820njc06hnbad2iocijr5qla4; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY sec_permission
    ADD CONSTRAINT uk_820njc06hnbad2iocijr5qla4 UNIQUE (name);


--
-- TOC entry 2040 (class 2606 OID 25093)
-- Name: sec_user_role uk_b3jwa7gpeo0hk4obl3fp59i4w; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY sec_user_role
    ADD CONSTRAINT uk_b3jwa7gpeo0hk4obl3fp59i4w UNIQUE (user_id, role_id);


--
-- TOC entry 2030 (class 2606 OID 25087)
-- Name: sec_role_permission uk_ea4cysdh3ecv394w7e4mpsgsw; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY sec_role_permission
    ADD CONSTRAINT uk_ea4cysdh3ecv394w7e4mpsgsw UNIQUE (role_id, permission_id);


--
-- TOC entry 2036 (class 2606 OID 25089)
-- Name: sec_user uk_n94cyl9fx3bjip0xmsca8ih4s; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY sec_user
    ADD CONSTRAINT uk_n94cyl9fx3bjip0xmsca8ih4s UNIQUE (cif);


--
-- TOC entry 2026 (class 2606 OID 25085)
-- Name: sec_role uk_q7bwxajjqg1q793atxs86mhgb; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY sec_role
    ADD CONSTRAINT uk_q7bwxajjqg1q793atxs86mhgb UNIQUE (name);


--
-- TOC entry 2042 (class 2606 OID 25099)
-- Name: sec_role_permission fk_11bhxwecd6edt844yj58g7i5j; Type: FK CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY sec_role_permission
    ADD CONSTRAINT fk_11bhxwecd6edt844yj58g7i5j FOREIGN KEY (role_id) REFERENCES sec_role(id);


--
-- TOC entry 2041 (class 2606 OID 25094)
-- Name: sec_role_permission fk_80tauu2sw4oj6qpnl4diktv99; Type: FK CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY sec_role_permission
    ADD CONSTRAINT fk_80tauu2sw4oj6qpnl4diktv99 FOREIGN KEY (permission_id) REFERENCES sec_permission(id);


--
-- TOC entry 2044 (class 2606 OID 25109)
-- Name: sec_user_role fk_kt2eg5ytt9hnlpxb9ldxjp6k8; Type: FK CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY sec_user_role
    ADD CONSTRAINT fk_kt2eg5ytt9hnlpxb9ldxjp6k8 FOREIGN KEY (user_id) REFERENCES sec_user(id);


--
-- TOC entry 2043 (class 2606 OID 25104)
-- Name: sec_user_role fk_tropn3rq81iwv8nqfed5bgi3g; Type: FK CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY sec_user_role
    ADD CONSTRAINT fk_tropn3rq81iwv8nqfed5bgi3g FOREIGN KEY (role_id) REFERENCES sec_role(id);


-- Completed on 2017-05-16 17:54:15

--
-- PostgreSQL database dump complete
--

