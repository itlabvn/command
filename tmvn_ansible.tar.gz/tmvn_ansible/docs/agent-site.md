## Deployment notes for first version

- Run this SQL so TrueService will accept new service for agent site
```
INSERT INTO "public"."apps" ("service", "api_key", "api_secret", "staff__id", "created_at", "updated_at", "platform")
VALUES ('true', 'hmd68po8vjk426veqv7j', 'hkzgwvqgl3s3u1essfjhn2hwevylr3a4', NULL, NULL, NULL, 'agent');

UPDATE sys_system_preference
SET value='["mobile","terminal","web","banking","sale","system","agent"]'
WHERE "variable"='service_gateway';
```

- Refresh TrueService's cache
```
curl http://localhost:10501/TrueService/service/clear_cache_app_key -d ''
curl http://localhost:10501/TrueService/service/clear_cache_system_preferences -d ''
```

- Deploy as usual
