--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 9.6.0

-- Started on 2017-05-16 17:52:12


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 8 (class 2615 OID 69075)
-- Name: bankgw; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA bankgw;

--
-- TOC entry 1 (class 3079 OID 12387)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 2243 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = bankgw, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 185 (class 1259 OID 25397)
-- Name: bank_profiles; Type: TABLE; Schema: bankgw; Owner: -
--

CREATE TABLE bank_profiles (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    accountant_email character varying(255),
    accountant_name character varying(255),
    accountant_phone character varying(255),
    accountant_sky character varying(255),
    address character varying(255),
    bank character varying(255),
    bank_account_number character varying(255),
    bank_branch character varying(255),
    bankname character varying(255),
    banknameeng character varying(255),
    businesss_email character varying(255),
    businesss_name character varying(255),
    businesss_phone character varying(255),
    businesss_sky character varying(255),
    card_holder character varying(255),
    contract_number character varying(255),
    create_time timestamp without time zone,
    customercare_email character varying(255),
    customercare_name character varying(255),
    customercare_sky character varying(255),
    customercare_phone character varying(255),
    date_end timestamp without time zone,
    date_sign timestamp without time zone,
    ordercode character varying(255),
    paymentcycle character varying(255),
    provider_type character varying(255),
    service character varying(255),
    shortname character varying(255),
    status timestamp without time zone,
    swiftcode character varying(64),
    technical_email character varying(255),
    technical_name character varying(255),
    technical_phone character varying(255),
    technical_sky character varying(255),
    urlfile character varying(255)
);


--
-- TOC entry 186 (class 1259 OID 25405)
-- Name: biz_api_account; Type: TABLE; Schema: bankgw; Owner: -
--

CREATE TABLE biz_api_account (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    account_status character varying(255),
    code character varying(6) NOT NULL,
    failed_counter integer,
    ips character varying(255),
    partner_bankgw_key text,
    password character varying(56) NOT NULL,
    username character varying(32) NOT NULL,
    customer_id bigint NOT NULL
);


--
-- TOC entry 187 (class 1259 OID 25413)
-- Name: biz_customer; Type: TABLE; Schema: bankgw; Owner: -
--

CREATE TABLE biz_customer (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    auth_url character varying(255),
    cif character varying(255),
    customer_type character varying(255),
    email character varying(255),
    full_name character varying(255),
    msisdn character varying(255),
    password character varying(255),
    secret character varying(255),
    customer_status character varying(255),
    username character varying(255)
);


--
-- TOC entry 188 (class 1259 OID 25421)
-- Name: biz_customer_attribute; Type: TABLE; Schema: bankgw; Owner: -
--

CREATE TABLE biz_customer_attribute (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    cif character varying(255) NOT NULL,
    bol_status character(1) NOT NULL,
    key_attribute character varying(255) NOT NULL,
    service_type character varying(255),
    value_attribute character varying(255) NOT NULL
);


--
-- TOC entry 189 (class 1259 OID 25429)
-- Name: cnf_provider_connection; Type: TABLE; Schema: bankgw; Owner: -
--

CREATE TABLE cnf_provider_connection (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    api_url character varying(255),
    bol_active character(1) NOT NULL,
    bol_hidden character(1) NOT NULL,
    bol_support_check_balance character(1) NOT NULL,
    discount double precision,
    error_rate double precision,
    name character varying(255),
    provider_code character varying(255),
    relation_ship double precision
);


--
-- TOC entry 190 (class 1259 OID 25437)
-- Name: cnf_provider_service; Type: TABLE; Schema: bankgw; Owner: -
--

CREATE TABLE cnf_provider_service (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    bol_active character(1) NOT NULL,
    provider_code character varying(255),
    service_code character varying(255),
    service_desc character varying(255),
    service_functions character varying(255),
    service_name character varying(255),
    service_prices character varying(255),
    service_type character varying(255),
    telco_service_type character varying(255),
    telco_type character varying(255)
);


--
-- TOC entry 191 (class 1259 OID 25445)
-- Name: cnf_service; Type: TABLE; Schema: bankgw; Owner: -
--

CREATE TABLE cnf_service (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    service_code character varying(255),
    service_desc character varying(255),
    service_name character varying(255),
    service_prices character varying(255),
    service_type character varying(255),
    telco_service_type character varying(255),
    telco_type character varying(255),
    parent_id bigint
);


--
-- TOC entry 192 (class 1259 OID 25453)
-- Name: cnf_service_config; Type: TABLE; Schema: bankgw; Owner: -
--

CREATE TABLE cnf_service_config (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    commision double precision,
    customer_type character varying(255),
    fee double precision,
    service_id bigint
);


--
-- TOC entry 193 (class 1259 OID 25458)
-- Name: cnf_service_config_detail; Type: TABLE; Schema: bankgw; Owner: -
--

CREATE TABLE cnf_service_config_detail (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    commision double precision,
    fee double precision,
    customer_id bigint,
    service_id bigint
);


--
-- TOC entry 194 (class 1259 OID 25463)
-- Name: cnf_telco; Type: TABLE; Schema: bankgw; Owner: -
--

CREATE TABLE cnf_telco (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    prefix character varying(255),
    telco_type character varying(255)
);


--
-- TOC entry 197 (class 1259 OID 25533)
-- Name: seq_id_entity; Type: SEQUENCE; Schema: bankgw; Owner: -
--

CREATE SEQUENCE seq_id_entity
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 195 (class 1259 OID 25471)
-- Name: store_seq; Type: TABLE; Schema: bankgw; Owner: -
--

CREATE TABLE store_seq (
    id_seq bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    seq_name character varying(255) NOT NULL,
    seq_value bigint NOT NULL
);


--
-- TOC entry 196 (class 1259 OID 25476)
-- Name: transaction_history; Type: TABLE; Schema: bankgw; Owner: -
--

CREATE TABLE transaction_history (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    address character varying(255),
    agencysend character varying(255),
    amount numeric(19,2),
    bankcardagencysend character varying(255),
    bankcode character varying(255),
    banknameagencysend character varying(255),
    cardname character varying(255),
    cardnumber character varying(255),
    customername character varying(255),
    idno character varying(255),
    merchant character varying(255),
    ordercode character varying(255),
    phonenumber character varying(255),
    receiveagency character varying(255),
    receivebankcard character varying(255),
    receivebankname character varying(255),
    receivecustomer character varying(255),
    receivecustomeridno character varying(255),
    receivepphone character varying(255),
    receivewalletcode character varying(255),
    servicetype character varying(64),
    status character varying(255),
    totalamount numeric(19,2),
    traceid character varying(255),
    transcustomer character varying(255),
    transcustomeridno character varying(255),
    transid character varying(64),
    transcustomerphone character varying(255),
    transtype character varying(255),
    transactiondate timestamp without time zone,
    transactionfee numeric(19,2),
    typecustomer character varying(255),
    walletcode character varying(255),
    walletcodesend character varying(255)
);


--
-- TOC entry 2224 (class 0 OID 25397)
-- Dependencies: 185
-- Data for Name: bank_profiles; Type: TABLE DATA; Schema: bankgw; Owner: -
--

INSERT INTO bank_profiles (id, created_time, creator_id, last_updated_time, last_updated_id, accountant_email, accountant_name, accountant_phone, accountant_sky, address, bank, bank_account_number, bank_branch, bankname, banknameeng, businesss_email, businesss_name, businesss_phone, businesss_sky, card_holder, contract_number, create_time, customercare_email, customercare_name, customercare_sky, customercare_phone, date_end, date_sign, ordercode, paymentcycle, provider_type, service, shortname, status, swiftcode, technical_email, technical_name, technical_phone, technical_sky, urlfile) VALUES (1, NULL, NULL, NULL, NULL, 'cuc@gmail.com', 'Nguyễn Kim Cúc', '0987345123', NULL, 'Thái Hà -Đống Đa- Hà Nội', 'TPBV', '0423658236', 'Thái Hà ', 'Ngân hàng Tiên Phong', NULL, 'lan@gmail.com', 'Nguyễn thị Lan', '0987345789', NULL, 'NGUYEN VAN A', NULL, NULL, '', '', NULL, NULL, NULL, NULL, '213547658', '15', NULL, 'Ecom,Ewallet', NULL, NULL, 'TPB', 'kim@gmail.com', 'Nguyễn thị Kim', '0987234890', NULL, NULL);
INSERT INTO bank_profiles (id, created_time, creator_id, last_updated_time, last_updated_id, accountant_email, accountant_name, accountant_phone, accountant_sky, address, bank, bank_account_number, bank_branch, bankname, banknameeng, businesss_email, businesss_name, businesss_phone, businesss_sky, card_holder, contract_number, create_time, customercare_email, customercare_name, customercare_sky, customercare_phone, date_end, date_sign, ordercode, paymentcycle, provider_type, service, shortname, status, swiftcode, technical_email, technical_name, technical_phone, technical_sky, urlfile) VALUES (2, NULL, NULL, NULL, NULL, 'cuc@gmail.com', 'Nguyễn Kim Cúc', '0987345123', NULL, 'Thái Hà -Đống Đa- Hà Nội', 'TPBV', '0423658236', 'Thái Hà ', 'Ngân hàng Tiên Phong', NULL, 'lan@gmail.com', 'Nguyễn thị Lan', '0987345789', NULL, 'NGUYEN VAN A', NULL, NULL, '', '', NULL, NULL, NULL, NULL, '213547658', '15', NULL, 'Ecom,Ewallet,BankTransfer', NULL, NULL, 'ABC', 'kim@gmail.com', 'Nguyễn thị Kim', '0987234890', NULL, NULL);
INSERT INTO bank_profiles (id, created_time, creator_id, last_updated_time, last_updated_id, accountant_email, accountant_name, accountant_phone, accountant_sky, address, bank, bank_account_number, bank_branch, bankname, banknameeng, businesss_email, businesss_name, businesss_phone, businesss_sky, card_holder, contract_number, create_time, customercare_email, customercare_name, customercare_sky, customercare_phone, date_end, date_sign, ordercode, paymentcycle, provider_type, service, shortname, status, swiftcode, technical_email, technical_name, technical_phone, technical_sky, urlfile) VALUES (3, NULL, NULL, NULL, NULL, '', 'Tan', '0987465243', NULL, 'Thái Hà -Hà Nội', 'SEAV', '', '', 'TECKCOMBANK', NULL, '', 'Kim', '0987465243', NULL, '', NULL, NULL, '', 'Nam', NULL, NULL, NULL, NULL, '4354754', '15', NULL, 'Ecom,Ewallet,BankTransfer', NULL, NULL, 'TECKCOMBANK', '', 'Hoang', '0987465243', NULL, NULL);
INSERT INTO bank_profiles (id, created_time, creator_id, last_updated_time, last_updated_id, accountant_email, accountant_name, accountant_phone, accountant_sky, address, bank, bank_account_number, bank_branch, bankname, banknameeng, businesss_email, businesss_name, businesss_phone, businesss_sky, card_holder, contract_number, create_time, customercare_email, customercare_name, customercare_sky, customercare_phone, date_end, date_sign, ordercode, paymentcycle, provider_type, service, shortname, status, swiftcode, technical_email, technical_name, technical_phone, technical_sky, urlfile) VALUES (4, NULL, NULL, NULL, NULL, '', 'Tan', '0987465243', NULL, 'Thái Hà -Hà Nội', 'SEAV', '423554645', 'Hà Nội', 'TECKCOMBANK', NULL, '', 'Kim', '0987465243', NULL, '', NULL, '2017-05-15 17:33:30.05', '', 'Nam', NULL, NULL, NULL, NULL, '4354754', '15', NULL, 'Ecom,Ewallet,BankTransfer', NULL, NULL, 'TECKCOM', '', 'Hoang', '0987465243', NULL, NULL);
INSERT INTO bank_profiles (id, created_time, creator_id, last_updated_time, last_updated_id, accountant_email, accountant_name, accountant_phone, accountant_sky, address, bank, bank_account_number, bank_branch, bankname, banknameeng, businesss_email, businesss_name, businesss_phone, businesss_sky, card_holder, contract_number, create_time, customercare_email, customercare_name, customercare_sky, customercare_phone, date_end, date_sign, ordercode, paymentcycle, provider_type, service, shortname, status, swiftcode, technical_email, technical_name, technical_phone, technical_sky, urlfile) VALUES (5, NULL, NULL, NULL, NULL, '', 'hoang', '0987567345', NULL, 'Hà Nội', 'SEAV', '', '', 'Ngân Hàng quân đội', NULL, '', 'kim', '0987567345', NULL, '', NULL, '2017-05-15 17:35:11.763', '', '', NULL, NULL, NULL, NULL, '234235', '15', NULL, 'Ecom,Ewallet,BankTransfer', NULL, NULL, 'MBBANK', '', 'nam', '0987567345', NULL, NULL);
INSERT INTO bank_profiles (id, created_time, creator_id, last_updated_time, last_updated_id, accountant_email, accountant_name, accountant_phone, accountant_sky, address, bank, bank_account_number, bank_branch, bankname, banknameeng, businesss_email, businesss_name, businesss_phone, businesss_sky, card_holder, contract_number, create_time, customercare_email, customercare_name, customercare_sky, customercare_phone, date_end, date_sign, ordercode, paymentcycle, provider_type, service, shortname, status, swiftcode, technical_email, technical_name, technical_phone, technical_sky, urlfile) VALUES (6, NULL, NULL, NULL, NULL, 'Mạnh', 'Tiến', '0987654132', NULL, 'Đống Đa -hà nội', 'NASC', '0454654768654745', 'Thái Hà Hà Nội', 'Ngân hàng VIB', NULL, 'Nam', 'Hoàng', '0987678564', NULL, 'Nguyễn Văn Chanh', NULL, '2017-05-16 10:51:43.939', 'Nam', 'Phong', NULL, NULL, '2017-05-26 00:00:00', '2017-05-11 00:00:00', '234654756856', '15', NULL, 'Ecom,Ewallet', NULL, NULL, 'VIB', 'Thuận', 'Kim', '0987652345', NULL, NULL);
INSERT INTO bank_profiles (id, created_time, creator_id, last_updated_time, last_updated_id, accountant_email, accountant_name, accountant_phone, accountant_sky, address, bank, bank_account_number, bank_branch, bankname, banknameeng, businesss_email, businesss_name, businesss_phone, businesss_sky, card_holder, contract_number, create_time, customercare_email, customercare_name, customercare_sky, customercare_phone, date_end, date_sign, ordercode, paymentcycle, provider_type, service, shortname, status, swiftcode, technical_email, technical_name, technical_phone, technical_sky, urlfile) VALUES (7, NULL, NULL, NULL, NULL, 'SADFSAFS', 'FFDSGFDGD', '0986234567', NULL, 'Hà Nội', 'ABBANK', '', '', 'Ngân hàng nông nghiệp', NULL, 'POIUYU', 'KIM', '0986234567', NULL, '', NULL, '2017-05-16 10:54:57.913', 'RETEWYYYRE', 'EWRTRYRTU', NULL, NULL, '2017-06-01 00:00:00', '2017-05-19 00:00:00', '3467545534634', '30', NULL, 'Ecom,Ewallet,BankTransfer', NULL, NULL, 'AGB', 'ỂWTEWT', 'EWREWTEW', '0986234567', NULL, NULL);
INSERT INTO bank_profiles (id, created_time, creator_id, last_updated_time, last_updated_id, accountant_email, accountant_name, accountant_phone, accountant_sky, address, bank, bank_account_number, bank_branch, bankname, banknameeng, businesss_email, businesss_name, businesss_phone, businesss_sky, card_holder, contract_number, create_time, customercare_email, customercare_name, customercare_sky, customercare_phone, date_end, date_sign, ordercode, paymentcycle, provider_type, service, shortname, status, swiftcode, technical_email, technical_name, technical_phone, technical_sky, urlfile) VALUES (8, NULL, NULL, NULL, NULL, '', '', '', NULL, 'HN', 'TPBV', '44356583001', 'Láng Hạ', 'Tien Phong', NULL, 'a@gmail.com', 'Anh', '0987563513', NULL, 'Anh', NULL, '2017-05-16 14:15:52.716', '', '', NULL, NULL, '2018-05-16 00:00:00', '2017-05-16 00:00:00', '243657778', '30', NULL, 'Ecom', NULL, NULL, 'TPBank', '', '', '', NULL, NULL);
INSERT INTO bank_profiles (id, created_time, creator_id, last_updated_time, last_updated_id, accountant_email, accountant_name, accountant_phone, accountant_sky, address, bank, bank_account_number, bank_branch, bankname, banknameeng, businesss_email, businesss_name, businesss_phone, businesss_sky, card_holder, contract_number, create_time, customercare_email, customercare_name, customercare_sky, customercare_phone, date_end, date_sign, ordercode, paymentcycle, provider_type, service, shortname, status, swiftcode, technical_email, technical_name, technical_phone, technical_sky, urlfile) VALUES (9, NULL, NULL, NULL, NULL, 'kim@gmail.com', 'Kim Jun Kim', '0987145623', NULL, 'đống đa hà nội', 'SEAV', '', '', 'Ngân hàng phương đông', NULL, 'Nam@gmail.com', 'Hoàng Nam', '0987145623', NULL, '', NULL, '2017-05-16 14:55:25.349', 'cong@gmail.com', 'Hoàng Công', NULL, NULL, '2017-05-25 00:00:00', '2017-05-11 00:00:00', '2354754', '30', NULL, 'Ecom,Ewallet', NULL, NULL, 'OPP', 'Tuyen@gmail.com', 'Kim Tuyền', '0987145623', NULL, NULL);
INSERT INTO bank_profiles (id, created_time, creator_id, last_updated_time, last_updated_id, accountant_email, accountant_name, accountant_phone, accountant_sky, address, bank, bank_account_number, bank_branch, bankname, banknameeng, businesss_email, businesss_name, businesss_phone, businesss_sky, card_holder, contract_number, create_time, customercare_email, customercare_name, customercare_sky, customercare_phone, date_end, date_sign, ordercode, paymentcycle, provider_type, service, shortname, status, swiftcode, technical_email, technical_name, technical_phone, technical_sky, urlfile) VALUES (10, NULL, NULL, NULL, NULL, '', '', '', NULL, 'HN', 'TPBV', '2343564', 'hn', 'Tep', NULL, 'mqai.com', 'Anh', '3435634643', NULL, 'DFS', NULL, '2017-05-16 15:35:02.717', '', '', NULL, NULL, '2017-05-31 00:00:00', '2017-05-16 00:00:00', '23SA', '30', NULL, 'Ewallet', NULL, NULL, 'TBP', '', '', '', NULL, NULL);
INSERT INTO bank_profiles (id, created_time, creator_id, last_updated_time, last_updated_id, accountant_email, accountant_name, accountant_phone, accountant_sky, address, bank, bank_account_number, bank_branch, bankname, banknameeng, businesss_email, businesss_name, businesss_phone, businesss_sky, card_holder, contract_number, create_time, customercare_email, customercare_name, customercare_sky, customercare_phone, date_end, date_sign, ordercode, paymentcycle, provider_type, service, shortname, status, swiftcode, technical_email, technical_name, technical_phone, technical_sky, urlfile) VALUES (11, NULL, NULL, NULL, NULL, '', '', '', NULL, 'HN', 'TPBV', '2343564', 'hn', 'Tep', NULL, 'mqai.com', 'Anh', '3435634643', NULL, 'DFS', NULL, '2017-05-16 15:36:18.397', '', '', NULL, NULL, '2017-05-31 00:00:00', '2017-05-16 00:00:00', '23SA', '30', NULL, 'Ewallet', NULL, NULL, 'Fsgds', '', '', '', NULL, NULL);
INSERT INTO bank_profiles (id, created_time, creator_id, last_updated_time, last_updated_id, accountant_email, accountant_name, accountant_phone, accountant_sky, address, bank, bank_account_number, bank_branch, bankname, banknameeng, businesss_email, businesss_name, businesss_phone, businesss_sky, card_holder, contract_number, create_time, customercare_email, customercare_name, customercare_sky, customercare_phone, date_end, date_sign, ordercode, paymentcycle, provider_type, service, shortname, status, swiftcode, technical_email, technical_name, technical_phone, technical_sky, urlfile) VALUES (12, NULL, NULL, NULL, NULL, '', '', '', NULL, 'HN', 'TPBV', '2343564', 'hn', 'Tep', NULL, 'mqai.com', 'Anh', '3435634643', NULL, 'DFS', NULL, '2017-05-16 15:38:35.383', '', '', NULL, NULL, '2017-05-31 00:00:00', '2017-05-16 00:00:00', '23SA', '30', NULL, 'Ewallet', NULL, NULL, 'Fdfas', '', '', '', NULL, NULL);
INSERT INTO bank_profiles (id, created_time, creator_id, last_updated_time, last_updated_id, accountant_email, accountant_name, accountant_phone, accountant_sky, address, bank, bank_account_number, bank_branch, bankname, banknameeng, businesss_email, businesss_name, businesss_phone, businesss_sky, card_holder, contract_number, create_time, customercare_email, customercare_name, customercare_sky, customercare_phone, date_end, date_sign, ordercode, paymentcycle, provider_type, service, shortname, status, swiftcode, technical_email, technical_name, technical_phone, technical_sky, urlfile) VALUES (13, NULL, NULL, NULL, NULL, '', '', '', NULL, 'HN', 'ASCB', '2342544', 'HN', 'ABC', NULL, 'mail', 'B', '2454657560', NULL, 'adsf', NULL, '2017-05-16 15:41:44.675', '', '', NULL, NULL, '2017-06-16 00:00:00', '2017-05-16 00:00:00', '2342A', '30', NULL, 'Ecom', NULL, NULL, 'Srfsf', '', '', '', NULL, NULL);
INSERT INTO bank_profiles (id, created_time, creator_id, last_updated_time, last_updated_id, accountant_email, accountant_name, accountant_phone, accountant_sky, address, bank, bank_account_number, bank_branch, bankname, banknameeng, businesss_email, businesss_name, businesss_phone, businesss_sky, card_holder, contract_number, create_time, customercare_email, customercare_name, customercare_sky, customercare_phone, date_end, date_sign, ordercode, paymentcycle, provider_type, service, shortname, status, swiftcode, technical_email, technical_name, technical_phone, technical_sky, urlfile) VALUES (14, NULL, NULL, NULL, NULL, '', '', '', NULL, 'HN', 'ASCB', '3423452352', 'HN', 'ACB', NULL, '', '', '', NULL, 'sfhg', NULL, '2017-05-16 15:43:03.144', '', '', NULL, '', '2017-06-30 00:00:00', '2017-05-16 00:00:00', '2342A', '30', NULL, NULL, NULL, NULL, 'fsgdf', 'a@gmail.com', 'fgdfg', '4546757453', NULL, NULL);


--
-- TOC entry 2225 (class 0 OID 25405)
-- Dependencies: 186
-- Data for Name: biz_api_account; Type: TABLE DATA; Schema: bankgw; Owner: -
--



--
-- TOC entry 2226 (class 0 OID 25413)
-- Dependencies: 187
-- Data for Name: biz_customer; Type: TABLE DATA; Schema: bankgw; Owner: -
--



--
-- TOC entry 2227 (class 0 OID 25421)
-- Dependencies: 188
-- Data for Name: biz_customer_attribute; Type: TABLE DATA; Schema: bankgw; Owner: -
--



--
-- TOC entry 2228 (class 0 OID 25429)
-- Dependencies: 189
-- Data for Name: cnf_provider_connection; Type: TABLE DATA; Schema: bankgw; Owner: -
--



--
-- TOC entry 2229 (class 0 OID 25437)
-- Dependencies: 190
-- Data for Name: cnf_provider_service; Type: TABLE DATA; Schema: bankgw; Owner: -
--



--
-- TOC entry 2230 (class 0 OID 25445)
-- Dependencies: 191
-- Data for Name: cnf_service; Type: TABLE DATA; Schema: bankgw; Owner: -
--



--
-- TOC entry 2231 (class 0 OID 25453)
-- Dependencies: 192
-- Data for Name: cnf_service_config; Type: TABLE DATA; Schema: bankgw; Owner: -
--



--
-- TOC entry 2232 (class 0 OID 25458)
-- Dependencies: 193
-- Data for Name: cnf_service_config_detail; Type: TABLE DATA; Schema: bankgw; Owner: -
--



--
-- TOC entry 2233 (class 0 OID 25463)
-- Dependencies: 194
-- Data for Name: cnf_telco; Type: TABLE DATA; Schema: bankgw; Owner: -
--



--
-- TOC entry 2244 (class 0 OID 0)
-- Dependencies: 197
-- Name: seq_id_entity; Type: SEQUENCE SET; Schema: bankgw; Owner: -
--

SELECT pg_catalog.setval('seq_id_entity', 14, true);


--
-- TOC entry 2234 (class 0 OID 25471)
-- Dependencies: 195
-- Data for Name: store_seq; Type: TABLE DATA; Schema: bankgw; Owner: -
--



--
-- TOC entry 2235 (class 0 OID 25476)
-- Dependencies: 196
-- Data for Name: transaction_history; Type: TABLE DATA; Schema: bankgw; Owner: -
--

INSERT INTO transaction_history (id, created_time, creator_id, last_updated_time, last_updated_id, address, agencysend, amount, bankcardagencysend, bankcode, banknameagencysend, cardname, cardnumber, customername, idno, merchant, ordercode, phonenumber, receiveagency, receivebankcard, receivebankname, receivecustomer, receivecustomeridno, receivepphone, receivewalletcode, servicetype, status, totalamount, traceid, transcustomer, transcustomeridno, transid, transcustomerphone, transtype, transactiondate, transactionfee, typecustomer, walletcode, walletcodesend) VALUES (7, NULL, NULL, '2017-05-15 17:33:30.05', NULL, 'Thái Hà Hà Nội', 'Nguyễn Văn Hoàng', 1200000.00, '097235621547', 'TPB', 'Lâm Quỳnh Chi', '038436475823', '3253465476909', 'Nguyễn Văn Công', '09343856346', 'TrueMoney', '097325636', '0982374735636', '930252367', '0884327536', 'Hoàng Văn Công', '93250834648', '0589347529876', '005936706573', '23654875688', 'ecom', 'success', 135090000.00, '090781', 'Nguyễn Văn Chương', '9253826', '0915', 'Hoàng Ngọc Nam', '235347', '2017-05-15 17:33:30.05', 230000.00, 'KH', '267548', '2354889');
INSERT INTO transaction_history (id, created_time, creator_id, last_updated_time, last_updated_id, address, agencysend, amount, bankcardagencysend, bankcode, banknameagencysend, cardname, cardnumber, customername, idno, merchant, ordercode, phonenumber, receiveagency, receivebankcard, receivebankname, receivecustomer, receivecustomeridno, receivepphone, receivewalletcode, servicetype, status, totalamount, traceid, transcustomer, transcustomeridno, transid, transcustomerphone, transtype, transactiondate, transactionfee, typecustomer, walletcode, walletcodesend) VALUES (8, NULL, NULL, '2017-05-15 17:33:30.05', NULL, 'Thái Hà Hà Nội', 'Nguyễn Văn Hoàng', 1200000.00, '097235621547', 'TPB', 'Lâm Quỳnh Chi', '038436475823', '3253465476909', 'Nguyễn Văn Công', '09343856346', 'TrueMoney', '097325636', '0982374735636', '930252367', '0884327536', 'Hoàng Văn Công', '93250834648', '0589347529876', '005936706573', '23654875688', 'wallet', 'success', 135090000.00, '090781', 'Nguyễn Văn Chương', '9253826', '0915', 'Hoàng Ngọc Nam', '235347', '2017-05-15 17:33:30.05', 230000.00, 'KH', '267548', '2354889');
INSERT INTO transaction_history (id, created_time, creator_id, last_updated_time, last_updated_id, address, agencysend, amount, bankcardagencysend, bankcode, banknameagencysend, cardname, cardnumber, customername, idno, merchant, ordercode, phonenumber, receiveagency, receivebankcard, receivebankname, receivecustomer, receivecustomeridno, receivepphone, receivewalletcode, servicetype, status, totalamount, traceid, transcustomer, transcustomeridno, transid, transcustomerphone, transtype, transactiondate, transactionfee, typecustomer, walletcode, walletcodesend) VALUES (9, NULL, NULL, '2017-05-15 17:33:30.05', NULL, 'Thái Hà Hà Nội', 'Nguyễn Văn Hoàng', 1200000.00, '097235621547', 'TPB', 'Lâm Quỳnh Chi', '038436475823', '3253465476909', 'Nguyễn Văn Công', '09343856346', 'TrueMoney', '097325636', '0982374735636', '930252367', '0884327536', 'Hoàng Văn Công', '93250834648', '0589347529876', '005936706573', '23654875688', 'tranfer', 'success', 135090000.00, '090781', 'Nguyễn Văn Chương', '9253826', '0915', 'Hoàng Ngọc Nam', '235347', '2017-05-15 17:33:30.05', 230000.00, 'KH', '267548', '2354889');
INSERT INTO transaction_history (id, created_time, creator_id, last_updated_time, last_updated_id, address, agencysend, amount, bankcardagencysend, bankcode, banknameagencysend, cardname, cardnumber, customername, idno, merchant, ordercode, phonenumber, receiveagency, receivebankcard, receivebankname, receivecustomer, receivecustomeridno, receivepphone, receivewalletcode, servicetype, status, totalamount, traceid, transcustomer, transcustomeridno, transid, transcustomerphone, transtype, transactiondate, transactionfee, typecustomer, walletcode, walletcodesend) VALUES (10, NULL, NULL, '2017-05-15 17:33:30.05', NULL, 'Thái Hà Hà Nội', 'Nguyễn Văn Hoàng', 1200000.00, '097235621547', 'TPB', 'Lâm Quỳnh Chi', '038436475823', '3253465476909', 'Nguyễn Văn Công', '09343856346', 'TrueMoney', '097325636', '0982374735636', '930252367', '0884327536', 'Hoàng Văn Công', '93250834648', '0589347529876', '005936706573', '23654875688', 'tranfer', 'success', 135090000.00, '090781', 'Nguyễn Văn Chương', '9253826', '0915', 'Hoàng Ngọc Nam', '235347', '2017-05-15 17:33:30.05', 230000.00, 'KH', '267548', '2354889');
INSERT INTO transaction_history (id, created_time, creator_id, last_updated_time, last_updated_id, address, agencysend, amount, bankcardagencysend, bankcode, banknameagencysend, cardname, cardnumber, customername, idno, merchant, ordercode, phonenumber, receiveagency, receivebankcard, receivebankname, receivecustomer, receivecustomeridno, receivepphone, receivewalletcode, servicetype, status, totalamount, traceid, transcustomer, transcustomeridno, transid, transcustomerphone, transtype, transactiondate, transactionfee, typecustomer, walletcode, walletcodesend) VALUES (11, NULL, NULL, '2017-05-15 17:33:30.05', NULL, 'Thái Hà Hà Nội', 'Nguyễn Văn Hoàng', 1200000.00, '097235621547', 'TPB', 'Lâm Quỳnh Chi', '038436475823', '3253465476909', 'Nguyễn Văn Công', '09343856346', 'TrueMoney', '097325636', '0982374735636', '930252367', '0884327536', 'Hoàng Văn Công', '93250834648', '0589347529876', '005936706573', '23654875688', 'tranfer', 'success', 135090000.00, '090781', 'Nguyễn Văn Chương', '9253826', '0915', 'Hoàng Ngọc Nam', '235347', '2017-05-15 17:33:30.05', 230000.00, 'KH', '267548', '2354889');
INSERT INTO transaction_history (id, created_time, creator_id, last_updated_time, last_updated_id, address, agencysend, amount, bankcardagencysend, bankcode, banknameagencysend, cardname, cardnumber, customername, idno, merchant, ordercode, phonenumber, receiveagency, receivebankcard, receivebankname, receivecustomer, receivecustomeridno, receivepphone, receivewalletcode, servicetype, status, totalamount, traceid, transcustomer, transcustomeridno, transid, transcustomerphone, transtype, transactiondate, transactionfee, typecustomer, walletcode, walletcodesend) VALUES (12, NULL, NULL, '2017-05-15 17:33:30.05', NULL, 'Thái Hà Hà Nội', 'Nguyễn Văn Hoàng', 1200000.00, '097235621547', 'TPB', 'Lâm Quỳnh Chi', '038436475823', '3253465476909', 'Nguyễn Văn Công', '09343856346', 'TrueMoney', '097325636', '0982374735636', '930252367', '0884327536', 'Hoàng Văn Công', '93250834648', '0589347529876', '005936706573', '23654875688', 'tranfer', 'success', 135090000.00, '090781', 'Nguyễn Văn Chương', '9253826', '0915', 'Hoàng Ngọc Nam', '235347', '2017-05-15 17:33:30.05', 230000.00, 'KH', '267548', '2354889');
INSERT INTO transaction_history (id, created_time, creator_id, last_updated_time, last_updated_id, address, agencysend, amount, bankcardagencysend, bankcode, banknameagencysend, cardname, cardnumber, customername, idno, merchant, ordercode, phonenumber, receiveagency, receivebankcard, receivebankname, receivecustomer, receivecustomeridno, receivepphone, receivewalletcode, servicetype, status, totalamount, traceid, transcustomer, transcustomeridno, transid, transcustomerphone, transtype, transactiondate, transactionfee, typecustomer, walletcode, walletcodesend) VALUES (13, NULL, NULL, '2017-05-15 17:33:30.05', NULL, 'Thái Hà Hà Nội', 'Nguyễn Văn Hoàng', 1200000.00, '097235621547', 'TPB', 'Lâm Quỳnh Chi', '038436475823', '3253465476909', 'Nguyễn Văn Công', '09343856346', 'TrueMoney', '097325636', '0982374735636', '930252367', '0884327536', 'Hoàng Văn Công', '93250834648', '0589347529876', '005936706573', '23654875688', 'tranfer', 'success', 135090000.00, '090781', 'Nguyễn Văn Chương', '9253826', '0915', 'Hoàng Ngọc Nam', '235347', '2017-05-15 17:33:30.05', 230000.00, 'KH', '267548', '2354889');
INSERT INTO transaction_history (id, created_time, creator_id, last_updated_time, last_updated_id, address, agencysend, amount, bankcardagencysend, bankcode, banknameagencysend, cardname, cardnumber, customername, idno, merchant, ordercode, phonenumber, receiveagency, receivebankcard, receivebankname, receivecustomer, receivecustomeridno, receivepphone, receivewalletcode, servicetype, status, totalamount, traceid, transcustomer, transcustomeridno, transid, transcustomerphone, transtype, transactiondate, transactionfee, typecustomer, walletcode, walletcodesend) VALUES (14, NULL, NULL, '2017-05-15 17:33:30.05', NULL, 'Thái Hà Hà Nội', 'Nguyễn Văn Hoàng', 1200000.00, '097235621547', 'TPB', 'Lâm Quỳnh Chi', '038436475823', '3253465476909', 'Nguyễn Văn Công', '09343856346', 'TrueMoney', '097325636', '0982374735636', '930252367', '0884327536', 'Hoàng Văn Công', '93250834648', '0589347529876', '005936706573', '23654875688', 'tranfer', 'success', 135090000.00, '090781', 'Nguyễn Văn Chương', '9253826', '0915', 'Hoàng Ngọc Nam', '235347', '2017-05-15 17:33:30.05', 230000.00, 'KH', '267548', '2354889');
INSERT INTO transaction_history (id, created_time, creator_id, last_updated_time, last_updated_id, address, agencysend, amount, bankcardagencysend, bankcode, banknameagencysend, cardname, cardnumber, customername, idno, merchant, ordercode, phonenumber, receiveagency, receivebankcard, receivebankname, receivecustomer, receivecustomeridno, receivepphone, receivewalletcode, servicetype, status, totalamount, traceid, transcustomer, transcustomeridno, transid, transcustomerphone, transtype, transactiondate, transactionfee, typecustomer, walletcode, walletcodesend) VALUES (1, NULL, NULL, '2017-05-16 17:33:30.05', NULL, 'Thái Hà Hà Nội', 'Nguyễn Văn Hoàng', 1200000.00, '097235621547', 'TPB', 'Lâm Quỳnh Chi', '038436475823', '3253465476909', 'Nguyễn Văn Công', '09343856346', 'TrueMoney', '097325636', '0982374735636', '930252367', '0884327536', 'Hoàng Văn Công', '93250834648', '0589347529876', '005936706573', '23654875688', 'tranfer', 'success', 135090000.00, '090781', 'Nguyễn Văn Chương', '9253826', '0915', 'Hoàng Ngọc Nam', '235347', '2017-05-16 17:33:30.05', 230000.00, 'KH', '267548', '2354889');
INSERT INTO transaction_history (id, created_time, creator_id, last_updated_time, last_updated_id, address, agencysend, amount, bankcardagencysend, bankcode, banknameagencysend, cardname, cardnumber, customername, idno, merchant, ordercode, phonenumber, receiveagency, receivebankcard, receivebankname, receivecustomer, receivecustomeridno, receivepphone, receivewalletcode, servicetype, status, totalamount, traceid, transcustomer, transcustomeridno, transid, transcustomerphone, transtype, transactiondate, transactionfee, typecustomer, walletcode, walletcodesend) VALUES (2, NULL, NULL, '2017-05-16 17:33:30.05', NULL, 'Thái Hà Hà Nội', 'Nguyễn Văn Hoàng', 1200000.00, '097235621547', 'TPB', 'Lâm Quỳnh Chi', '038436475823', '3253465476909', 'Nguyễn Văn Công', '09343856346', 'TrueMoney', '097325636', '0982374735636', '930252367', '0884327536', 'Hoàng Văn Công', '93250834648', '0589347529876', '005936706573', '23654875688', 'tranfer', 'success', 135090000.00, '090781', 'Nguyễn Văn Chương', '9253826', '0915', 'Hoàng Ngọc Nam', '235347', '2017-05-16 17:33:30.05', 230000.00, 'KH', '267548', '2354889');
INSERT INTO transaction_history (id, created_time, creator_id, last_updated_time, last_updated_id, address, agencysend, amount, bankcardagencysend, bankcode, banknameagencysend, cardname, cardnumber, customername, idno, merchant, ordercode, phonenumber, receiveagency, receivebankcard, receivebankname, receivecustomer, receivecustomeridno, receivepphone, receivewalletcode, servicetype, status, totalamount, traceid, transcustomer, transcustomeridno, transid, transcustomerphone, transtype, transactiondate, transactionfee, typecustomer, walletcode, walletcodesend) VALUES (3, NULL, NULL, '2017-05-16 17:33:30.05', NULL, 'Thái Hà Hà Nội', 'Nguyễn Văn Hoàng', 1200000.00, '097235621547', 'TPB', 'Lâm Quỳnh Chi', '038436475823', '3253465476909', 'Nguyễn Văn Công', '09343856346', 'TrueMoney', '097325636', '0982374735636', '930252367', '0884327536', 'Hoàng Văn Công', '93250834648', '0589347529876', '005936706573', '23654875688', 'tranfer', 'success', 135090000.00, '090781', 'Nguyễn Văn Chương', '9253826', '0915', 'Hoàng Ngọc Nam', '235347', '2017-05-16 17:33:30.05', 230000.00, 'KH', '267548', '2354889');
INSERT INTO transaction_history (id, created_time, creator_id, last_updated_time, last_updated_id, address, agencysend, amount, bankcardagencysend, bankcode, banknameagencysend, cardname, cardnumber, customername, idno, merchant, ordercode, phonenumber, receiveagency, receivebankcard, receivebankname, receivecustomer, receivecustomeridno, receivepphone, receivewalletcode, servicetype, status, totalamount, traceid, transcustomer, transcustomeridno, transid, transcustomerphone, transtype, transactiondate, transactionfee, typecustomer, walletcode, walletcodesend) VALUES (4, NULL, NULL, '2017-05-16 17:33:30.05', NULL, 'Thái Hà Hà Nội', 'Nguyễn Văn Hoàng', 1200000.00, '097235621547', 'TPB', 'Lâm Quỳnh Chi', '038436475823', '3253465476909', 'Nguyễn Văn Công', '09343856346', 'TrueMoney', '097325636', '0982374735636', '930252367', '0884327536', 'Hoàng Văn Công', '93250834648', '0589347529876', '005936706573', '23654875688', 'tranfer', 'success', 135090000.00, '090781', 'Nguyễn Văn Chương', '9253826', '0915', 'Hoàng Ngọc Nam', '235347', '2017-05-16 17:33:30.05', 230000.00, 'KH', '267548', '2354889');
INSERT INTO transaction_history (id, created_time, creator_id, last_updated_time, last_updated_id, address, agencysend, amount, bankcardagencysend, bankcode, banknameagencysend, cardname, cardnumber, customername, idno, merchant, ordercode, phonenumber, receiveagency, receivebankcard, receivebankname, receivecustomer, receivecustomeridno, receivepphone, receivewalletcode, servicetype, status, totalamount, traceid, transcustomer, transcustomeridno, transid, transcustomerphone, transtype, transactiondate, transactionfee, typecustomer, walletcode, walletcodesend) VALUES (5, NULL, NULL, '2017-05-16 17:33:30.05', NULL, 'Thái Hà Hà Nội', 'Nguyễn Văn Hoàng', 1200000.00, '097235621547', 'TPB', 'Lâm Quỳnh Chi', '038436475823', '3253465476909', 'Nguyễn Văn Công', '09343856346', 'TrueMoney', '097325636', '0982374735636', '930252367', '0884327536', 'Hoàng Văn Công', '93250834648', '0589347529876', '005936706573', '23654875688', 'tranfer', 'success', 135090000.00, '090781', 'Nguyễn Văn Chương', '9253826', '0915', 'Hoàng Ngọc Nam', '235347', '2017-05-16 17:33:30.05', 230000.00, 'KH', '267548', '2354889');
INSERT INTO transaction_history (id, created_time, creator_id, last_updated_time, last_updated_id, address, agencysend, amount, bankcardagencysend, bankcode, banknameagencysend, cardname, cardnumber, customername, idno, merchant, ordercode, phonenumber, receiveagency, receivebankcard, receivebankname, receivecustomer, receivecustomeridno, receivepphone, receivewalletcode, servicetype, status, totalamount, traceid, transcustomer, transcustomeridno, transid, transcustomerphone, transtype, transactiondate, transactionfee, typecustomer, walletcode, walletcodesend) VALUES (6, NULL, NULL, '2017-05-16 17:33:30.05', NULL, 'Thái Hà Hà Nội', 'Nguyễn Văn Hoàng', 1200000.00, '097235621547', 'TPB', 'Lâm Quỳnh Chi', '038436475823', '3253465476909', 'Nguyễn Văn Công', '09343856346', 'TrueMoney', '097325636', '0982374735636', '930252367', '0884327536', 'Hoàng Văn Công', '93250834648', '0589347529876', '005936706573', '23654875688', 'tranfer', 'success', 135090000.00, '090781', 'Nguyễn Văn Chương', '9253826', '0915', 'Hoàng Ngọc Nam', '235347', '2017-05-16 17:33:30.05', 230000.00, 'KH', '267548', '2354889');


--
-- TOC entry 2055 (class 2606 OID 25404)
-- Name: bank_profiles bank_profiles_pkey; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY bank_profiles
    ADD CONSTRAINT bank_profiles_pkey PRIMARY KEY (id);


--
-- TOC entry 2057 (class 2606 OID 25412)
-- Name: biz_api_account biz_api_account_pkey; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY biz_api_account
    ADD CONSTRAINT biz_api_account_pkey PRIMARY KEY (id);


--
-- TOC entry 2067 (class 2606 OID 25428)
-- Name: biz_customer_attribute biz_customer_attribute_pkey; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY biz_customer_attribute
    ADD CONSTRAINT biz_customer_attribute_pkey PRIMARY KEY (id);


--
-- TOC entry 2061 (class 2606 OID 25420)
-- Name: biz_customer biz_customer_pkey; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY biz_customer
    ADD CONSTRAINT biz_customer_pkey PRIMARY KEY (id);


--
-- TOC entry 2071 (class 2606 OID 25436)
-- Name: cnf_provider_connection cnf_provider_connection_pkey; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY cnf_provider_connection
    ADD CONSTRAINT cnf_provider_connection_pkey PRIMARY KEY (id);


--
-- TOC entry 2075 (class 2606 OID 25444)
-- Name: cnf_provider_service cnf_provider_service_pkey; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY cnf_provider_service
    ADD CONSTRAINT cnf_provider_service_pkey PRIMARY KEY (id);


--
-- TOC entry 2089 (class 2606 OID 25462)
-- Name: cnf_service_config_detail cnf_service_config_detail_pkey; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY cnf_service_config_detail
    ADD CONSTRAINT cnf_service_config_detail_pkey PRIMARY KEY (id);


--
-- TOC entry 2085 (class 2606 OID 25457)
-- Name: cnf_service_config cnf_service_config_pkey; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY cnf_service_config
    ADD CONSTRAINT cnf_service_config_pkey PRIMARY KEY (id);


--
-- TOC entry 2079 (class 2606 OID 25452)
-- Name: cnf_service cnf_service_pkey; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY cnf_service
    ADD CONSTRAINT cnf_service_pkey PRIMARY KEY (id);


--
-- TOC entry 2093 (class 2606 OID 25470)
-- Name: cnf_telco cnf_telco_pkey; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY cnf_telco
    ADD CONSTRAINT cnf_telco_pkey PRIMARY KEY (id);


--
-- TOC entry 2097 (class 2606 OID 25475)
-- Name: store_seq store_seq_pkey; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY store_seq
    ADD CONSTRAINT store_seq_pkey PRIMARY KEY (id_seq);


--
-- TOC entry 2101 (class 2606 OID 25483)
-- Name: transaction_history transaction_history_pkey; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY transaction_history
    ADD CONSTRAINT transaction_history_pkey PRIMARY KEY (id);


--
-- TOC entry 2063 (class 2606 OID 25487)
-- Name: biz_customer uk_5oqv5mhxnttm4rjv0o3non5io; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY biz_customer
    ADD CONSTRAINT uk_5oqv5mhxnttm4rjv0o3non5io UNIQUE (cif);


--
-- TOC entry 2059 (class 2606 OID 25485)
-- Name: biz_api_account uk_7ombler5d36gg81n93x5si0ee; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY biz_api_account
    ADD CONSTRAINT uk_7ombler5d36gg81n93x5si0ee UNIQUE (customer_id, code, username);


--
-- TOC entry 2099 (class 2606 OID 25507)
-- Name: store_seq uk_7xvbemqsogovku3xkph5o502h; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY store_seq
    ADD CONSTRAINT uk_7xvbemqsogovku3xkph5o502h UNIQUE (seq_name);


--
-- TOC entry 2073 (class 2606 OID 25493)
-- Name: cnf_provider_connection uk_8ew8yx0jhbof4wiulkxkoqtwu; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY cnf_provider_connection
    ADD CONSTRAINT uk_8ew8yx0jhbof4wiulkxkoqtwu UNIQUE (provider_code);


--
-- TOC entry 2077 (class 2606 OID 25495)
-- Name: cnf_provider_service uk_ddtfompbbxiq9cn0n9ysfmtka; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY cnf_provider_service
    ADD CONSTRAINT uk_ddtfompbbxiq9cn0n9ysfmtka UNIQUE (provider_code, service_type, telco_type, telco_service_type);


--
-- TOC entry 2095 (class 2606 OID 25505)
-- Name: cnf_telco uk_fci53fidms4dxyfiv117mtadf; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY cnf_telco
    ADD CONSTRAINT uk_fci53fidms4dxyfiv117mtadf UNIQUE (telco_type);


--
-- TOC entry 2065 (class 2606 OID 25489)
-- Name: biz_customer uk_fevdq463hyhxciwyn74xaj46n; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY biz_customer
    ADD CONSTRAINT uk_fevdq463hyhxciwyn74xaj46n UNIQUE (username);


--
-- TOC entry 2087 (class 2606 OID 25501)
-- Name: cnf_service_config uk_fv7ygudrqkq2u1eb3thnvk37b; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY cnf_service_config
    ADD CONSTRAINT uk_fv7ygudrqkq2u1eb3thnvk37b UNIQUE (service_id, customer_type);


--
-- TOC entry 2081 (class 2606 OID 25499)
-- Name: cnf_service uk_j65rm9v7oe101egvufhdqr5vm; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY cnf_service
    ADD CONSTRAINT uk_j65rm9v7oe101egvufhdqr5vm UNIQUE (service_code);


--
-- TOC entry 2091 (class 2606 OID 25503)
-- Name: cnf_service_config_detail uk_oddmtq1f5fcyo9senvl07ddor; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY cnf_service_config_detail
    ADD CONSTRAINT uk_oddmtq1f5fcyo9senvl07ddor UNIQUE (service_id, customer_id);


--
-- TOC entry 2083 (class 2606 OID 25497)
-- Name: cnf_service uk_ok95stn969wuolg9jr7jhn0eo; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY cnf_service
    ADD CONSTRAINT uk_ok95stn969wuolg9jr7jhn0eo UNIQUE (service_type, telco_type, telco_service_type);


--
-- TOC entry 2069 (class 2606 OID 25491)
-- Name: biz_customer_attribute uni_cif_key_service_type_attr_idx; Type: CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY biz_customer_attribute
    ADD CONSTRAINT uni_cif_key_service_type_attr_idx UNIQUE (cif, key_attribute, service_type);


--
-- TOC entry 2105 (class 2606 OID 25523)
-- Name: cnf_service_config_detail fk_1v8p7t6ycy4230pthsrwx71mt; Type: FK CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY cnf_service_config_detail
    ADD CONSTRAINT fk_1v8p7t6ycy4230pthsrwx71mt FOREIGN KEY (customer_id) REFERENCES biz_customer(id);


--
-- TOC entry 2102 (class 2606 OID 25508)
-- Name: biz_api_account fk_476xykuchbi6fmd7nr6jjqqcg; Type: FK CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY biz_api_account
    ADD CONSTRAINT fk_476xykuchbi6fmd7nr6jjqqcg FOREIGN KEY (customer_id) REFERENCES biz_customer(id);


--
-- TOC entry 2106 (class 2606 OID 25528)
-- Name: cnf_service_config_detail fk_5ew492u1py7bnbm9b3sa4ltfy; Type: FK CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY cnf_service_config_detail
    ADD CONSTRAINT fk_5ew492u1py7bnbm9b3sa4ltfy FOREIGN KEY (service_id) REFERENCES cnf_service(id);


--
-- TOC entry 2104 (class 2606 OID 25518)
-- Name: cnf_service_config fk_hoewdr6o86gyv62haedcoqif; Type: FK CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY cnf_service_config
    ADD CONSTRAINT fk_hoewdr6o86gyv62haedcoqif FOREIGN KEY (service_id) REFERENCES cnf_service(id);


--
-- TOC entry 2103 (class 2606 OID 25513)
-- Name: cnf_service fk_n8xag46g7bs8rvtrqj91ij80l; Type: FK CONSTRAINT; Schema: bankgw; Owner: -
--

ALTER TABLE ONLY cnf_service
    ADD CONSTRAINT fk_n8xag46g7bs8rvtrqj91ij80l FOREIGN KEY (parent_id) REFERENCES cnf_service(id);


-- Completed on 2017-05-16 17:52:13

--
-- PostgreSQL database dump complete
--

