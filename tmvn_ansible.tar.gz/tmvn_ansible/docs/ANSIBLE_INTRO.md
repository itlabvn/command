---

# Introduction to Ansible
## haild@1pay.vn

---

# Summary

- Install
- Inventory
- ansible.cfg
- Modules
- Facts and variables
- Playbooks
- Conventions

---

# Core ideas

- Different environment should have the same structure --> playbook
- They differ in identity and configuration --> inventory, facts and variables
- Common administrative tasks should be encapsulated --> modules

---

# Install
## On standard Ubuntu setup

```bash
$ sudo apt-get install python-pip
$ pip install --user ansible-playbook
$ export PATH=$HOME/.local/bin:$PATH
```

---

# Inventory
## List of hosts and their groups

```ini
[proxy]
10.10.1.11
10.10.1.12

[app]
10.10.2.11
10.10.2.12

[edc]
10.10.1.11
10.10.2.11
```

---

# Sub-groups
## Group could include other groups

```ini
[db_pri]
10.10.3.11

[db_sec]
10.10.3.12

[db:children]
db_pri
db_sec
```

---

# ansible.cfg: global configuration for ansible

* Load order (first found used)
    * ANSIBLE\_CONFIG (an environment variable)
    * ansible.cfg (in the current directory)
    * .ansible.cfg (in the home directory)
    * /etc/ansible/ansible.cfg
* Full options: https://raw.githubusercontent.com/ansible/ansible/devel/examples/ansible.cfg

---

# Configuration overloading

* ansible.cfg
    ```ini
    [defaults]
    forks = 50
    ```
* Environment variable
    ```bash
    $ export ANSIBLE_FORKS=5
    ```
* Final value: 5

---

# Modules
## Encapsulation of common tasks

* `apt`: `name=nginx=1.10 state=present`
* `apt`: `name=apache state=absent`
* `apt`: `name=haproxy state=latest cache_valid_time=86400 update_cache=yes install_recommends=no`

---

# Ad-hoc module execution
## Using `ansible` command

```bash
$ ansible all -i hosts -m command -a 'date'
$ ansible proxy:app -i hosts -m command --become -a 'apt-get install htop'
```

---

# Facts
## things that are discovered about remote nodes

```bash
$ ansible all -i hosts -m setup
```

```json
{
    "ansible_distribution": "Ubuntu",
    "ansible_distribution_release": "xenial",
    "ansible_dns": {
        "nameservers": [ "8.8.8.8", "8.8.4.4" ]
    }
}
```

---

# Variables
## names of values declared in inventory, host vars and group vars

- Load order
    - role defaults
    - inventory INI or script group vars
    - inventory group\_vars/all
    - playbook group\_vars/all
    - __inventory group\_vars/\*__
    - playbook group\_vars/\*
    - __inventory INI or script host vars__
    - inventory host\_vars/\*
    - playbook host\_vars/\*
    - __host facts__
    - __play vars__
    - play vars\_prompt
    - play vars\_files
    - role vars (defined in role/vars/main.yml)
    - block vars (only for tasks in block)
    - task vars (only for the task)
    - role (and include\_role) params
    - include params
    - include\_vars
    - __set\_facts / registered vars__
    - extra vars (always win precedence)

---

# Using facts and vars

```bash
$ ansible all -i hosts -m debug -a 'msg="Hello, I am {{ ansible_user }}@{{ ansible_hostname }}, at tier {{ nr_tier }}"'
```

---

# Tasks
## an action (a module and its arguments) with a name and optionally some other keywords

```yaml
- name: Copy certificates
  tags: config
  copy:
    src: "{{ item }}"
    dest: "/etc/nginx/ssl/{{ metabase.domain }}/"
    owner: root
    mode: 400
  with_fileglob:
    - "files/ssl/{{ metabase.domain }}/*"
  notify:
    - test nginx
    - reload nginx
```

---

# Handlers
## special tasks that do not run unless notified when a task reports an underlying change on a remote system

```yaml
handlers:
  - name: test nginx
    command: nginx -t
  - name: reload nginx
    service: name=nginx state=reloaded
```

---

# Plays
## mapping between a set of hosts and the tasks to be run on those hosts

```yaml
- hosts: proxy
  become: yes
  handlers:
    - name: reload nginx
      service: name=nginx state=reloaded
  tasks:
    - name: Copy certificates
      copy:
        src: "{{ item }}"
        dest: "/etc/nginx/ssl/{{ metabase.domain }}/"
      with_fileglob:
        - "files/ssl/{{ metabase.domain }}/*"
      notify: reload nginx
    - name: Setup nginx
      template: src=templates/nginx/ams.conf.j2 dest=/etc/nginx/conf.d/{{ metabase.domain }}.conf
      notify: reload nginx
```
---

# Playbook
## a list of plays

```yaml
- hosts: db_pri
  tasks:
    - postgresql_user:
        name: "{{ tmv.db.user }}"
        password: "{{ tmv.db.password }}"
        encrypted: true
    - postgresql_db:
        name: "{{ tmv.db.name }}"
        owner: "{{ tmv.db.user }}"

- hosts: proxy
  tasks:
    - name: Setup nginx
      template: src=templates/nginx/tmv.conf.j2 dest=/etc/nginx/conf.d/{{ tmv.domain }}.conf

- include: tmv-deploy.yml
```
---

# Common modules

- `apt`, `apt_key`, `apt_repository`
- `copy`, `template`, `lineinfile`
- `docker_container`
- `wait_for`, `service`
---

# Conventions

- Use tags to separate install, config and deploy
- Each environment should has its own inventory, with a group of the same name
- `copy`'s `src` should be in files
- `template`'s `src` should be in templates
- Prefer `copy` and `template` to `lineinfile`
- If application could use a configuration directory, use it rather than modifying main configuration file
