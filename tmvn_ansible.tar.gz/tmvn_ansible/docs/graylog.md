B1: Import graylog content_packs:
    - truy cập vào graylog với quyền admin -> system -> Content Packs -> Import content pack
    - chọn và upload tất cả content_pack trong "file/graylog_content_packs"
B2: Kiểm tra đảm bảo firewall cho phép graylog server nhận log trên port 9010(UDP) và 9011(TCP)
B3: Format nginx logs bằng cách chạy nginx-install.yml playbook
B4: Forward logs từ các server về graylog server
    - chạy playbook graylog_collection.yml
