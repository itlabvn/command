## Upgrade notes

### Version 1.2.2

- Deploy version 2.2.7 of TrueService

- Import data
```
psql -1 -h $PGHOST -U dlotto truemoney_edc_gateway < docs/edcgw-1.2.2.sql
```

- Deploy
```
ansible-playbook -Dvv -i $ENV edcgw.yml
```
