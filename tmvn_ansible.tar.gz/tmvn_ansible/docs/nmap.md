B1: Update file files/nmap/nmap-hosts va files/nmap/nmap-services khi co sua doi hay them moi host hoac service
B2: run playbook nmap-tcp.yml voi tags=all-ports de Scan tat ca TCP port, voi tags=tmvn-ports de chi Scan tmvn-service ports
B3: Kiem tra ket qua Scan trong file /tmp/nmap.log hoac /tmp/nmap_all.log

