# change api_rails_base_url_ptu_check value
true_money=# update sys_system_preference set value = 'http://<easyapi_host>:<easyapi_port>/ptu/pin/check' where variable = 'api_rails_base_url_ptu_check';

# change api_rails_base_url_ptu_print value
true_money=# update sys_system_preference set value = 'http://<easyapi_host>:<easyapi_port>/ptu/pin/print' where variable = 'api_rails_base_url_ptu_print';
