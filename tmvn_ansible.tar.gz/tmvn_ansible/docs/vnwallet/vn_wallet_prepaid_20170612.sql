-- --------------------------------------------------------
-- Máy chủ:                      127.0.0.1
-- Server version:               5.7.18-log - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Phiên bản:           9.4.0.5170
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for vn_wallet_prepaid
DROP DATABASE IF EXISTS `vn_wallet_prepaid`;
CREATE DATABASE IF NOT EXISTS `vn_wallet_prepaid` /*!40100 DEFAULT CHARACTER SET ascii */;
USE `vn_wallet_prepaid`;

-- Dumping structure for table vn_wallet_prepaid.audit_log
DROP TABLE IF EXISTS `audit_log`;
CREATE TABLE IF NOT EXISTS `audit_log` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CREATED_TIME` datetime DEFAULT NULL,
  `CREATOR_ID` bigint(20) DEFAULT NULL,
  `LAST_UPDATED_TIME` datetime DEFAULT NULL,
  `LAST_UPDATED_ID` bigint(20) DEFAULT NULL,
  `BODY` varchar(10000) DEFAULT NULL,
  `LOG_TYPE` varchar(255) DEFAULT NULL,
  `METHOD` varchar(255) DEFAULT NULL,
  `TRANSACTION_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_gwa6n51moqxvtr25lr1ifk520` (`TRANSACTION_ID`),
  CONSTRAINT `FK_gwa6n51moqxvtr25lr1ifk520` FOREIGN KEY (`TRANSACTION_ID`) REFERENCES `transaction` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=ascii;

-- Dumping data for table vn_wallet_prepaid.audit_log: ~7 rows (approximately)
/*!40000 ALTER TABLE `audit_log` DISABLE KEYS */;
INSERT INTO `audit_log` (`ID`, `CREATED_TIME`, `CREATOR_ID`, `LAST_UPDATED_TIME`, `LAST_UPDATED_ID`, `BODY`, `LOG_TYPE`, `METHOD`, `TRANSACTION_ID`) VALUES
	(1, '2017-06-12 11:50:39', 0, NULL, NULL, '{"reference":"","firstName":"","lastName":"","idOrPassport":"","cellphoneNumber":"","expiryDate":"","transactionID":"","transactionDate":"","cardIdentifier":"","reasonID":0,"note":"","cardType":{"id":0,"name":"VIRTUAL"}}', 'REQUEST', 'GET_CARD', 1),
	(2, '2017-06-12 11:50:53', 0, NULL, NULL, '{"terminalID":"0094276952","checksum":"A3AE9591A1ECC64B1185A37DF9CAEE5550B672D7","profileNumber":"3133170484","reference":"","transactionDate":"20170612T04:50:39","transactionID":"","VirtualCardList":[{"cvv":"140","cardNumber":"5192600021074285","expiryDate":"20201212T00:00:00","trackingNumber":"877873300000242"},{"cvv":"174","cardNumber":"5192601131253983","expiryDate":"20190605T00:00:00","trackingNumber":"433773300000283"},{"cvv":"254","cardNumber":"5192602307416768","expiryDate":"20201212T00:00:00","trackingNumber":"609173300000279"},{"cvv":"579","cardNumber":"5192602673945135","expiryDate":"20180210T00:00:00","trackingNumber":"273773300000259"},{"cvv":"359","cardNumber":"5192604734347665","expiryDate":"20180210T00:00:00","trackingNumber":"846373300000278"},{"cvv":"512","cardNumber":"5192606573529782","expiryDate":"20180507T00:00:00","trackingNumber":"614273300000003"},{"cvv":"811","cardNumber":"5192606997526737","expiryDate":"20180210T00:00:00","trackingNumber":"854673300000276"},{"cvv":"328","cardNumber":"5192608212742552","expiryDate":"20171212T00:00:00","trackingNumber":"107873300000008"},{"cvv":"463","cardNumber":"5192609668978716","expiryDate":"20201212T00:00:00","trackingNumber":"287073300000243"},{"cvv":"346","cardNumber":"5192609890995561","expiryDate":"20180210T00:00:00","trackingNumber":"474873300000277"}],"code":"1","msg":"ok"}', 'REQUEST', 'GET_CARD', 1),
	(3, '2017-06-12 11:53:53', 0, NULL, NULL, '{"reference":"","firstName":"","lastName":"","idOrPassport":"","cellphoneNumber":"","expiryDate":"","transactionID":"","transactionDate":"","cardIdentifier":"","reasonID":0,"note":"","cardType":{"id":0,"name":"VIRTUAL"}}', 'REQUEST', 'GET_CARD', 2),
	(4, '2017-06-12 13:36:56', 0, NULL, NULL, '{"reference":"","firstName":"","lastName":"","idOrPassport":"","cellphoneNumber":"","expiryDate":"","transactionID":"","transactionDate":"","cardIdentifier":"","reasonID":0,"note":"","cardType":{"id":0,"name":"VIRTUAL"}}', 'REQUEST', 'GET_CARD', 3),
	(5, '2017-06-12 13:37:16', 0, NULL, NULL, '{"terminalID":"0094276952","checksum":"9D076E108C7CFC309E878782BE902C132959A2FA","profileNumber":"3133170484","reference":"","transactionDate":"20170612T06:36:56","transactionID":"","VirtualCardList":[{"cvv":"140","cardNumber":"5192600021074285","expiryDate":"20201212T00:00:00","trackingNumber":"877873300000242"},{"cvv":"174","cardNumber":"5192601131253983","expiryDate":"20190605T00:00:00","trackingNumber":"433773300000283"},{"cvv":"254","cardNumber":"5192602307416768","expiryDate":"20201212T00:00:00","trackingNumber":"609173300000279"},{"cvv":"579","cardNumber":"5192602673945135","expiryDate":"20180210T00:00:00","trackingNumber":"273773300000259"},{"cvv":"359","cardNumber":"5192604734347665","expiryDate":"20180210T00:00:00","trackingNumber":"846373300000278"},{"cvv":"512","cardNumber":"5192606573529782","expiryDate":"20180507T00:00:00","trackingNumber":"614273300000003"},{"cvv":"811","cardNumber":"5192606997526737","expiryDate":"20180210T00:00:00","trackingNumber":"854673300000276"},{"cvv":"328","cardNumber":"5192608212742552","expiryDate":"20171212T00:00:00","trackingNumber":"107873300000008"},{"cvv":"463","cardNumber":"5192609668978716","expiryDate":"20201212T00:00:00","trackingNumber":"287073300000243"},{"cvv":"346","cardNumber":"5192609890995561","expiryDate":"20180210T00:00:00","trackingNumber":"474873300000277"}],"code":"1","msg":"ok"}', 'REQUEST', 'GET_CARD', 3),
	(6, '2017-06-12 14:02:50', 0, NULL, NULL, '{"reference":"","firstName":"","lastName":"","idOrPassport":"","cellphoneNumber":"","expiryDate":"","transactionID":"","transactionDate":"","cardIdentifier":"","reasonID":0,"note":"","cardType":{"id":0,"name":"VIRTUAL"}}', 'REQUEST', 'GET_CARD', 4),
	(7, '2017-06-12 14:04:57', 0, NULL, NULL, '{"terminalID":"0094276952","checksum":"FC191172097206EA1CB49F507B555BD603E77643","profileNumber":"3133170484","reference":"","transactionDate":"20170612T07:02:49","transactionID":"","VirtualCardList":[{"cvv":"140","cardNumber":"5192600021074285","expiryDate":"20201212T00:00:00","trackingNumber":"877873300000242"},{"cvv":"174","cardNumber":"5192601131253983","expiryDate":"20190605T00:00:00","trackingNumber":"433773300000283"},{"cvv":"254","cardNumber":"5192602307416768","expiryDate":"20201212T00:00:00","trackingNumber":"609173300000279"},{"cvv":"579","cardNumber":"5192602673945135","expiryDate":"20180210T00:00:00","trackingNumber":"273773300000259"},{"cvv":"359","cardNumber":"5192604734347665","expiryDate":"20180210T00:00:00","trackingNumber":"846373300000278"},{"cvv":"512","cardNumber":"5192606573529782","expiryDate":"20180507T00:00:00","trackingNumber":"614273300000003"},{"cvv":"811","cardNumber":"5192606997526737","expiryDate":"20180210T00:00:00","trackingNumber":"854673300000276"},{"cvv":"328","cardNumber":"5192608212742552","expiryDate":"20171212T00:00:00","trackingNumber":"107873300000008"},{"cvv":"463","cardNumber":"5192609668978716","expiryDate":"20201212T00:00:00","trackingNumber":"287073300000243"},{"cvv":"346","cardNumber":"5192609890995561","expiryDate":"20180210T00:00:00","trackingNumber":"474873300000277"}],"code":"1","msg":"ok"}', 'REQUEST', 'GET_CARD', 4);
/*!40000 ALTER TABLE `audit_log` ENABLE KEYS */;

-- Dumping structure for table vn_wallet_prepaid.event
DROP TABLE IF EXISTS `event`;
CREATE TABLE IF NOT EXISTS `event` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CREATED_TIME` datetime DEFAULT NULL,
  `CREATOR_ID` bigint(20) DEFAULT NULL,
  `LAST_UPDATED_TIME` datetime DEFAULT NULL,
  `LAST_UPDATED_ID` bigint(20) DEFAULT NULL,
  `EVENT_TYPE` varchar(255) DEFAULT NULL,
  `TRANSACTION_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_spocicw2wbj0b7s7ni04aqcci` (`TRANSACTION_ID`),
  CONSTRAINT `FK_spocicw2wbj0b7s7ni04aqcci` FOREIGN KEY (`TRANSACTION_ID`) REFERENCES `transaction` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=ascii;

-- Dumping data for table vn_wallet_prepaid.event: ~4 rows (approximately)
/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` (`ID`, `CREATED_TIME`, `CREATOR_ID`, `LAST_UPDATED_TIME`, `LAST_UPDATED_ID`, `EVENT_TYPE`, `TRANSACTION_ID`) VALUES
	(1, '2017-06-12 11:50:39', 0, NULL, NULL, 'GET_CARD', 1),
	(2, '2017-06-12 11:53:53', 0, NULL, NULL, 'GET_CARD', 2),
	(3, '2017-06-12 13:36:57', 0, NULL, NULL, 'GET_CARD', 3),
	(4, '2017-06-12 14:02:50', 0, NULL, NULL, 'GET_CARD', 4);
/*!40000 ALTER TABLE `event` ENABLE KEYS */;

-- Dumping structure for table vn_wallet_prepaid.status_code
DROP TABLE IF EXISTS `status_code`;
CREATE TABLE IF NOT EXISTS `status_code` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CREATED_TIME` datetime DEFAULT NULL,
  `CREATOR_ID` bigint(20) DEFAULT NULL,
  `LAST_UPDATED_TIME` datetime DEFAULT NULL,
  `LAST_UPDATED_ID` bigint(20) DEFAULT NULL,
  `SPI_CODE` varchar(255) DEFAULT NULL,
  `SPI_MSG` varchar(255) DEFAULT NULL,
  `TUTUKA_CODE` varchar(255) DEFAULT NULL,
  `TUTUKA_MSG` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_jqyyp2625iup4y32u4yy4svt8` (`TUTUKA_CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=ascii;

-- Dumping data for table vn_wallet_prepaid.status_code: ~45 rows (approximately)
/*!40000 ALTER TABLE `status_code` DISABLE KEYS */;
INSERT INTO `status_code` (`ID`, `CREATED_TIME`, `CREATOR_ID`, `LAST_UPDATED_TIME`, `LAST_UPDATED_ID`, `SPI_CODE`, `SPI_MSG`, `TUTUKA_CODE`, `TUTUKA_MSG`) VALUES
	(1, NULL, NULL, NULL, NULL, '1', 'ok', '1', 'ok'),
	(2, NULL, NULL, NULL, NULL, '-2', 'Invalid Card Number', '-2', 'Invalid Card Number'),
	(3, NULL, NULL, NULL, NULL, '-5', 'Stop aleady requested', '-5', 'Stop aleady requested'),
	(4, NULL, NULL, NULL, NULL, '-6', 'Card expired', '-6', 'Card expired'),
	(5, NULL, NULL, NULL, NULL, '-8', 'Authentication failed', '-8', 'Authentication failed'),
	(6, NULL, NULL, NULL, NULL, '-9', 'A general error occurred', '-9', 'A general error occurred'),
	(7, NULL, NULL, NULL, NULL, '-10', 'Card already activated', '-10', 'Card already activated'),
	(8, NULL, NULL, NULL, NULL, '-11', 'Card was not stopped', '-11', 'Card was not stopped'),
	(9, NULL, NULL, NULL, NULL, '-13', 'Stolen card', '-13', 'Stolen card'),
	(10, NULL, NULL, NULL, NULL, '-16', 'Profile not linked to this terminal', '-16', 'Profile not linked to this terminal'),
	(11, NULL, NULL, NULL, NULL, '-17', 'Card not linked to this profile', '-17', 'Card not linked to this profile'),
	(12, NULL, NULL, NULL, NULL, '-19', 'Card already allocated', '-19', 'Card already allocated'),
	(13, NULL, NULL, NULL, NULL, '-22', 'Card already linked', '-22', 'Card already linked'),
	(14, NULL, NULL, NULL, NULL, '-23', 'Invalid PIN length', '-23', 'Invalid PIN length'),
	(15, NULL, NULL, NULL, NULL, '-24', 'Invalid Card Data', '-24', 'Invalid Card Data'),
	(16, NULL, NULL, NULL, NULL, '-25', 'Card cannot be retired', '-25', 'Card cannot be retired'),
	(17, NULL, NULL, NULL, NULL, '3001', 'The length of firstname and lastname exceed limitation', '3001', 'The length of firstname and lastname exceed limitation'),
	(18, NULL, NULL, NULL, NULL, '3002', 'Failed to generate checksum', '3002', 'Failed to generate checksum'),
	(19, NULL, NULL, NULL, NULL, '3003', 'Failed to bind XML content', '3003', 'Failed to bind XML content'),
	(20, NULL, NULL, NULL, NULL, '3004', 'Key not found Exception', '3004', 'Key not found Exception'),
	(21, NULL, NULL, NULL, NULL, '3005', 'Invalid PAN', '3005', 'Invalid PAN'),
	(22, NULL, NULL, NULL, NULL, '3006', 'User card not found', '3006', 'User card not found'),
	(23, NULL, NULL, NULL, NULL, '3007', 'An error occurred when create card', '3007', 'An error occurred when create card'),
	(24, NULL, NULL, NULL, NULL, '3008', 'An error occurred when get active card', '3008', 'An error occurred when get active card'),
	(25, NULL, NULL, NULL, NULL, '3009', 'Unknown response code', '3009', 'Unknown response code'),
	(26, NULL, NULL, NULL, NULL, '3011', 'Card type not found', '3011', 'Card type not found'),
	(27, NULL, NULL, NULL, NULL, '3012', 'Terminal Id not found', '3012', 'Terminal Id not found'),
	(28, NULL, NULL, NULL, NULL, '3013', 'Campaign Id not found', '3013', 'Campaign Id not found'),
	(29, NULL, NULL, NULL, NULL, '3014', 'Card order not found', '3014', 'Card order not found'),
	(30, NULL, NULL, NULL, NULL, '3015', 'Card already was imported', '3015', 'Card already was imported'),
	(31, NULL, NULL, NULL, NULL, '3016', 'Card order address is invalid', '3016', 'Card order address is invalid'),
	(32, NULL, NULL, NULL, NULL, '3017', 'Request check sum is invalid', '3017', 'Request check sum is invalid'),
	(33, NULL, NULL, NULL, NULL, '3018', 'Cannot parse string to datetime.', '3018', 'Cannot parse string to datetime.'),
	(34, NULL, NULL, NULL, NULL, '3019', 'Tutuka transaction not found', '3019', 'Tutuka transaction not found'),
	(35, NULL, NULL, NULL, NULL, '3020', 'Transaction not found', '3020', 'Transaction not found'),
	(36, NULL, NULL, NULL, NULL, '3021', 'Cannot save to database', '3021', 'Cannot save to database'),
	(37, NULL, NULL, NULL, NULL, '3022', 'This card was cancelled', '3022', 'This card was cancelled'),
	(38, NULL, NULL, NULL, NULL, '3023', 'Cannot get check sum', '3023', 'Cannot get check sum'),
	(39, NULL, NULL, NULL, NULL, '3024', 'Job not found', '3024', 'Job not found'),
	(40, NULL, NULL, NULL, NULL, '3025', 'Cannot remove reconciled', '3025', 'Cannot remove reconciled'),
	(41, NULL, NULL, NULL, NULL, '3026', 'Card order detail not found', '3026', 'Card order detail not found'),
	(42, NULL, NULL, NULL, NULL, '3027', 'Invalid thai ID', '3027', 'Invalid thai ID'),
	(43, NULL, NULL, NULL, NULL, '3028', 'Co-brand card data not found', '3028', 'Co-brand card data not found'),
	(44, NULL, NULL, NULL, NULL, '3029', 'Order card was not imported', '3029', 'Order card was not imported'),
	(45, NULL, NULL, NULL, NULL, '3999', 'PPC general error', '3999', 'PPC general error');
/*!40000 ALTER TABLE `status_code` ENABLE KEYS */;

-- Dumping structure for table vn_wallet_prepaid.transaction
DROP TABLE IF EXISTS `transaction`;
CREATE TABLE IF NOT EXISTS `transaction` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CREATED_TIME` datetime DEFAULT NULL,
  `CREATOR_ID` bigint(20) DEFAULT NULL,
  `LAST_UPDATED_TIME` datetime DEFAULT NULL,
  `LAST_UPDATED_ID` bigint(20) DEFAULT NULL,
  `CANCELLED` int(11) DEFAULT NULL,
  `CARD_IDENTIFIER` varchar(255) DEFAULT NULL,
  `CARD_TYPE` int(11) DEFAULT NULL,
  `CELL_PHONE_NUMBER` varchar(255) DEFAULT NULL,
  `EXPIRY_DATE` datetime DEFAULT NULL,
  `FIRST_NAME` varchar(255) DEFAULT NULL,
  `ID_OR_PASSPORT` varchar(255) DEFAULT NULL,
  `LAST_NAME` varchar(255) DEFAULT NULL,
  `NARRATIVE` varchar(255) DEFAULT NULL,
  `NOTE` varchar(255) DEFAULT NULL,
  `PAN` varchar(255) DEFAULT NULL,
  `PROFILE_NUMBER` varchar(255) DEFAULT NULL,
  `REASON_ID` int(11) DEFAULT NULL,
  `REF_TRANSACTION_ID` varchar(255) NOT NULL,
  `REFERENCE` varchar(255) DEFAULT NULL,
  `REQUEST_AMOUNT` int(11) DEFAULT NULL,
  `STATUS` int(11) DEFAULT NULL,
  `TERMINAL_ID` varchar(255) DEFAULT NULL,
  `TRANSACTION_DATE` datetime DEFAULT NULL,
  `TRANSACTION_TYPE` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=ascii;

-- Dumping data for table vn_wallet_prepaid.transaction: ~4 rows (approximately)
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
INSERT INTO `transaction` (`ID`, `CREATED_TIME`, `CREATOR_ID`, `LAST_UPDATED_TIME`, `LAST_UPDATED_ID`, `CANCELLED`, `CARD_IDENTIFIER`, `CARD_TYPE`, `CELL_PHONE_NUMBER`, `EXPIRY_DATE`, `FIRST_NAME`, `ID_OR_PASSPORT`, `LAST_NAME`, `NARRATIVE`, `NOTE`, `PAN`, `PROFILE_NUMBER`, `REASON_ID`, `REF_TRANSACTION_ID`, `REFERENCE`, `REQUEST_AMOUNT`, `STATUS`, `TERMINAL_ID`, `TRANSACTION_DATE`, `TRANSACTION_TYPE`) VALUES
	(1, '2017-06-12 11:50:39', 0, NULL, NULL, NULL, '', 0, '', NULL, '', '', '', NULL, '', NULL, '3133170484', 0, '', '', NULL, 0, '0094276952', '2017-06-12 11:50:39', 'GET_CARD'),
	(2, '2017-06-12 11:53:52', 0, NULL, NULL, NULL, '', 0, '', NULL, '', '', '', NULL, '', NULL, '3133170484', 0, '', '', NULL, 0, '0094276952', '2017-06-12 11:53:52', 'GET_CARD'),
	(3, '2017-06-12 13:36:56', 0, NULL, NULL, NULL, '', 0, '', NULL, '', '', '', NULL, '', NULL, '3133170484', 0, '', '', NULL, 0, '0094276952', '2017-06-12 13:36:56', 'GET_CARD'),
	(4, '2017-06-12 14:02:50', 0, NULL, NULL, NULL, '', 0, '', NULL, '', '', '', NULL, '', NULL, '3133170484', 0, '', '', NULL, 0, '0094276952', '2017-06-12 14:02:50', 'GET_CARD');
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
