-- --------------------------------------------------------
-- Máy chủ:                      127.0.0.1
-- Server version:               5.7.18-log - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Phiên bản:           9.4.0.5170
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for vn_wallet_cfg_setting
/*CREATE DATABASE IF NOT EXISTS `vn_wallet_cfg_setting` !40100 DEFAULT CHARACTER SET ascii */;
/*USE `vn_wallet_cfg_setting`*/;

-- Dumping structure for table vn_wallet_cfg_setting.spending_limit
CREATE TABLE IF NOT EXISTS `spending_limit` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CREATED_TIME` datetime DEFAULT NULL,
  `CREATOR_ID` bigint(20) DEFAULT NULL,
  `LAST_UPDATED_TIME` datetime DEFAULT NULL,
  `LAST_UPDATED_ID` bigint(20) DEFAULT NULL,
  `KYC_TYPE` varchar(255) DEFAULT NULL,
  `VALUE_PER_DAY` bigint(20) DEFAULT NULL,
  `VALUE_PER_MONTH` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=ascii;

-- Dumping data for table vn_wallet_cfg_setting.spending_limit: ~2 rows (approximately)
/*!40000 ALTER TABLE `spending_limit` DISABLE KEYS */;
INSERT INTO `spending_limit` (`ID`, `CREATED_TIME`, `CREATOR_ID`, `LAST_UPDATED_TIME`, `LAST_UPDATED_ID`, `KYC_TYPE`, `VALUE_PER_DAY`, `VALUE_PER_MONTH`) VALUES
	(1, '2017-06-16 18:37:45', 0, '2017-06-16 18:37:45', 0, 'PARTIAL_KYC', 20000000, 50000000),
	(2, '2017-06-16 18:37:45', 0, '2017-06-19 09:20:34', 0, 'FULL_KYC', 50000000, 300000000);
/*!40000 ALTER TABLE `spending_limit` ENABLE KEYS */;

-- Dumping structure for table vn_wallet_cfg_setting.transaction_limit
CREATE TABLE IF NOT EXISTS `transaction_limit` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CREATED_TIME` datetime DEFAULT NULL,
  `CREATOR_ID` bigint(20) DEFAULT NULL,
  `LAST_UPDATED_TIME` datetime DEFAULT NULL,
  `LAST_UPDATED_ID` bigint(20) DEFAULT NULL,
  `KYC_TYPE` varchar(255) DEFAULT NULL,
  `MAX_VALUE_PER_TRANSACTION` bigint(20) DEFAULT NULL,
  `MAX_VALUE_TRANSACTION_PER_DAY` bigint(20) DEFAULT NULL,
  `MIN_VALUE_PER_TRANSACTION` bigint(20) DEFAULT NULL,
  `SERVICE_GROUP` varchar(255) DEFAULT NULL,
  `TRANSACTION_TYPE` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=ascii;

-- Dumping data for table vn_wallet_cfg_setting.transaction_limit: ~10 rows (approximately)
/*!40000 ALTER TABLE `transaction_limit` DISABLE KEYS */;
INSERT INTO `transaction_limit` (`ID`, `CREATED_TIME`, `CREATOR_ID`, `LAST_UPDATED_TIME`, `LAST_UPDATED_ID`, `KYC_TYPE`, `MAX_VALUE_PER_TRANSACTION`, `MAX_VALUE_TRANSACTION_PER_DAY`, `MIN_VALUE_PER_TRANSACTION`, `SERVICE_GROUP`, `TRANSACTION_TYPE`) VALUES
	(1, NULL, NULL, '2017-06-16 18:39:33', 0, 'PARTIAL_KYC', 2000000, 5000000, 20000, 'FUND-IN', 'are you ok'),
	(2, NULL, NULL, '2017-06-16 18:39:33', 0, 'PARTIAL_KYC', 5000000, 10000000, 20000, 'FUND-IN', 'FUND_IN_VIA_NAPAS'),
	(3, NULL, NULL, '2017-06-16 18:39:33', 0, 'PARTIAL_KYC', 1000000, 1000000, 20000, 'FUND-OUT', 'FUND_OUT_TO_LINKED_BANK'),
	(4, NULL, NULL, '2017-06-16 18:39:33', 0, 'PARTIAL_KYC', 1000000, 2000000, 10000, 'CARD PAYMENT', 'VIRTUAL_CARD_PAYMENT'),
	(5, NULL, NULL, '2017-06-16 18:39:33', 0, 'PARTIAL_KYC', 500000, 2000000, 10000, 'TOPUP', 'TOPUP_PIN_ALL'),
	(6, NULL, NULL, '2017-06-19 09:20:34', 0, 'FULL_KYC', 10000000, 10000000, 20000, 'FUND-IN', 'FUND_IN_VIA_LINKED_BANK'),
	(7, NULL, NULL, '2017-06-19 09:20:34', 0, 'FULL_KYC', 20000000, 20000000, 20000, 'FUND-IN', 'FUND_IN_VIA_NAPAS'),
	(8, NULL, NULL, '2017-06-19 09:20:34', 0, 'FULL_KYC', 5000000, 1000000, 20000, 'FUND-OUT', 'FUND_OUT_TO_LINKED_BANK'),
	(9, NULL, NULL, '2017-06-19 09:20:34', 0, 'FULL_KYC', 10000000, 15000000, 10000, 'CARD PAYMENT', 'VIRTUAL_CARD_PAYMENT'),
	(10, NULL, NULL, '2017-06-19 09:20:34', 0, 'FULL_KYC', 5000000, 4000000, 10000, 'TOPUP', 'TOPUP_PIN_ALL');
/*!40000 ALTER TABLE `transaction_limit` ENABLE KEYS */;

-- Dumping structure for table vn_wallet_cfg_setting.wallet_balance
CREATE TABLE IF NOT EXISTS `wallet_balance` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CREATED_TIME` datetime DEFAULT NULL,
  `CREATOR_ID` bigint(20) DEFAULT NULL,
  `LAST_UPDATED_TIME` datetime DEFAULT NULL,
  `LAST_UPDATED_ID` bigint(20) DEFAULT NULL,
  `AMOUNT` bigint(20) DEFAULT NULL,
  `KYC_TYPE` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=ascii;

-- Dumping data for table vn_wallet_cfg_setting.wallet_balance: ~2 rows (approximately)
/*!40000 ALTER TABLE `wallet_balance` DISABLE KEYS */;
INSERT INTO `wallet_balance` (`ID`, `CREATED_TIME`, `CREATOR_ID`, `LAST_UPDATED_TIME`, `LAST_UPDATED_ID`, `AMOUNT`, `KYC_TYPE`) VALUES
	(1, NULL, NULL, '2017-06-16 18:39:32', 0, 23424324234, 'PARTIAL_KYC'),
	(2, NULL, NULL, '2017-06-19 09:20:34', 0, 500000000, 'FULL_KYC');
/*!40000 ALTER TABLE `wallet_balance` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
