-- MySQL dump 10.13  Distrib 5.7.18, for Linux (x86_64)
--
-- Host: localhost    Database: vn_wallet_gateway
-- ------------------------------------------------------
-- Server version	5.7.18-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `vn_wallet_gateway`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `vn_wallet_gateway` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `vn_wallet_gateway`;

--
-- Table structure for table `BIZ_CUSTOMER`
--

DROP TABLE IF EXISTS `BIZ_CUSTOMER`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BIZ_CUSTOMER` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CREATED_TIME` datetime DEFAULT NULL,
  `CREATOR_ID` bigint(20) DEFAULT NULL,
  `LAST_UPDATED_TIME` datetime DEFAULT NULL,
  `LAST_UPDATED_ID` bigint(20) DEFAULT NULL,
  `AUTH_URL` varchar(255) DEFAULT NULL,
  `CIF` varchar(255) DEFAULT NULL,
  `EMAIL` varchar(255) DEFAULT NULL,
  `FULL_NAME` varchar(255) DEFAULT NULL,
  `MSISDN` varchar(255) DEFAULT NULL,
  `PASSWORD` varchar(255) DEFAULT NULL,
  `SECRET` varchar(255) DEFAULT NULL,
  `USERNAME` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_5oqv5mhxnttm4rjv0o3non5io` (`CIF`),
  UNIQUE KEY `UK_fevdq463hyhxciwyn74xaj46n` (`USERNAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BIZ_CUSTOMER`
--

LOCK TABLES `BIZ_CUSTOMER` WRITE;
/*!40000 ALTER TABLE `BIZ_CUSTOMER` DISABLE KEYS */;
/*!40000 ALTER TABLE `BIZ_CUSTOMER` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EWALLET_SESSIONS`
--

DROP TABLE IF EXISTS `EWALLET_SESSIONS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EWALLET_SESSIONS` (
  `SESSION_ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CREATED_TIME` datetime DEFAULT NULL,
  `CREATOR_ID` bigint(20) DEFAULT NULL,
  `LAST_UPDATED_TIME` datetime DEFAULT NULL,
  `LAST_UPDATED_ID` bigint(20) DEFAULT NULL,
  `ACTIVED_TIME` datetime DEFAULT NULL,
  `APP_VERSION` varchar(255) DEFAULT NULL,
  `EXPIRED_TIME` datetime DEFAULT NULL,
  `IP` varchar(32) NOT NULL,
  `REQUEST_ID` varchar(80) NOT NULL,
  `STATUS` varchar(255) DEFAULT NULL,
  `TOKEN_EQ` varchar(32) NOT NULL,
  PRIMARY KEY (`SESSION_ID`),
  UNIQUE KEY `UK_67qc84db22savq2wyc6h4ypg4` (`TOKEN_EQ`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EWALLET_SESSIONS`
--

LOCK TABLES `EWALLET_SESSIONS` WRITE;
/*!40000 ALTER TABLE `EWALLET_SESSIONS` DISABLE KEYS */;
/*!40000 ALTER TABLE `EWALLET_SESSIONS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ewallet_sessions`
--

DROP TABLE IF EXISTS `ewallet_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ewallet_sessions` (
  `session_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `CREATED_TIME` datetime DEFAULT NULL,
  `CREATOR_ID` bigint(20) DEFAULT NULL,
  `LAST_UPDATED_TIME` datetime DEFAULT NULL,
  `LAST_UPDATED_ID` bigint(20) DEFAULT NULL,
  `actived_time` datetime DEFAULT NULL,
  `app_version` varchar(10) NOT NULL,
  `expired_time` datetime DEFAULT NULL,
  `IP` varchar(20) NOT NULL,
  `request_id` varchar(30) NOT NULL,
  `session_key` varchar(50) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `token` varchar(50) NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ewallet_sessions`
--

LOCK TABLES `ewallet_sessions` WRITE;
/*!40000 ALTER TABLE `ewallet_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `ewallet_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vnwallet_session`
--

DROP TABLE IF EXISTS `vnwallet_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vnwallet_session` (
  `session_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `CREATED_TIME` datetime DEFAULT NULL,
  `CREATOR_ID` bigint(20) DEFAULT NULL,
  `LAST_UPDATED_TIME` datetime DEFAULT NULL,
  `LAST_UPDATED_ID` bigint(20) DEFAULT NULL,
  `actived_time` datetime DEFAULT NULL,
  `app_version` varchar(10) NOT NULL,
  `expired_time` datetime DEFAULT NULL,
  `IP` varchar(20) NOT NULL,
  `request_id` varchar(30) NOT NULL,
  `session_key` varchar(50) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `token` varchar(50) NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vnwallet_session`
--

LOCK TABLES `vnwallet_session` WRITE;
/*!40000 ALTER TABLE `vnwallet_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `vnwallet_session` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-06-12  7:40:51
