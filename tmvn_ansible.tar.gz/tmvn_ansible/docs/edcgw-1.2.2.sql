CREATE TABLE service_map(
    service_id serial primary key,
    service_name varchar(30) ,
    method_name varchar(150),
    type varchar(10),
    option varchar(2),
    status varchar(10)
);

CREATE TABLE rule_config(
    rule_id integer not null,
    service_id integer not null,
    primary key(rule_id,service_id)
);


CREATE TABLE user_service_config(
  id serial primary key,
  account_id varchar(10) not null,
  card_id varchar(12) not null,
  device_id varchar(20) not null default 'N/A'::varchar,
  reg_version varchar(15) not null default 'N/A'::varchar,
  province_code varchar(10),
  from_date date,
  to_date date,
  rule_id integer,
  status varchar(10),
  created_at timestamp without time zone,
  updated_at timestamp without time zone,
  created_id integer,
  updated_id integer
);

alter table edc_sessions
add column service_list text, 
add column method_list text;

----------------------
insert into service_map(service_id, service_name, method_name,type,option,status) values ('1','banlance_inquiry','req_check_balance_check,req_check_balance_confirm','','Y','active');

insert into service_map(service_id, service_name, method_name,type,option,status) values ('2','pin_code','req_ptu_check,req_ptu_confirm,req_ptu_mult_card_check,req_ptu_mult_card_confirm','','Y','active');
 
insert into service_map(service_id, service_name, method_name,type,option,status) values ('3','pinless','req_pinless_confirm','','Y','active');

insert into service_map(service_id, service_name, method_name,type,option,status) values ('4','change_cus_pwd','req_change_cus_pwd,req_change_password','','Y','active');

insert into service_map(service_id, service_name, method_name,type,option,status) values ('5','re_pincode_serial_confirm','req_reptu_confirm_serial,req_reptu_confirm','','Y','active');

insert into service_map(service_id, service_name, method_name,type,option,status) values ('6','req_deposit,req_withdraw','req_deposit_withdraw','','Y','active');

insert into service_map(service_id, service_name, method_name,type,option,status) values ('7','minitxnreport','req_transaction_reports','','Y','active');

insert into service_map(service_id, service_name, method_name,type,option,status) values ('8','req_agent_revenue_report','req_agent_revenue_reports','','Y','active');

insert into service_map(service_id, service_name, method_name,type,option,status) values ('9','dealer_banks','req_dealer_banks','','Y','active');

insert into service_map(service_id, service_name, method_name,type,option,status) values ('10','money_transfer','req_money_transfer_check,req_money_transfer_confirm','','Y','active');

insert into service_map(service_id, service_name, method_name,type,option,status) values ('11','bill_payment','req_billpay_precheck,req_billpay_check,req_billpay_confirm','','Y','active'); 

insert into service_map(service_id, service_name, method_name,type,option,status) values ('12','cash_in','req_cash_in_check,req_cash_in_confirm','','Y','active'); 

insert into service_map(service_id, service_name, method_name,type,option,status) values ('13','cash_out','req_cash_out_check,req_cash_out_confirm','','Y','active'); 

----------------------
insert into rule_config(rule_id, service_id) values (1,1); 

insert into rule_config(rule_id, service_id) values (1,2); 

insert into rule_config(rule_id, service_id) values (1,3); 

insert into rule_config(rule_id, service_id) values (1,4); 

insert into rule_config(rule_id, service_id) values (1,5);

insert into rule_config(rule_id, service_id) values (1,6);

insert into rule_config(rule_id, service_id) values (1,7);

insert into rule_config(rule_id, service_id) values (1,8);

insert into rule_config(rule_id, service_id) values (1,9);   

insert into rule_config(rule_id, service_id) values (2,10);

insert into rule_config(rule_id, service_id) values (2,11);

insert into rule_config(rule_id, service_id) values (2,12);    

insert into rule_config(rule_id, service_id) values (2,13);

insert into rule_config(rule_id, service_id) values (3,10); 

insert into rule_config(rule_id, service_id) values (4,11); 

insert into rule_config(rule_id, service_id) values (5,12);

insert into rule_config(rule_id, service_id) values (6,13);       


----------------------
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55043005','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55043038','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55053003','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55053001','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55043048','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55053011','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55033062','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55033036','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55063019','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55063010','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55063038','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55033003','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55033042','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55013017','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55013042','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55023058','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55013043','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55023057','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55023033','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55033037','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55033047','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55033014','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55023030','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55033070','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55063004','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55063036','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55013044','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55013001','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55013026','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55013057','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55013031','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55023013','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55033053','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('55033051','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70203004','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70073028','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70063007','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70223004','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70163001','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70073027','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70133001','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70093006','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70083012','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70223005','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70073008','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70043007','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70043013','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70233002','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70073031','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70183008','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70203003','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70073005','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70133015','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70053009','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70183001','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70053013','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70133008','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70073007','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70083002','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70063008','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70043005','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70223018','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70223006','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70083006','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70023009','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70083005','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70123009','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70123002','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70223002','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70073009','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70183004','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70083017','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70083025','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70093001','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70073006','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70133004','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70083001','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70053006','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70203001','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70073012','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70043009','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70023020','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70183006','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70043021','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70153003','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70233001','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70083015','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70183002','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70183009','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70053012','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70093007','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70023006','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70033004','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70043006','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70053008','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70073021','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70133014','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70083010','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70193001','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70203006','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70213003','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('70043001','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10053035','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10133008','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10063019','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10133001','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10063057','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10063051','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10063044','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10173008','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10173007','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10173011','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10093015','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10093022','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10073007','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10073048','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10073045','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10073032','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10083011','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10083017','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10083052','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10083006','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10043018','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10043031','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('16033001','','','1.2.2.10',4); 
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10023017','','','1.2.2.10',4);
insert into user_service_config(account_id, card_id, device_id, reg_version, rule_id) values ('10023005','','','1.2.2.9',4);
