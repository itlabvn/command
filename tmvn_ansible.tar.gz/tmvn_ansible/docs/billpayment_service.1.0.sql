--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.1
-- Dumped by pg_dump version 9.6.1

-- Started on 2017-02-24 11:04:33

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 5 (class 2615 OID 16387)
-- Name: billpay; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA billpay;


SET search_path = billpay, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 206 (class 1259 OID 17584)
-- Name: bill_transaction_log; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE bill_transaction_log (
    id bigint NOT NULL,
    trans_amount double precision,
    bills character varying(255),
    created_time timestamp without time zone,
    creator_id integer,
    crm_trans_log character varying(255),
    db_active character varying(255),
    ids_val character varying(255),
    last_updated_id integer,
    last_updated_time timestamp without time zone,
    merchant character varying(255),
    provider character varying(255),
    return_code character varying(255),
    return_message text,
    service character varying(255),
    status boolean,
    trans_date timestamp without time zone,
    trans_ref character varying(255),
    transaction_type character varying(255)
);


--
-- TOC entry 187 (class 1259 OID 16412)
-- Name: biller; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE biller (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    biller_id integer NOT NULL,
    name character varying(255),
    db_active character(1)
);


--
-- TOC entry 188 (class 1259 OID 16417)
-- Name: billpay_provider; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE billpay_provider (
    prvd_id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    base_uri character varying(255),
    input character varying(255),
    name character varying(255),
    private_key character varying(255),
    provider_code integer NOT NULL,
    secret_key character varying(255),
    commission real,
    db_active character(1),
    connect_params text
);


--
-- TOC entry 197 (class 1259 OID 16630)
-- Name: card_item; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE card_item (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    description character varying(255),
    expired_date timestamp without time zone,
    pin character varying(255),
    serial character varying(255),
    status character varying(255),
    title character varying(255),
    type character varying(255),
    face integer,
    db_active character(1)
);


--
-- TOC entry 210 (class 1259 OID 17642)
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: billpay; Owner: -
--

CREATE SEQUENCE hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 186 (class 1259 OID 16404)
-- Name: merchan_info; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE merchan_info (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    merchant_code integer,
    merchant_key character varying(255),
    merchant_name character varying(255),
    merchant_pkey_path character varying(255),
    commission real,
    db_active character(1)
);


--
-- TOC entry 189 (class 1259 OID 16425)
-- Name: paid_bill; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE paid_bill (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    paid_amount double precision,
    bill_no character varying(255),
    bill_trans_log_id bigint,
    customer_name character varying(255),
    identifiers_value character varying(255),
    merchant_code integer,
    provider_id integer,
    service_id integer,
    agent_comm real,
    tmv_comm real,
    db_active character(1),
    trans_date timestamp(0) without time zone
);


--
-- TOC entry 190 (class 1259 OID 16433)
-- Name: parent_service; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE parent_service (
    ps_id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    name character varying(255),
    db_active character(1)
);


--
-- TOC entry 207 (class 1259 OID 17592)
-- Name: payment_order; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE payment_order (
    order_id bigint NOT NULL,
    address character varying(255),
    amount numeric(19,2),
    bill_no character varying(255),
    contract_no character varying(255),
    create_time timestamp without time zone,
    customer_name character varying(255),
    feeamount numeric(19,2),
    merchant_code integer,
    order_info character varying(255),
    paymnet_order_no character varying(255),
    provider_code integer,
    service_code integer,
    status character varying(255),
    totalamount numeric(19,2),
    trans_ref character varying(255),
    update_time timestamp without time zone,
    user_id integer
);


--
-- TOC entry 208 (class 1259 OID 17600)
-- Name: payment_transaction; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE payment_transaction (
    payment_id bigint NOT NULL,
    amount double precision,
    link_request character varying(255),
    order_info character varying(255),
    order_type character varying(255),
    order_id character varying(255),
    provider_return_message text,
    provider_return_code character varying(255),
    request_time date,
    response_code character varying(255),
    response_message text,
    response_time date,
    trans_ref character varying(255),
    trans_status character varying(255)
);


--
-- TOC entry 191 (class 1259 OID 16438)
-- Name: provider_api; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE provider_api (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    api_params character varying(255),
    api_response_data character varying(255),
    api_response_status character varying(255),
    method_name character varying(255) NOT NULL,
    provider bytea,
    request_type character varying(255) NOT NULL,
    db_active character(1)
);


--
-- TOC entry 201 (class 1259 OID 17553)
-- Name: sec_permission; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE sec_permission (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    db_active character(1),
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    description character varying(255),
    name character varying(50),
    type character varying(255)
);


--
-- TOC entry 202 (class 1259 OID 17561)
-- Name: sec_role; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE sec_role (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    db_active character(1),
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    description character varying(255),
    name character varying(50),
    type character varying(255)
);


--
-- TOC entry 203 (class 1259 OID 17569)
-- Name: sec_role_permission; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE sec_role_permission (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    db_active character(1),
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    permission_id bigint,
    role_id bigint
);


--
-- TOC entry 204 (class 1259 OID 17574)
-- Name: sec_user; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE sec_user (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    db_active character(1),
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    cif character varying(64),
    password character varying(50),
    username character varying(50)
);


--
-- TOC entry 205 (class 1259 OID 17579)
-- Name: sec_user_role; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE sec_user_role (
    id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    db_active character(1),
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    role_id bigint,
    user_id bigint
);


--
-- TOC entry 209 (class 1259 OID 17640)
-- Name: seq_id_entity; Type: SEQUENCE; Schema: billpay; Owner: -
--

CREATE SEQUENCE seq_id_entity
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 192 (class 1259 OID 16446)
-- Name: service; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE service (
    s_id bigint NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    name character varying(255) NOT NULL,
    service_code integer NOT NULL,
    ps_id bigint NOT NULL,
    db_active character(1)
);


--
-- TOC entry 193 (class 1259 OID 16451)
-- Name: service_provider; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE service_provider (
    id integer NOT NULL,
    prvd_id bigint NOT NULL,
    s_id bigint NOT NULL
);


--
-- TOC entry 199 (class 1259 OID 16997)
-- Name: test_bill_id_seq; Type: SEQUENCE; Schema: billpay; Owner: -
--

CREATE SEQUENCE test_bill_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 200 (class 1259 OID 17029)
-- Name: test_bill; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE test_bill (
    id bigint DEFAULT nextval('test_bill_id_seq'::regclass) NOT NULL,
    created_time timestamp without time zone,
    creator_id bigint,
    db_active character(1),
    last_updated_time timestamp without time zone,
    last_updated_id bigint,
    address character varying(255),
    amount double precision,
    bill_no character varying(255),
    contract_no character varying(255),
    from_date character varying(255),
    full_name character varying(255),
    is_paid_all boolean,
    provider character varying(255),
    service character varying(255),
    to_date character varying(255),
    unpaid_amount double precision
);


--
-- TOC entry 196 (class 1259 OID 16515)
-- Name: user_roles; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE user_roles (
    user_role_id integer,
    user_name character varying(255) DEFAULT NULL::character varying,
    role character varying(30) DEFAULT NULL::character varying
);


--
-- TOC entry 195 (class 1259 OID 16507)
-- Name: users; Type: TABLE; Schema: billpay; Owner: -
--

CREATE TABLE users (
    id bigint NOT NULL,
    user_name character varying(255) NOT NULL,
    password character varying(30) NOT NULL,
    full_name character varying(50) NOT NULL,
    age integer,
    address character varying(100) DEFAULT NULL::character varying,
    phone_number character varying(15) DEFAULT NULL::character varying,
    enabled integer,
    create_time timestamp without time zone,
    update_time timestamp without time zone
);


--
-- TOC entry 194 (class 1259 OID 16505)
-- Name: users_id_seq; Type: SEQUENCE; Schema: billpay; Owner: -
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 2354 (class 0 OID 0)
-- Dependencies: 194
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: billpay; Owner: -
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- TOC entry 2134 (class 2604 OID 16510)
-- Name: users id; Type: DEFAULT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- TOC entry 2345 (class 0 OID 17584)
-- Dependencies: 206
-- Data for Name: bill_transaction_log; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY bill_transaction_log (id, trans_amount, bills, created_time, creator_id, crm_trans_log, db_active, ids_val, last_updated_id, last_updated_time, merchant, provider, return_code, return_message, service, status, trans_date, trans_ref, transaction_type) FROM stdin;
\.


--
-- TOC entry 2327 (class 0 OID 16412)
-- Dependencies: 187
-- Data for Name: biller; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY biller (id, created_time, creator_id, last_updated_time, last_updated_id, biller_id, name, db_active) FROM stdin;
\.


--
-- TOC entry 2328 (class 0 OID 16417)
-- Dependencies: 188
-- Data for Name: billpay_provider; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY billpay_provider (prvd_id, created_time, creator_id, last_updated_time, last_updated_id, base_uri, input, name, private_key, provider_code, secret_key, commission, db_active, connect_params) FROM stdin;
1	2017-01-10 16:19:54	0	\N	\N	http://ip2.public.vtvcab.vn:86	subNum	VTVCab	\N	1	e2ea936a04757d5c416c0b5c260667ee	0	Y	11|1Pay|e2ea936a04757d5c416c0b5c260667ee
\.


--
-- TOC entry 2337 (class 0 OID 16630)
-- Dependencies: 197
-- Data for Name: card_item; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY card_item (id, created_time, creator_id, last_updated_time, last_updated_id, description, expired_date, pin, serial, status, title, type, face, db_active) FROM stdin;
\.


--
-- TOC entry 2355 (class 0 OID 0)
-- Dependencies: 210
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: billpay; Owner: -
--

SELECT pg_catalog.setval('hibernate_sequence', 12, true);


--
-- TOC entry 2326 (class 0 OID 16404)
-- Dependencies: 186
-- Data for Name: merchan_info; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY merchan_info (id, created_time, creator_id, last_updated_time, last_updated_id, merchant_code, merchant_key, merchant_name, merchant_pkey_path, commission, db_active) FROM stdin;
1	2016-12-23 00:00:00	1	\N	\N	1	m7rscHScIsB87PKur5RTdVfpPQeQRn	TrueMoney	key/truemoney/PublicKey.ber	0.5	Y
2	2017-01-05 10:03:59	1	\N	\N	2	al4pC2vNrCn0mirlArfuR2dVDHrvMB	MyBill	key/mybill/PublicKey.ber	0.5	Y
\.


--
-- TOC entry 2329 (class 0 OID 16425)
-- Dependencies: 189
-- Data for Name: paid_bill; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY paid_bill (id, created_time, creator_id, last_updated_time, last_updated_id, paid_amount, bill_no, bill_trans_log_id, customer_name, identifiers_value, merchant_code, provider_id, service_id, agent_comm, tmv_comm, db_active, trans_date) FROM stdin;
\.


--
-- TOC entry 2330 (class 0 OID 16433)
-- Dependencies: 190
-- Data for Name: parent_service; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY parent_service (ps_id, created_time, creator_id, last_updated_time, last_updated_id, name, db_active) FROM stdin;
1	2017-01-13 14:27:20	0	\N	\N	Truyền hình cab	\N
2	2017-01-13 14:27:20	0	\N	\N	Internet	\N
3	2017-01-13 14:27:20	0	\N	\N	Điện	\N
4	2017-01-13 14:27:20	0	\N	\N	Nước	\N
5	2017-01-13 14:27:20	0	\N	\N	Điện thoại cố định	\N
6	2017-01-13 14:27:20	0	\N	\N	Di động trả sau	\N
7	2017-01-13 14:27:20	0	\N	\N	Vé máy bay	\N
8	2017-01-13 14:27:20	0	\N	\N	Dịch vụ tiện ích	\N
9	2017-01-13 14:27:20	0	\N	\N	Thu hộ tín dụng	\N
10	2017-01-13 14:27:20	0	\N	\N	Thu hộ bảo hiểm	\N
\.


--
-- TOC entry 2346 (class 0 OID 17592)
-- Dependencies: 207
-- Data for Name: payment_order; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY payment_order (order_id, address, amount, bill_no, contract_no, create_time, customer_name, feeamount, merchant_code, order_info, paymnet_order_no, provider_code, service_code, status, totalamount, trans_ref, update_time, user_id) FROM stdin;
\.


--
-- TOC entry 2347 (class 0 OID 17600)
-- Dependencies: 208
-- Data for Name: payment_transaction; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY payment_transaction (payment_id, amount, link_request, order_info, order_type, order_id, provider_return_message, provider_return_code, request_time, response_code, response_message, response_time, trans_ref, trans_status) FROM stdin;
\.


--
-- TOC entry 2331 (class 0 OID 16438)
-- Dependencies: 191
-- Data for Name: provider_api; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY provider_api (id, created_time, creator_id, last_updated_time, last_updated_id, api_params, api_response_data, api_response_status, method_name, provider, request_type, db_active) FROM stdin;
\.


--
-- TOC entry 2340 (class 0 OID 17553)
-- Dependencies: 201
-- Data for Name: sec_permission; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY sec_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) FROM stdin;
2	2017-02-21 00:00:00	0	Y	\N	\N	Filter Bill Permission	FILTER_BILL	FILTER_BILL
3	2017-02-21 00:00:00	0	Y	\N	\N	Pay One Bill	PAY_A_BILL	PAY_A_BILL
4	2017-02-21 00:00:00	0	Y	\N	\N	View transaction list	VIEW_TRANSACTION	VIEW_TRANSACTION
5	2017-02-21 00:00:00	0	Y	\N	\N	Export excel file	EXPORT_TRANSACTION	EXPORT_TRANSACTION
10	2017-02-21 00:00:00	0	Y	\N	\N	Export excel file	EXPORT_RECONCILE_DETAIL	EXPORT_RECONCILE_DETAIL
9	2017-02-21 00:00:00	0	Y	\N	\N	View reconcile detail	VIEW_RECONCILE_DETAIL	VIEW_RECONCILE_DETAIL
8	2017-02-21 00:00:00	0	Y	\N	\N	Export excel file	EXPORT_RECONCILE	EXPORT_RECONCILE
7	2017-02-21 00:00:00	0	Y	\N	\N	View reconciliation list	VIEW_RECONCILE	VIEW_RECONCILE
6	2017-02-21 00:00:00	0	Y	\N	\N	Filter reconciliation	FILTER_RECONCILE	FILTER_RECONCILE
1	2017-02-21 12:00:00	0	Y	\N	\N	Pay All Bill Permission	PAY_ALL_BILL	PAY_ALL_BILL
\.


--
-- TOC entry 2341 (class 0 OID 17561)
-- Dependencies: 202
-- Data for Name: sec_role; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY sec_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, description, name, type) FROM stdin;
2	2017-02-21 00:00:00	0	Y	\N	\N	Role Finance	ROLE_FINANCE	ROLE_FINANCE
1	2017-02-21 12:00:00	0	Y	\N	\N	Role Admin	ROLE_ADMIN	ROLE_ADMIN
3	2017-02-21 00:00:00	0	Y	\N	\N	Role customer care	ROLE_CS	ROLE_CS
4	2017-02-21 00:00:00	0	Y	\N	\N	Role sale manager	ROLE_SALE_MNG	ROLE_SALE_MNG
5	2017-02-21 00:00:00	0	Y	\N	\N	Role sale support	ROLE_SALE_SP	ROLE_SALE_SP
6	2017-02-21 00:00:00	0	Y	\N	\N	Role User	ROLE_USER	ROLE_USER
\.


--
-- TOC entry 2342 (class 0 OID 17569)
-- Dependencies: 203
-- Data for Name: sec_role_permission; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY sec_role_permission (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, permission_id, role_id) FROM stdin;
1	2017-02-21 12:00:00	0	Y	\N	\N	1	1
2	2017-02-21 12:00:00	0	Y	\N	\N	2	1
3	2017-02-21 12:00:00	0	Y	\N	\N	3	1
4	2017-02-21 12:00:00	0	Y	\N	\N	4	1
5	2017-02-21 12:00:00	0	Y	\N	\N	5	1
6	2017-02-21 12:00:00	0	Y	\N	\N	6	1
7	2017-02-21 12:00:00	0	Y	\N	\N	7	1
8	2017-02-21 12:00:00	0	Y	\N	\N	8	1
9	2017-02-21 12:00:00	0	Y	\N	\N	9	1
10	2017-02-21 12:00:00	0	Y	\N	\N	10	1
11	2017-02-21 12:00:00	0	Y	\N	\N	4	3
12	2017-02-21 12:00:00	0	Y	\N	\N	4	2
13	2017-02-21 12:00:00	0	Y	\N	\N	5	2
14	2017-02-21 12:00:00	0	Y	\N	\N	6	2
15	2017-02-21 12:00:00	0	Y	\N	\N	7	2
16	2017-02-21 12:00:00	0	Y	\N	\N	8	2
17	2017-02-21 12:00:00	0	Y	\N	\N	9	2
18	2017-02-21 12:00:00	0	Y	\N	\N	10	2
19	2017-02-21 12:00:00	0	Y	\N	\N	4	4
20	2017-02-21 12:00:00	0	Y	\N	\N	5	4
21	2017-02-21 12:00:00	0	Y	\N	\N	4	5
22	2017-02-21 12:00:00	0	Y	\N	\N	5	5
23	2017-02-21 12:00:00	0	Y	\N	\N	1	6
24	2017-02-21 12:00:00	0	Y	\N	\N	2	6
25	2017-02-21 12:00:00	0	Y	\N	\N	3	6
\.


--
-- TOC entry 2343 (class 0 OID 17574)
-- Dependencies: 204
-- Data for Name: sec_user; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY sec_user (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, cif, password, username) FROM stdin;
1	2017-02-21 12:00:00	0	Y	\N	\N	Admin	b4daa47d847274d8df65306c53a42aaa	admin@truemoney.com.vn
2	2017-02-22 12:00:00	0	Y	\N	\N	Finance Support	b4daa47d847274d8df65306c53a42aaa	finance.support@truemoney.com.vn
3	2017-02-23 12:00:00	0	Y	\N	\N	Customer Care	b4daa47d847274d8df65306c53a42aaa	customer.care@truemoney.com.vn
4	2017-02-24 12:00:00	0	Y	\N	\N	Sale Manager	b4daa47d847274d8df65306c53a42aaa	sale.manager@truemoney.com.vn
5	2017-02-25 12:00:00	0	Y	\N	\N	Sale Support	b4daa47d847274d8df65306c53a42aaa	sale.support@truemoney.com.vn
6	2017-02-21 00:00:00	0	Y	\N	\N	Hoàng Công Bình	b4daa47d847274d8df65306c53a42aaa	binhhc@truemoney.com.vn
\.


--
-- TOC entry 2344 (class 0 OID 17579)
-- Dependencies: 205
-- Data for Name: sec_user_role; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY sec_user_role (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, role_id, user_id) FROM stdin;
1	2017-02-21 12:00:00	0	Y	\N	\N	1	1
2	2017-02-21 00:00:00	0	Y	\N	\N	2	2
3	2017-02-21 00:00:00	0	Y	\N	\N	3	3
4	2017-02-21 00:00:00	0	Y	\N	\N	4	4
5	2017-02-21 00:00:00	0	Y	\N	\N	5	5
6	2017-02-21 12:00:00	0	Y	\N	\N	6	6
\.


--
-- TOC entry 2356 (class 0 OID 0)
-- Dependencies: 209
-- Name: seq_id_entity; Type: SEQUENCE SET; Schema: billpay; Owner: -
--

SELECT pg_catalog.setval('seq_id_entity', 17, true);


--
-- TOC entry 2332 (class 0 OID 16446)
-- Dependencies: 192
-- Data for Name: service; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY service (s_id, created_time, creator_id, last_updated_time, last_updated_id, name, service_code, ps_id, db_active) FROM stdin;
1	2017-01-13 14:27:46	0	\N	\N	VTVCab	1	1	\N
2	2017-01-13 14:50:07	0	\N	\N	Cấp nước Hồ Chí Minh	5	4	\N
\.


--
-- TOC entry 2333 (class 0 OID 16451)
-- Dependencies: 193
-- Data for Name: service_provider; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY service_provider (id, prvd_id, s_id) FROM stdin;
\.


--
-- TOC entry 2339 (class 0 OID 17029)
-- Dependencies: 200
-- Data for Name: test_bill; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY test_bill (id, created_time, creator_id, db_active, last_updated_time, last_updated_id, address, amount, bill_no, contract_no, from_date, full_name, is_paid_all, provider, service, to_date, unpaid_amount) FROM stdin;
\.


--
-- TOC entry 2357 (class 0 OID 0)
-- Dependencies: 199
-- Name: test_bill_id_seq; Type: SEQUENCE SET; Schema: billpay; Owner: -
--

SELECT pg_catalog.setval('test_bill_id_seq', 1, true);


--
-- TOC entry 2336 (class 0 OID 16515)
-- Dependencies: 196
-- Data for Name: user_roles; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY user_roles (user_role_id, user_name, role) FROM stdin;
3	1pay	ROLE_ADMIN
3	1pay	ROLE_USER
5	finance.support@truemoney.com.vn	ROLE_FINANCE_SUPPORT
\.


--
-- TOC entry 2335 (class 0 OID 16507)
-- Dependencies: 195
-- Data for Name: users; Type: TABLE DATA; Schema: billpay; Owner: -
--

COPY users (id, user_name, password, full_name, age, address, phone_number, enabled, create_time, update_time) FROM stdin;
1	BillPay	123456	BillPay	20	Ha Noi	09874525466	1	\N	\N
2	123456	123456	BillPay	20	Ha Noi	09874525466	1	\N	\N
3	1pay	123456	BillPay	20	Ha Noi	09874525466	1	\N	\N
4	aipay	123456	BillPay	20	Ha Noi	09874525466	1	\N	\N
5	finance.support@truemoney.com.vn	123456	Finance Support	30	Thái Hà	0123456	1	\N	\N
\.


--
-- TOC entry 2358 (class 0 OID 0)
-- Dependencies: 194
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: billpay; Owner: -
--

SELECT pg_catalog.setval('users_id_seq', 1, true);


--
-- TOC entry 2197 (class 2606 OID 17591)
-- Name: bill_transaction_log bill_transaction_log_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY bill_transaction_log
    ADD CONSTRAINT bill_transaction_log_pkey PRIMARY KEY (id);


--
-- TOC entry 2143 (class 2606 OID 16416)
-- Name: biller biller_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY biller
    ADD CONSTRAINT biller_pkey PRIMARY KEY (id);


--
-- TOC entry 2147 (class 2606 OID 16424)
-- Name: billpay_provider billpay_provider_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY billpay_provider
    ADD CONSTRAINT billpay_provider_pkey PRIMARY KEY (prvd_id);


--
-- TOC entry 2171 (class 2606 OID 16637)
-- Name: card_item card_item_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY card_item
    ADD CONSTRAINT card_item_pkey PRIMARY KEY (id);


--
-- TOC entry 2141 (class 2606 OID 16411)
-- Name: merchan_info merchan_info_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY merchan_info
    ADD CONSTRAINT merchan_info_pkey PRIMARY KEY (id);


--
-- TOC entry 2151 (class 2606 OID 16432)
-- Name: paid_bill paid_bill_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY paid_bill
    ADD CONSTRAINT paid_bill_pkey PRIMARY KEY (id);


--
-- TOC entry 2153 (class 2606 OID 16437)
-- Name: parent_service parent_service_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY parent_service
    ADD CONSTRAINT parent_service_pkey PRIMARY KEY (ps_id);


--
-- TOC entry 2199 (class 2606 OID 17599)
-- Name: payment_order payment_order_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY payment_order
    ADD CONSTRAINT payment_order_pkey PRIMARY KEY (order_id);


--
-- TOC entry 2201 (class 2606 OID 17607)
-- Name: payment_transaction payment_transaction_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY payment_transaction
    ADD CONSTRAINT payment_transaction_pkey PRIMARY KEY (payment_id);


--
-- TOC entry 2155 (class 2606 OID 16445)
-- Name: provider_api provider_api_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY provider_api
    ADD CONSTRAINT provider_api_pkey PRIMARY KEY (id);


--
-- TOC entry 2175 (class 2606 OID 17560)
-- Name: sec_permission sec_permission_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY sec_permission
    ADD CONSTRAINT sec_permission_pkey PRIMARY KEY (id);


--
-- TOC entry 2183 (class 2606 OID 17573)
-- Name: sec_role_permission sec_role_permission_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY sec_role_permission
    ADD CONSTRAINT sec_role_permission_pkey PRIMARY KEY (id);


--
-- TOC entry 2179 (class 2606 OID 17568)
-- Name: sec_role sec_role_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY sec_role
    ADD CONSTRAINT sec_role_pkey PRIMARY KEY (id);


--
-- TOC entry 2187 (class 2606 OID 17578)
-- Name: sec_user sec_user_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY sec_user
    ADD CONSTRAINT sec_user_pkey PRIMARY KEY (id);


--
-- TOC entry 2193 (class 2606 OID 17583)
-- Name: sec_user_role sec_user_role_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY sec_user_role
    ADD CONSTRAINT sec_user_role_pkey PRIMARY KEY (id);


--
-- TOC entry 2159 (class 2606 OID 16450)
-- Name: service service_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY service
    ADD CONSTRAINT service_pkey PRIMARY KEY (s_id);


--
-- TOC entry 2165 (class 2606 OID 16455)
-- Name: service_provider service_provider_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY service_provider
    ADD CONSTRAINT service_provider_pkey PRIMARY KEY (s_id, prvd_id);


--
-- TOC entry 2173 (class 2606 OID 17037)
-- Name: test_bill test_bill_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY test_bill
    ADD CONSTRAINT test_bill_pkey PRIMARY KEY (id);


--
-- TOC entry 2149 (class 2606 OID 16459)
-- Name: billpay_provider uk_1pdpam9jnl87jvr7caeq9avf5; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY billpay_provider
    ADD CONSTRAINT uk_1pdpam9jnl87jvr7caeq9avf5 UNIQUE (provider_code);


--
-- TOC entry 2189 (class 2606 OID 17617)
-- Name: sec_user uk_46psvtdbgrirs6s7ib5d3hs49; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY sec_user
    ADD CONSTRAINT uk_46psvtdbgrirs6s7ib5d3hs49 UNIQUE (username);


--
-- TOC entry 2161 (class 2606 OID 16465)
-- Name: service uk_75p8oeffx30y1dh1xow0htsyt; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY service
    ADD CONSTRAINT uk_75p8oeffx30y1dh1xow0htsyt UNIQUE (service_code);


--
-- TOC entry 2177 (class 2606 OID 17609)
-- Name: sec_permission uk_820njc06hnbad2iocijr5qla4; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY sec_permission
    ADD CONSTRAINT uk_820njc06hnbad2iocijr5qla4 UNIQUE (name);


--
-- TOC entry 2163 (class 2606 OID 16463)
-- Name: service uk_adgojnrwwx9c3y3qa2q08uuqp; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY service
    ADD CONSTRAINT uk_adgojnrwwx9c3y3qa2q08uuqp UNIQUE (name);


--
-- TOC entry 2195 (class 2606 OID 17619)
-- Name: sec_user_role uk_b3jwa7gpeo0hk4obl3fp59i4w; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY sec_user_role
    ADD CONSTRAINT uk_b3jwa7gpeo0hk4obl3fp59i4w UNIQUE (user_id, role_id);


--
-- TOC entry 2185 (class 2606 OID 17613)
-- Name: sec_role_permission uk_ea4cysdh3ecv394w7e4mpsgsw; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY sec_role_permission
    ADD CONSTRAINT uk_ea4cysdh3ecv394w7e4mpsgsw UNIQUE (role_id, permission_id);


--
-- TOC entry 2157 (class 2606 OID 16461)
-- Name: provider_api uk_fpk3o0ci50tjbsdjjpokeivbl; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY provider_api
    ADD CONSTRAINT uk_fpk3o0ci50tjbsdjjpokeivbl UNIQUE (method_name);


--
-- TOC entry 2145 (class 2606 OID 16457)
-- Name: biller uk_gc6ufmu6g85kns4sjtvetuq8e; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY biller
    ADD CONSTRAINT uk_gc6ufmu6g85kns4sjtvetuq8e UNIQUE (biller_id);


--
-- TOC entry 2191 (class 2606 OID 17615)
-- Name: sec_user uk_n94cyl9fx3bjip0xmsca8ih4s; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY sec_user
    ADD CONSTRAINT uk_n94cyl9fx3bjip0xmsca8ih4s UNIQUE (cif);


--
-- TOC entry 2181 (class 2606 OID 17611)
-- Name: sec_role uk_q7bwxajjqg1q793atxs86mhgb; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY sec_role
    ADD CONSTRAINT uk_q7bwxajjqg1q793atxs86mhgb UNIQUE (name);


--
-- TOC entry 2167 (class 2606 OID 16467)
-- Name: service_provider uk_rnkfdc9jc0dpmqfq410s93y7g; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY service_provider
    ADD CONSTRAINT uk_rnkfdc9jc0dpmqfq410s93y7g UNIQUE (prvd_id);


--
-- TOC entry 2169 (class 2606 OID 16514)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 2206 (class 2606 OID 17625)
-- Name: sec_role_permission fk_11bhxwecd6edt844yj58g7i5j; Type: FK CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY sec_role_permission
    ADD CONSTRAINT fk_11bhxwecd6edt844yj58g7i5j FOREIGN KEY (role_id) REFERENCES sec_role(id);


--
-- TOC entry 2204 (class 2606 OID 16478)
-- Name: service_provider fk_50wq9qosaua5ajfa9urrebyul; Type: FK CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY service_provider
    ADD CONSTRAINT fk_50wq9qosaua5ajfa9urrebyul FOREIGN KEY (s_id) REFERENCES service(s_id);


--
-- TOC entry 2205 (class 2606 OID 17620)
-- Name: sec_role_permission fk_80tauu2sw4oj6qpnl4diktv99; Type: FK CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY sec_role_permission
    ADD CONSTRAINT fk_80tauu2sw4oj6qpnl4diktv99 FOREIGN KEY (permission_id) REFERENCES sec_permission(id);


--
-- TOC entry 2202 (class 2606 OID 16468)
-- Name: service fk_cl5m186dyqrh4iv7c2rct1iwa; Type: FK CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY service
    ADD CONSTRAINT fk_cl5m186dyqrh4iv7c2rct1iwa FOREIGN KEY (ps_id) REFERENCES parent_service(ps_id);


--
-- TOC entry 2208 (class 2606 OID 17635)
-- Name: sec_user_role fk_kt2eg5ytt9hnlpxb9ldxjp6k8; Type: FK CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY sec_user_role
    ADD CONSTRAINT fk_kt2eg5ytt9hnlpxb9ldxjp6k8 FOREIGN KEY (user_id) REFERENCES sec_user(id);


--
-- TOC entry 2203 (class 2606 OID 16473)
-- Name: service_provider fk_rnkfdc9jc0dpmqfq410s93y7g; Type: FK CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY service_provider
    ADD CONSTRAINT fk_rnkfdc9jc0dpmqfq410s93y7g FOREIGN KEY (prvd_id) REFERENCES billpay_provider(prvd_id);


--
-- TOC entry 2207 (class 2606 OID 17630)
-- Name: sec_user_role fk_tropn3rq81iwv8nqfed5bgi3g; Type: FK CONSTRAINT; Schema: billpay; Owner: -
--

ALTER TABLE ONLY sec_user_role
    ADD CONSTRAINT fk_tropn3rq81iwv8nqfed5bgi3g FOREIGN KEY (role_id) REFERENCES sec_role(id);


-- Completed on 2017-02-24 11:04:33

--
-- PostgreSQL database dump complete
--

