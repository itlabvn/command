## Deployment notes for statebank

- Initialize database
```
psql -1 -h $10.10.3.10 -U dlotto true_money < docs/true_money.sql
```

- Migration
```
psql -1 -h 10.10.3.10 -U dlotto true_money < docs/00*.sql
```

- Restart trueservice
```
for host in 10.10.2.{11..13}; do
    ssh ubuntu@$host sudo docker restart trueservice
done
```

- Create stock accounts
```
ssh ubuntu@10.10.2.11 'curl http://127.0.0.1:10501/TrueService/api/system/v1/request -d \'{"accountId": null,"cardId": "000000000","requestGateWay": "system","appId": "easy","deviceId": "G8700000000","serviceId": "create_stock","step": "confirm","data": {"lastName": "Actual pool wallet","fristName": "TM","userAccountId": "10000004", "userAccountClassify":"wallet"}}\' -H "Content-Type:application/json" -H "Api-Key:5isumn2pz7ziqvqoim1w" -H "Api-Secret:yz9isqcrha7mh3fz8m9tlbwoxziyb6qs"'
ssh ubuntu@10.10.2.11 'curl http://127.0.0.1:10501/TrueService/api/system/v1/request -d \'{"accountId": null,"cardId": "000000000","requestGateWay": "system","appId": "easy","deviceId": "G8700000000","serviceId": "create_stock","step": "confirm","data": {"lastName": "Paybill wallet","fristName": "TM","userAccountId": "10000005", "userAccountClassify":"wallet"}}\' -H "Content-Type:application/json" -H "Api-Key:5isumn2pz7ziqvqoim1w" -H "Api-Secret:yz9isqcrha7mh3fz8m9tlbwoxziyb6qs"'
ssh ubuntu@10.10.2.11 'curl http://127.0.0.1:10501/TrueService/api/system/v1/request -d \'{"accountId": null,"cardId": "000000000","requestGateWay": "system","appId": "easy","deviceId": "G8700000000","serviceId": "create_stock","step": "confirm","data": {"lastName": "Promotion wallet","fristName": "TM","userAccountId": "10000006", "userAccountClassify":"wallet"}}\' -H "Content-Type:application/json" -H "Api-Key:5isumn2pz7ziqvqoim1w" -H "Api-Secret:yz9isqcrha7mh3fz8m9tlbwoxziyb6qs"'
ssh ubuntu@10.10.2.11 'curl http://127.0.0.1:10501/TrueService/api/system/v1/request -d \'{"accountId": null,"cardId": "000000000","requestGateWay": "system","appId": "easy","deviceId": "G8700000000","serviceId": "create_stock","step": "confirm","data": {"lastName": "Paybill commission stock","fristName": "TM","userAccountId": "23029031", "userAccountClassify":"wallet"}}\' -H "Content-Type:application/json" -H "Api-Key:5isumn2pz7ziqvqoim1w" -H "Api-Secret:yz9isqcrha7mh3fz8m9tlbwoxziyb6qs"'
ssh ubuntu@10.10.2.11 'curl http://127.0.0.1:10501/TrueService/api/system/v1/request -d \'{"accountId": null,"cardId": "000000000","requestGateWay": "system","appId": "easy","deviceId": "G8700000000","serviceId": "create_stock","step": "confirm","data": {"lastName": "Paybill provider stock","fristName": "TM","userAccountId": "23029032"}}\' -H "Content-Type:application/json" -H "Api-Key:5isumn2pz7ziqvqoim1w" -H "Api-Secret:yz9isqcrha7mh3fz8m9tlbwoxziyb6qs"'
```

## Deployment notes for v2.2.7

- Deploy new version
```
ansible-playbook -Dvv trueservice.yml
```

- Migrate database
```
psql -1 -h $PGHOST -U dlotto true_money < $WORKSPACE/trueservice/documents/releases/20170215_v2.2.7/updated_20170215_bill_payment.sql
```

- Create stock accounts
```
curl http://127.0.0.1:10501/TrueService/api/system/v1/request -d '{"accountId": null,"cardId": "000000000","requestGateWay": "system","appId": "easy","deviceId": "G8700000000","serviceId": "create_stock","step": "confirm","data": {"lastName": "Paybill commission stock","fristName": "TM","userAccountId": "23029031"}}' -H "Content-Type:application/json" -H "Api-Key:5isumn2pz7ziqvqoim1w" -H "Api-Secret:yz9isqcrha7mh3fz8m9tlbwoxziyb6qs"
curl http://127.0.0.1:10501/TrueService/api/system/v1/request -d '{"accountId": null,"cardId": "000000000","requestGateWay": "system","appId": "easy","deviceId": "G8700000000","serviceId": "create_stock","step": "confirm","data": {"lastName": "Paybill provider stock","fristName": "TM","userAccountId": "23029032"}}' -H "Content-Type:application/json" -H "Api-Key:5isumn2pz7ziqvqoim1w" -H "Api-Secret:yz9isqcrha7mh3fz8m9tlbwoxziyb6qs"
```

- Restart trueservice

## Deployment notes for v2.2.6

- Run this SQL first
```
BEGIN;

INSERT INTO public.sys_system_preference(VARIABLE, data_type, value, is_allow_update, sys_preference_type, description, service_type, is_stock_account, group_variable, is_use_by)
VALUES ('assigned_roles_config_for_deposit_approval', 'String', '1,107,108,125', 'Y', NULL, 'Assigned role for approval', NULL, 'N', NULL, NULL);

INSERT INTO public.sys_system_preference(VARIABLE, data_type, value, is_allow_update, sys_preference_type, description, service_type, is_stock_account, group_variable, is_use_by)
VALUES ('assigned_roles_config_for_stock_tansfer', 'String', '1,107,125', 'Y', NULL, 'Assigned role for approval', NULL, 'N', NULL, NULL);

COMMIT;
```

- Deploy as usual
```
ansible-playbook -Dvv trueservice.yml -C
ansible-playbook -Dvv trueservice.yml
```

## Deployment notes for version 2

- Run this SQL first
```
BEGIN;

INSERT INTO "public"."apps" ("service", "staff__id", "created_at", "platform", "api_secret", "updated_at", "api_key")
VALUES ('easy', NULL, NULL, 'web', 'hy84nZJ8PUfDs2VUKVTjH4gkYZFemG7Utf4xANyc', NULL, 'fUNKE6ux3xGNJ6g338RFt');

INSERT INTO "public"."apps" ("service", "staff__id", "created_at", "platform", "api_secret", "updated_at", "api_key")
VALUES ('ptu', NULL, NULL, 'web', 'nRAySnEJY4N6UuWmwqrZLafKSpPAcALxTfjvRKVz', NULL, 'bZvZ757FcefdRAg8NKYAZ');

COMMIT;
```
- Deploy as usual
```
ansible-playbook -Dvv trueservice.yml -C
ansible-playbook -Dvv trueservice.yml
```
