######chuyển service từ không có HA sang HA:
với những request từ ngoài internet vào thì dùng nginx
Với những request giữa các server với nhau thì sử dụng HAproxy
=> service chỉ nhận request từ ngoài internet thì chỉ cần cần dùng nginx
   service nhận request giữa các server và cả ngoài internet thì dùng cả nginx và haproxy



- Add thêm host vào groups trong inventory
	[billpaygw]
	172.31.1.41 nr_tier=app nr_name=billpaygw
	172.31.1.237 nr_tier=app nr_name=billpaygw

- Thêm biến "node_port" có giá trị bằng "port + 1"

- Sửa giá trị của biến "host" thành {{ ansible_default_ipv4.address }}
	billpaygw:
	  domain: dev.api.mybill.vn
	  host: "{{ ansible_default_ipv4.address }}"
	  port: 10700
	  node_port: 10701

- Cấu hình thêm fronend và backend cho HAproxy (templates/haproxy/haproxy.cfg.j2)
	########## Config billpaygw HA ##########

	frontend {{ billpaygw.domain }}
			mode tcp
			option tcplog
			bind {{ ansible_default_ipv4.address }}:{{ billpaygw.port }}
			default_backend {{ billpaygw.domain }}
			timeout client          1m

	backend {{ billpaygw.domain }}
			mode tcp
			option tcplog
			balance roundrobin
			{% for node in groups['billpaygw'] %}
			server billpaygw-0{{ loop.index }} {{ hostvars[node]['ansible_default_ipv4']['address'] }}:{{ billpaygw.node_port }}
			{% endfor %}
			timeout connect        10s
			timeout server          1m

- add thêm task vào playbook để copy cấu hình haproxy lên server.



- Cấu hình nginx upstream và proxy pass đến upstream:
	upstream billpayfe_{{ billpay.fe.port }} {
	{% for host in groups['billpay-fe'] %}
		server {{ host }}:{{ billpay.fe.port }};
	{% endfor %}
	}
- add thêm task vào playbook để copy cấu hình nginx lên server.
