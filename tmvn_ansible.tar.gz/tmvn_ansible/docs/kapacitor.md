I. Deploy kapacitor
Install kapacitor: ansible-playbook -i dev kapacitor.yml -Dvv --tags=install
Config kapacitor: ansible-playbook -i dev kapacitor.yml -Dvv --tags=config


II. Explain deploy config for kapatitor
- Trong files kapacitor.yml có các tasks copy batch, copy stream, copy template từ local lên agent kapacitor. tương ứng sau khi chạy mỗi tasks sẽ sử dụng "register" để liệt kê các files ticks được copy
- Tasks "Creating the list item changed" sẽ tạo 1 list "$ticks_files_changed" liệt kê  các files tick có thay đổi so với đích dựa vào thuộc tinh "changed" 
- Tasks "Processing kapacitor tasks" sẽ chỉ thực hiện delete, define và enable các tasks trong kapacitor khi list "$ticks_files_changed" có giá trị và chỉ thực hiện với những tick files có thay đổi hoặc tạo mới


II. Explain bash script files/kapacitor/tasks.sh 
- Với đầu vào "$1" = "$ticks_files_changed". Sử dụng vòng lặp "for" để liệt kê từng thành phần trong list "$ticks_files_changed" cho việc delete, define và enable các tasks trong kapacitor
- Ví dụ giá trị mẫu của $task, $type, $tick  
  $task = "load"
  $type = "batch"
  $tick = "/etc/kapacitor/ticks/batch/load.tick"
