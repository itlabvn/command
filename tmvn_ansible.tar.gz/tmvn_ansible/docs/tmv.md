## Upgrade notes

### Version 1.2.35

- Run this SQL
```
UPDATE "public"."sys_system_preference" SET "value"='86400' WHERE "variable"='true_transfer_time_cancel';
UPDATE "public"."sys_system_preference" SET "value"='2880' WHERE "variable"='true_buy_pinless_time_cancel';
```
- Clear TrueService cache
```
curl http://localhost:10501/TrueService/service/clear_cache_system_preferences -d ""
```

### Version 1.2.32

- Run this SQL
```
BEGIN;
ALTER TABLE stock_items ADD COLUMN owners varchar(1);
COMMIT;
```
- Run this SQL
```
BEGIN;
CREATE UNIQUE INDEX "wallet_by_date_idx" ON "public"."wallet_by_date" USING btree ("user_account__id", "date_payment");
COMMIT;
```
- Run this SQL
```
BEGIN;
UPDATE user_profile SET kyc_status = 'basic' WHERE kyc_status IS NULL;
ALTER TABLE user_profile ALTER COLUMN kyc_status SET NOT NULL;
ALTER TABLE user_profile ALTER COLUMN kyc_status SET DEFAULT 'basic';
COMMIT;
```
- Deploy as usual
- Run `php /opt/true-money/www/true-operation/laravel-app/artisan insert:walletByDate 2016-12-19 close`
- Run `php /opt/true-money/www/true-operation/laravel-app/artisan insert:walletByDate 2017-01-05 2017-02-14`
