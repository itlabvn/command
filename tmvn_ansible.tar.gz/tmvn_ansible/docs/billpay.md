## Upgrade notes

### Version 1.1
- Migrate database
```
psql -1 -h $PGHOST -U billpay -d billpay -f scripts_update/script_0001.sql -f scripts_update/script_0002.sql -f scripts_update/script_0003.sql
```

- Deploy
```
ansible-playbook -Dvv -i $ENV billpaygw.yml billpay-fe.yml
```

- Migrate trueservice
```
psql -1 -h $PGHOST -U dlotto -d true_money -f 0008-v2.2.10.sql -f 0009-v2.2.10.sql -f 0010-v2.2.10.sql -f 0011-v2.2.10.sql -f 0012-v2.2.10.sql -f 0013-v2.2.10.sql -f 0014-v2.2.10.sql
```

- Deploy trueservice
```
ansible-playbook -Dvv -i $ENV trueservice.yml
```

- Import data
```
psql -1 -h 172.31.4.207 -U tmv_edc_gw -d edc_gateway -f documents/releases/v1.2.6/00001.sql -f documents/releases/v1.2.6/00002.sql -f billpay_300agent_product.sql
```

- Deploy edcgw
```
ssh tmvn-edc sudo nginx -s quit
ansible-playbook -Dvv -i $ENV edcgw.yml
ssh tmvn-edc sudo service nginx start
```

- Deploy web apps
```
ansible-playbook -Dvv -i $ENV tmv-deploy.yml agent_dashboard-deploy.yml landingpage-deploy.yml
```

### Version 1.0

- Initialize database
```
ansible-playbook -Dvv -i $ENV billpaygw.yml --tags=postgres
```

- Import data
```
psql -1 -h $PGHOST -U billpay billpay < billpayment_service.1.0.sql
```

- Create roles and grant permissions
```
ansible-playbook -Dvv -i $ENV billpay-fe.yml --tags=postgres
```

- Deploy
```
ansible-playbook -Dvv -i $ENV billpaygw.yml billpay-fe.yml
```
