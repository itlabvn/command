Cách restore data của graylog lưu trên elasticsearch:
+ Nếu restore ở server khác:
b1: Nén tất cả các dữ liệu snapshot trên máy chủ elasticsearch (/var/backups/elasticsearch)
b2: Copy file vừa nén đến máy chủ elasticsearch mới sau đó giải nén vào thư mục chứa snapshot (/var/backups/elasticsearch)
b3: chạy lệnh ở dưới từ máy local:

        ansible all -i "13.228.27.219," -m script -a "scripts/elasticsearch_restore.sh -h 172.33.0.208 -p 9200" -Dvvv
    trong đó:
    172.33.0.208 là địa chỉ mà elasticsearch listen.
    13.228.27.219 là địa chỉ máy chủ elasticsearch mà máy local có thể ssh đến được


+ Nếu restore ở cùng server thì chỉ cần chạy bước thứ 3 ở trên.
