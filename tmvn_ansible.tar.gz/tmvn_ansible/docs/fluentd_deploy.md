### Mô hình hoạt động của fluentd kết hợp graylog ###
Các ontainers sẽ được cấu hình logging driver=fluentd với port mặc định 24224. Các  hosts sẽ được cài đặt fluentd từ file fluentd_deploy.yml với cấu hình agent(tmvn_ansible/templates/fluentd/td-agent-host.j2) sẽ nhận log từ các containers trên port 24224. Trên graylog server sẽ cài đặt fluentd với cấu hình dạng server(tmvn_ansible/templates/fluentd/td-agent-graylog.j2) sẽ nhận log từ port 9012 từ các fluentd agent và containers với port mặc định 24224 (nếu nằm trực tiếp trên hosts chứa graylog server).  Fluentd server và sử dụng output gelf plugin để đẩy log lên input gelf của graylog server. 

- Đặc tính mô hình: Khi connection giữa hosts chứa fluentd agent hoặc  host chứa fluentd server (graylog server) hoặc fluentd service trên graylog server bị down. Toàn bộ log từ các containers sẽ được buffer trên hosts chứa các containers và được đẩy tới graylog server khi connection up

- Khai báo firewall
+ Open input, output port 24224 trên các hosts chứa fluentd agent
+ Open input port 9012 and 24224 trên graylog server hosts (fluentd server)

- Câu lệnh deploy
+ Khai báo lại log_driver cho các containers
container:
  log_driver: fluentd
  log_options: tag=docker
Ví dụ container:  sudo docker run -ti --name test --log-driver=fluentd --log-opt tag=docker nginx /bin/bash

+ Thêm các ip address của các hosts muốn deploy fluentd agent hoặc server vào file tmvn_ansible/dev
[fluentd]
ip_address 1
ip_address 2 ...

Command deploy:# ansible-playbook -i dev fluentd_deploy.yml -Dvvv
