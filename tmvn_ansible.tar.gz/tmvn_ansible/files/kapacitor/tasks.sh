#!/bin/bash

#set -x

tick_dir=/etc/kapacitor/ticks
database="telegraf"

for path in $1
do
    # example path: stream/load.tick or /a/b/c/tmvn_ansible/stream/load.tick
    # in which task filename is load.tick, task is load, type is stream
    filename=$(basename $path)
    task=${filename%.*}
    type=$(basename $(dirname $path))
    tick=$tick_dir/$type/$filename

    kapacitor delete tasks $task
    echo "Delete tasks $task successfully"

    kapacitor define $task -tick $tick -type $type -dbrp ${database}.autogen
    echo Define task $task with tick script $tick successfully

    kapacitor enable $task
    echo "Enable tasks $task successfully"
done
