#!/usr/bin/env bash

  cat true_money_v2.sql | gzip \
| pv \
| ssh ubuntu@10.10.3.10 'gunzip | sudo -u postgres psql -1 true_money'

  ssh ubuntu@52.220.25.33 'mysqldump -u cms_truemoney -pBfxECx3NO6MWIF1nSGQBLolNcPVlybjUflYTWkFeFI cms_truemoney | gzip' \
| pv \
| ssh ubuntu@10.10.3.11 'gunzip | mysql -u cms_truemoney -pBfxECx3NO6MWIF1nSGQBLolNcPVlybjUflYTWkFeFI cms_truemoney'

DIR=/opt/true-money/www/true-operation
  ssh ubuntu@52.220.25.33 sudo tar -cz -C "$DIR" ./images \
| pv \
| ssh ubuntu@10.10.2.12 sudo tar -xz -C "$DIR"


DIR=/opt/true-money/www/html/landing_cms
  ssh ubuntu@52.220.25.33 sudo tar -cz -C "$DIR" ./uploads \
| pv \
| ssh ubuntu@10.10.2.12 sudo tar -xz -C "$DIR"
