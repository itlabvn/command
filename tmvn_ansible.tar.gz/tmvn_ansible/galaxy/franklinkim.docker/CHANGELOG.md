<a name="1.7.0"></a>
## 1.7.0 (2017-03-27)


#### Features

*   update meta info to use ansible 2.0 ([62e6301a](https://github.com/weareinteractive/ansible-docker/commit/62e6301a485678eec365a532d99c515502072472))
*   add docker_pip_dependencies ([3abd25f6](https://github.com/weareinteractive/ansible-docker/commit/3abd25f60063c4a1fe0b1867422c9f3df8934433))
*   use docker_container instead obsolete docker ([cd0b0974](https://github.com/weareinteractive/ansible-docker/commit/cd0b0974c301b23c94e0408e8b903cd2737510af))
*   update tests sudo to become ([bff2dc35](https://github.com/weareinteractive/ansible-docker/commit/bff2dc3513fb4f548da207d238f421edec9f1521))



<a name="1.6.1"></a>
### 1.6.1 (2016-02-29)


#### Features

*   don't use bare variable names ([026b3f98](https://github.com/weareinteractive/ansible-docker/commit/026b3f988217ed6c74efbe6c362295fc62b1efdf))



<a name="1.6.0"></a>
## 1.6.0 (2015-11-30)


#### Features

*   using ansible-role to generate README ([e6a93ed8](https://github.com/weareinteractive/ansible-docker/commit/e6a93ed837e92ad85fc5ec040fe38afb5417771f))
*   adds CHANGELOG ([3b2913da](https://github.com/weareinteractive/ansible-docker/commit/3b2913da9e5b03c5ad66b7c3e277cf75ac34e050))
*   adds opensuse support ([f93b5f21](https://github.com/weareinteractive/ansible-docker/commit/f93b5f2104e6a6154d95ace2b3fd5824e7ad1d3d))
