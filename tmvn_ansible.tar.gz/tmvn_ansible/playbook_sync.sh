#!/usr/bin/env bash

set -e

for service_playbook in *-deploy.yml; do
    project_name="${service_playbook%-deploy.yml}"
    project_playbook="../*/ansible/${project_name}.yml"
    if ! diff $service_playbook $project_playbook; then
        vimdiff $service_playbook $project_playbook
    fi
done
