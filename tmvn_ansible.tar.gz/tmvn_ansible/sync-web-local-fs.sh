#!/usr/bin/env bash

ssh tmvn-web-stg sudo tar -cz -C /opt/true-money/www/true-operation ./images | ssh -i ~/.ssh/tmvn-staging.pem ubuntu@172.31.1.237 sudo tar -xz -C /opt/true-money/www/true-operation
ssh tmvn-web-stg sudo tar -cz -C /opt/true-money/www/html/landing_cms ./uploads | ssh -i ~/.ssh/tmvn-staging.pem ubuntu@172.31.1.237 sudo tar -xz -C /opt/true-money/www/html/landing_cms

ssh -i ~/.ssh/1pay_tmc.pem -o 'ProxyCommand=ssh -W %h:%p -q tmvn-web-stg' ubuntu@172.31.6.103 'sudo -u postgres pg_dump true_money | gzip' | ssh -i ~/.ssh/tmvn-staging.pem ubuntu@172.31.2.4 'gunzip | sudo -u postgres psql -1 -U postgres true_money'
ssh -i ~/.ssh/1pay_tmc.pem -o 'ProxyCommand=ssh -W %h:%p -q tmvn-web-stg' ubuntu@172.31.6.103 'sudo -u postgres pg_dump true_money_oauth2 | gzip' | ssh -i ~/.ssh/tmvn-staging.pem ubuntu@172.31.2.4 'gunzip | sudo -u postgres psql -1 -U postgres true_money_oauth2'
ssh -i ~/.ssh/1pay_tmc.pem -o 'ProxyCommand=ssh -W %h:%p -q tmvn-web-stg' ubuntu@172.31.6.103 'sudo -u postgres pg_dump metabase | gzip' | ssh -i ~/.ssh/tmvn-staging.pem ubuntu@172.31.2.4 'gunzip | sudo -u postgres psql -1 -U postgres metabase'
ssh -i ~/.ssh/1pay_tmc.pem -o 'ProxyCommand=ssh -W %h:%p -q tmvn-web-stg' ubuntu@172.31.6.103 'sudo -u postgres pg_dump saleapp | gzip' | ssh -i ~/.ssh/tmvn-staging.pem ubuntu@172.31.2.4 'gunzip | sudo -u postgres psql -1 -U postgres saleapp'
ssh tmvn-web-stg "mysqldump -u root -p'123456a@' cms_truemoney | gzip" | ssh -i ~/.ssh/tmvn-staging.pem ubuntu@172.31.2.4 'gunzip | mysql -u cms_truemoney -pBfxECx3NO6MWIF1nSGQBLolNcPVlybjUflYTWkFeFI cms_truemoney'

  ssh -i ~/.ssh/tmvn-staging.pem ubuntu@172.31.2.4 'sudo -u postgres pg_dump true_money | gzip' \
| pv \
| ssh -i ~/.ssh/tmvn-staging.pem ubuntu@172.32.2.11 'gunzip | sudo -u postgres psql -1 true_money'

  ssh -i ~/.ssh/tmvn-staging.pem ubuntu@172.31.2.4 'sudo -u postgres pg_dump --data-only saleapp | gzip' \
| pv \
| ssh -i ~/.ssh/tmvn-staging.pem ubuntu@172.32.2.11 'gunzip | sudo -u postgres psql -1 saleapp'

  ssh -i ~/.ssh/tmvn-staging.pem ubuntu@172.31.2.4 'mysqldump -u cms_truemoney -pBfxECx3NO6MWIF1nSGQBLolNcPVlybjUflYTWkFeFI cms_truemoney | gzip' \
| pv \
| ssh -i ~/.ssh/tmvn-staging.pem ubuntu@172.32.2.11 'gunzip | mysql -u cms_truemoney -pBfxECx3NO6MWIF1nSGQBLolNcPVlybjUflYTWkFeFI cms_truemoney'

  ssh -i ~/.ssh/tmvn-staging.pem ubuntu@172.31.1.12 sudo tar -cz -C /opt/true-money/www/true-operation ./images \
| pv \
| ssh -i ~/.ssh/tmvn-staging.pem ubuntu@172.32.1.12 sudo tar -xz -C /opt/true-money/www/true-operation

  ssh -i ~/.ssh/tmvn-staging.pem ubuntu@172.31.1.12 sudo tar -cz -C /opt/true-money/www/html/landing_cms ./uploads \
| pv \
| ssh -i ~/.ssh/tmvn-staging.pem ubuntu@172.32.1.12 sudo tar -xz -C /opt/true-money/www/html/landing_cms

  ssh tmvn-web sudo tar -cz -C /opt/true-money/www/true-operation ./images \
| pv \
| ssh ubuntu@10.10.2.42 sudo tar -xz -C /opt/true-money/www/true-operation

ansible-playbook -i production3 edcgw.yml --tags=postgres -DC

  ssh tmvn-edc 'sudo -u postgres pg_dump -T edc_archived_audit_logs -T edc_archived_sessions edc_gateway | gzip' \
| pv \
| ssh ubuntu@10.10.3.12 'gunzip | sudo -u postgres psql -p 5433 -1 edc_gateway'

ssh -R localhost:50000:10.10.2.42:22 tmvn-web 'rsync -e "ssh -p 50000 -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null" -av -P /opt/true-money/www/true-operation/images/ ubuntu@localhost:/opt/true-money/www/true-operation/images'
